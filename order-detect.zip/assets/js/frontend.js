jQuery(document).ready(function($) {
    var countdownInterval; // Global variable to hold the countdown interval
    var countdownDuration = getResendCountdownDuration();

    function getResendCountdownDuration() {
        var configured = parseInt(order_detect.settings.otp_resend_countdown_seconds, 10);

        if (isNaN(configured)) {
            configured = 60;
        }

        configured = Math.min(Math.max(configured, 5), 600);
        return configured;
    }

    function isValidBangladeshiPhoneNumber(phoneNumber) {
        return normalizeBangladeshiPhoneNumber(phoneNumber) !== null;
    }

    function normalizeBangladeshiPhoneNumber(phoneNumber) {
        if (typeof phoneNumber !== 'string') {
            return null;
        }

        phoneNumber = phoneNumber.replace(/\D+/g, '');

        if (/^8801[1-9]\d{8}$/.test(phoneNumber)) {
            return '0' + phoneNumber.slice(3);
        }

        if (/^01[1-9]\d{8}$/.test(phoneNumber)) {
            return phoneNumber;
        }

        return null;
    }

    function showInvalidPhoneError() {
        showCheckoutError(order_detect.invalid_phone_message || 'Please enter a valid Bangladeshi phone number. Example: 017XXXXXXXX.');
        $("#billing_phone").focus();
    }

    function validateCheckoutFields() {
        var isValid = true;
        
        $('.woocommerce-invalid').removeClass('woocommerce-invalid');
        $('.woocommerce-error').remove();
        
        $('form.checkout').find('.woocommerce-billing-fields .validate-required input, .woocommerce-billing-fields .validate-required select').each(function() {
            var $field = $(this);
            var value = $field.is('select') ? $field.val() : $field.val().trim();
            if (value === '' || (value === null && $field.is('select'))) {
                isValid = false;
                $field.addClass('woocommerce-invalid');
            } else {
                $(this).removeClass('woocommerce-invalid');
            } 
        });

        if ($('#ship-to-different-address-checkbox').prop('checked') === true) {
            $('form.checkout').find('.shipping_address .validate-required input, .shipping_address .validate-required select').each(function() {
                var $field = $(this);
                var value = $field.is('select') ? $field.val() : $field.val().trim();
                if (value === '' || (value === null && $field.is('select'))) {
                    isValid = false;
                    $(this).addClass('woocommerce-invalid');
                } else {
                    $(this).removeClass('woocommerce-invalid');
                }
            });
        }
        
        return isValid;
    }

    function showCheckoutError(message) {
        $('.woocommerce-error, .woocommerce-message, .woocommerce-NoticeGroup').remove();
        var $form = $('form.checkout');
        var $error = $('<ul class="woocommerce-error" role="alert"><li></li></ul>');
        $error.find('li').text(message);
        $form.prepend($error);
        $('html, body').animate({ scrollTop: $form.offset().top - 30 }, 200);
    }

    function resetOtpPopupState() {
        $('.otp-processing-area').show();
        $('.otp-form-area').hide();
        $('#otp-verify-failed').removeClass('order-detect-show').text('');
        $('#otp-status-notice').removeClass('order-detect-show').text('');
        $('#otp-sedning-msg').text('');
        $('#otp-code').val('');
        $("#otp-resend-msg, #otp-resend-btn").remove();
        clearInterval(countdownInterval);
        countdownDuration = getResendCountdownDuration();
    }

    function openOtpPopupLoading() {
        resetOtpPopupState();
        document.getElementById('od-order-verification-popup').style.display = 'flex';
    }

    function closeOtpPopup() {
        document.getElementById('od-order-verification-popup').style.display = 'none';
        resetOtpPopupState();
    }

    function showOtpFormState() {
        $('.otp-processing-area').hide();
        $('.otp-form-area').show();
    }

    async function prepareOtpState(billingPhone) {
        try {
            const response = await $.ajax({
                type: 'POST',
                dataType: 'json',
                url: order_detect.ajax_url,
                data: {
                    action: 'od_prepare_otp',
                    security: order_detect.nonce,
                    phone_number: billingPhone
                }
            });

            if (!response || response.success !== true || !response.data || !response.data.status) {
                return { ok: false, status: 'error' };
            }

            return {
                ok: true,
                status: response.data.status
            };
        } catch (error) {
            var message = (error.responseJSON && error.responseJSON.data && error.responseJSON.data.message)
                ? error.responseJSON.data.message
                : order_detect.something_wrong;
            showCheckoutError(message);
            return { ok: false, status: 'error' };
        }
    }

    function startCountdown(duration, elementId) {
        clearInterval(countdownInterval);
        var timer = duration, minutes, seconds;
        var $element = $(elementId);
        countdownInterval = setInterval(function() {
            minutes = parseInt(timer / 60, 10);
            seconds = parseInt(timer % 60, 10);
            seconds = seconds < 10 ? "0" + seconds : seconds;
            var timeText = minutes + ':' + seconds;
            var countdownText = order_detect.resend_countdown_text || 'Didn\'t receive code? Resend in %time%';
            countdownText = countdownText.replace('%time%', timeText);
            $element.html('<p class="otp-resend-msg" id="otp-resend-msg">' + countdownText + '</p>');
            if (--timer < 0) {
                clearInterval(countdownInterval);
                $element.html('');
                $element.append('<button type="button" class="otp-verification-btn" id="otp-resend-btn">' + order_detect.resend_otp + '</button>');
            }
        }, 1000);
    }

    $(document).on('click', '.show-otp-popup', async function(e) {
        e.preventDefault();

        if (validateCheckoutFields()) {
            let billingPhone = $("#billing_phone").val();
            billingPhone = normalizeBangladeshiPhoneNumber(billingPhone);
            if (billingPhone) {
                if(order_detect.settings['enable_otp']) {
                    openOtpPopupLoading();

                    const otpState = await prepareOtpState(billingPhone);
                    if (!otpState.ok) {
                        closeOtpPopup();
                        return;
                    }

                    if (otpState.status === 'verified') {
                        closeOtpPopup();
                        $('form.checkout').submit();
                    } else {
                        showOtpFormState();
                        sendOTP('#otp-verify-btn', billingPhone);
                    }
                } else {
                    $('form.checkout').submit();
                }
            } else {
                showInvalidPhoneError();
            }
        }
    });

    $(document).on('click', '#otp-verify-btn', function() {
        let that = $(this);
        let phoneNumber = $.trim($("#billing_phone").val());
        phoneNumber = normalizeBangladeshiPhoneNumber(phoneNumber);
        let otpCode = $.trim($("#otp-code").val());

        if (otpCode != '' && otpCode.length == 4 && (phoneNumber != '' && isValidBangladeshiPhoneNumber(phoneNumber))) {

            that.html(order_detect.loader);
            that.prop("disabled", true);
            
            $.ajax({
                type: 'POST',
                dataType: 'json',
                url: order_detect.ajax_url,
                data: {
                    action: 'verify_otp',
                    security: order_detect.nonce,
                    otp: otpCode,
                    phone_number: phoneNumber
                },
                success: function(response, textStatus, jqXHR) {
                    var statusCode = jqXHR.status;
                    that.html('');

                    if (statusCode === 200 && response.success) {
                        $('#otp-verify-failed').addClass('order-detect-hide');
                        $('#otp-status-notice').addClass('order-detect-show').text(response.message);
                        that.html(order_detect.verify);
                        $('.otp-verification-form').remove();
                        $('.otp-process-loader').show();
                        $('form.checkout').submit();
                        document.getElementById('od-order-verification-popup').style.display = 'none';
                    } else {
                        $('#otp-verify-failed').addClass('order-detect-show').text(response.message);
                        that.html(order_detect.verify);
                        that.prop("disabled", false);
                    }
                },
                error: function(jqXHR) {
                    $('#otp-verify-failed').addClass('order-detect-show').text(order_detect.something_wrong);
                    that.html('');
                    that.html(order_detect.try_again);
                    that.prop("disabled", false);
                }
            });

        }
    });

    $(document).on('click', '#otp-resend-btn', function(e) {
        e.preventDefault();
        $("#otp-code").val('');
        let billingPhone = $("#billing_phone").val();
        sendOTP('#otp-resend-btn', billingPhone);
    });

    function sendOTP(elementId, billingPhone) {
        billingPhone = normalizeBangladeshiPhoneNumber(billingPhone);
        if (billingPhone != '' && isValidBangladeshiPhoneNumber(billingPhone)) {

            let that = $(elementId);
            let otpSent = false;
            that.html(order_detect.loader);
            that.prop("disabled", true);

            $.ajax({
                type: 'POST',
                dataType: 'json',
                url: order_detect.ajax_url,
                data: {
                    action: 'send_otp',
                    security: order_detect.nonce,
                    phone_number: billingPhone
                },
                success: function(response, textStatus, jqXHR) {
                    otpSent = true;
                    $("#otp-sedning-msg").text(response.message);
                },
                error: function(jqXHR) {
                    var responseMessage = jqXHR.responseJSON && jqXHR.responseJSON.message
                        ? jqXHR.responseJSON.message
                        : order_detect.something_wrong;
                    $("#otp-sedning-msg").text(responseMessage);
                    that.html(order_detect.verify);
                    that.prop("disabled", false);
                },
                complete: function() {
                    that.html(order_detect.verify);
                    that.prop("disabled", false);
                    if (otpSent) {
                        startCountdown(countdownDuration, '#otp-resend-section');
                    }
                }
            });

        } else {
            showInvalidPhoneError();
        }
    }

    $(document).on('click', '.modal__close', function() {
        closeOtpPopup();
    });

});
