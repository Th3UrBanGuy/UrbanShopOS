(function ($) {
  "use strict";

  $.orderDetect = $.orderDetect || {};
  $(document).ready(function () {
    let activeTab = "license";
    const qVars = $.orderDetect.get_query_vars();
    if (
      qVars.page === "order-detect" &&
      qVars.tab &&
      qVars.tab !== "undefined"
    ) {
      activeTab = qVars.tab;
    }
    $.orderDetect.setActiveTab(activeTab);
    $.orderDetect.init();
  });

  $.orderDetect.get_query_vars = function () {
    const vars = {};
    window.location.href.replace(
      /[?&]+([^=&]+)=([^&]*)/gi,
      function (m, key, value) {
        vars[key] = value;
      }
    );
    return vars;
  };

  $.orderDetect.init = function () {
    $.orderDetect.bindEvents();
  };

  $.orderDetect.bindEvents = function () {
    $(".order-detect-settings-button").removeClass("button");
    $(document).on("click", "#enable_otp", function () {
      const sms_provider = $("#sms_provider").val();
      const sms_api_key = $("#sms_api_key").val();
      const dianahost_sender_id = $("#dianahost_sender_id").val();
      const mimsms_sender_id = $("#mimsms_sender_id").val();
      const mimsms_username = $("#mimsms_username").val();
      const bulksmsbd_sender_id = $("#bulksmsbd_sender_id").val();

      if (!sms_provider || !sms_api_key) {
        alert("Please select an SMS provider and enter the API key first.");
        return false;
      }

      if (sms_provider === "dianahost" && !dianahost_sender_id) {
        alert("Please enter Dianahost Sender ID first.");
        return false;
      }

      if (
        sms_provider === "mimsms" &&
        (!mimsms_sender_id || !mimsms_username)
      ) {
        alert("Please enter Mimsms Sender ID and Username first.");
        return false;
      }

      if (sms_provider === "bulksmsbd" && !bulksmsbd_sender_id) {
        alert("Please enter Bulksmsbd Sender ID first.");
        return false;
      }

      $.orderDetect.toggleOtpSettings();
    });
    $.orderDetect.toggleOtpSettings();

    $(document).on("click", "#enable_footer_text", function () {
      $.orderDetect.toggleOtpSettings();
    });
  };

  $.orderDetect.settingsTab = function (button) {
    const tabToGo = $(button).data("tab");
    const qVars = $.orderDetect.get_query_vars();

    // Check if trying to access Checkout OTP or Order Notification tabs with blank SMS provider
    // if (tabToGo === "otp_settings" || tabToGo === "order_notifications") {
    // 	const sms_provider = $('#sms_provider').val();
    // 	if (!sms_provider || sms_provider === "") {
    // 		alert('Please select an SMS provider before accessing this tab.');
    // 		return false;
    // 	}
    // }

    if (
      qVars.page === "order-detect" &&
      qVars.tab &&
      qVars.tab !== "undefined"
    ) {
    }
    $.orderDetect.setActiveTab(tabToGo);
  };

  $(".order-detect-settings-menu li").on("click", function () {
    $.orderDetect.settingsTab(this);
  });

  $.orderDetect.setActiveTab = function (tab) {
    if (!tab) {
      tab = "license";
    }
    $('.order-detect-settings-menu li[data-tab="' + tab + '"]')
      .addClass("active")
      .siblings()
      .removeClass("active");
    $("#order-detect-" + tab)
      .addClass("active")
      .siblings()
      .removeClass("active");
    const qVars = $.orderDetect.get_query_vars();
    if (qVars.page === "order-detect") {
      const baseUrl = window.location.href.split("?")[0] + "?page=order-detect";
      const newUrl = baseUrl + "&tab=" + tab;
      history.replaceState(null, "", newUrl);
    }
  };

  $.orderDetect.toggleOtpSettings = function () {
    const isChecked = $("#enable_otp").is(":checked");
    $("#order-detect-meta-checkout_otp_message").toggle(isChecked);
    $(".otp-dynamic-setting").toggle(isChecked);

    const isCheckedFooterText = $("#enable_footer_text").is(":checked");
    $("#order-detect-meta-footer_text_heading").toggle(isCheckedFooterText);
    $("#order-detect-meta-footer_text_details").toggle(isCheckedFooterText);
  };

  $(document).on("click", "#license-submit", function () {
    let license_key = $("#orderdetect_license_key").val();
    let $message = $(".order-detect-license-status");
    let that = $(this);
    if (license_key != "") {
      that.html(order_detect.loader);
      that.prop("disabled", true);
      $.ajax({
        type: "POST",
        dataType: "json",
        url: order_detect.ajax_url,
        data: {
          action: "license_activate",
          security: order_detect.nonce,
          license_key: license_key,
        },
        success: function (response, textStatus, jqXHR) {
          var statusCode = jqXHR.status;
          $message.removeClass(
            "order-detect-license-status-success order-detect-license-status-error"
          );
          if (statusCode === 200) {
            $message.addClass(response.class).text(response.message).show();
            that.html("");
            that.html(order_detect.activate);
            that.prop("disabled", false);
            setTimeout(function () {
              location.reload();
            }, 2000);
          } else {
            $message.addClass(response.class).text(response.message).show();
          }
        },
        error: function (jqXHR) {
          var response = jqXHR.responseJSON;
          $message.addClass(response.class).text(response.message).show();
          that.html("");
          that.html(order_detect.activate);
          that.prop("disabled", false);
        },
      });
    }
  });

  $(document).on("click", "#license-deactivate", function () {
    var confirmDeactivation = confirm(
      "Are you sure you want to deactivate the license key?"
    );
    if (!confirmDeactivation) {
      return;
    }
    let $message = $(".order-detect-license-status");
    let that = $(this);
    that.html(order_detect.loader);
    that.prop("disabled", true);
    $.ajax({
      type: "POST",
      dataType: "json",
      url: order_detect.ajax_url,
      data: {
        action: "license_deactivate",
        security: order_detect.nonce,
      },
      success: function (response, textStatus, jqXHR) {
        var statusCode = jqXHR.status;
        $message.removeClass(
          "order-detect-license-status-success order-detect-license-status-error"
        );
        if (statusCode === 200) {
          $message.addClass(response.class).text(response.message).show();
          that.html("");
          that.html(order_detect.activate);
          that.prop("disabled", false);
          setTimeout(function () {
            location.reload();
          }, 2000);
        } else {
          $message.addClass(response.class).text(response.message).show();
        }
      },
      error: function (jqXHR) {
        var response = jqXHR.responseJSON;
        $message.addClass(response.class).text(response.message).show();
        that.html("");
        that.html(order_detect.activate);
        that.prop("disabled", false);
      },
    });
  });

  $(document).on("click", "#provider-settings-save-btn", function (e) {
    let button = $(this);
    let sms_provider = $("#sms_provider").val();
    let sms_api_key = $("#sms_api_key").val();
    let dianahost_sender_id = $("#dianahost_sender_id").val();
    let mimsms_sender_id = $("#mimsms_sender_id").val();
    let mimsms_username = $("#mimsms_username").val();
    let bulksmsbd_sender_id = $("#bulksmsbd_sender_id").val();
    let data = {};

    // if (sms_provider === "" || typeof sms_provider === 'undefined' || sms_api_key === '') {
    // 	$("#sms_provider").focus();
    //alert('Please select a SMS Provider and API Key');
    // 	return;
    // }
    if (sms_provider === "" || typeof sms_provider === "undefined") {
      $("#enable_otp").prop("checked", false);
      $("#checkout_otp_message").hide();
      $(".order-detect-status-alert").each(function () {
        $(this).prop("checked", false);
      });
      $(".order-detect-status-checkbox[type=checkbox]").each(function () {
        var messageRow = $(this).closest("tr").next("tr");
        messageRow.hide();
      });
    }

    data = {
      action: "save_sms_provider_settings",
      sms_provider: sms_provider,
      sms_api_key: sms_api_key,
      dianahost_sender_id: dianahost_sender_id,
      mimsms_sender_id: mimsms_sender_id,
      mimsms_username: mimsms_username,
      bulksmsbd_sender_id: bulksmsbd_sender_id,
      security: order_detect.nonce,
    };

    if ("dianahost" === sms_provider && dianahost_sender_id === "") {
      alert("Sender Id is required");
      return;
    }
    if ("mimsms" === sms_provider && mimsms_sender_id === "") {
      alert("Sender Id is required");
      return;
    }
    if ("mimsms" === sms_provider && mimsms_username === "") {
      alert("User name is required");
      return;
    }
    if ("bulksmsbd" === sms_provider && bulksmsbd_sender_id === "") {
      alert("Sender Id is required");
      return;
    }

    if ("dianahost" === sms_provider && dianahost_sender_id !== "") {
      data["dianahost_sender_id"] = dianahost_sender_id;
    }
    if ("mimsms" === sms_provider && mimsms_sender_id !== "") {
      data["mimsms_sender_id"] = mimsms_sender_id;
    }
    if ("mimsms" === sms_provider && mimsms_username !== "") {
      data["mimsms_username"] = mimsms_username;
    }
    if ("bulksmsbd" === sms_provider && bulksmsbd_sender_id !== "") {
      data["bulksmsbd_sender_id"] = bulksmsbd_sender_id;
    }

    $.ajax({
      url: order_detect.ajax_url,
      type: "POST",
      dataType: "json",
      data: data,
      beforeSend: function () {
        button.attr("disabled", true);
        button.text("Saving...");
      },
      success: function (response) {
        if (response.success) {
          $("#sms-balance-show").text(response.data.balance);
          showToast(response.data.message);
        }
      },
      error: function (e, textStatus, errorThrown) {
        console.log("Error loading order");
        console.log("Error Status: " + textStatus);
        console.log("Error Thrown: " + errorThrown);
        console.log("Response Text: " + e.responseText);
        console.log("Error Object:", e);
        showToast(e.responseText);
      },
      complete: function () {
        button.attr("disabled", false);
        button.text("Save");
      },
    });
  });

  $(document).on("click", "#otp-settings-save-btn", function (e) {
    let button = $(this);
    let enable_otp = $("#enable_otp").is(":checked");
    let checkout_otp_message = $("#checkout_otp_message").val().trim();
    let otp_expiry_minutes = parseInt($("#otp_expiry_minutes").val(), 10) || 15;
    let otp_resend_countdown_seconds =
      parseInt($("#otp_resend_countdown_seconds").val(), 10) || 60;
    let otp_popup_title = $("#otp_popup_title").val().trim();
    let otp_processing_message = $("#otp_processing_message").val().trim();
    let otp_placeholder = $("#otp_placeholder").val().trim();
    let otp_verify_button_text = $("#otp_verify_button_text").val().trim();
    let otp_resend_button_text = $("#otp_resend_button_text").val().trim();
    let otp_resend_countdown_text = $("#otp_resend_countdown_text").val().trim();
    let otp_invalid_phone_message = $("#otp_invalid_phone_message").val().trim();
    let otp_try_again_text = $("#otp_try_again_text").val().trim();
    let otp_generic_error_message = $("#otp_generic_error_message").val().trim();
    let otp_sent_message = $("#otp_sent_message").val().trim();
    let otp_verified_message = $("#otp_verified_message").val().trim();
    let otp_invalid_code_message = $("#otp_invalid_code_message").val().trim();

    if (enable_otp) {
      if (!checkout_otp_message) {
        $("#checkout_otp_message").focus();
        return;
      }
    }

    otp_expiry_minutes = Math.min(Math.max(otp_expiry_minutes, 1), 60);
    otp_resend_countdown_seconds = Math.min(
      Math.max(otp_resend_countdown_seconds, 5),
      600
    );

    $("#otp_expiry_minutes").val(otp_expiry_minutes);
    $("#otp_resend_countdown_seconds").val(otp_resend_countdown_seconds);

    $.ajax({
      url: order_detect.ajax_url,
      type: "POST",
      dataType: "json",
      data: {
        action: "save_otp_setting",
        enable_otp: enable_otp ? 1 : 0,
        checkout_otp_message: checkout_otp_message,
        otp_expiry_minutes: otp_expiry_minutes,
        otp_resend_countdown_seconds: otp_resend_countdown_seconds,
        otp_popup_title: otp_popup_title,
        otp_processing_message: otp_processing_message,
        otp_placeholder: otp_placeholder,
        otp_verify_button_text: otp_verify_button_text,
        otp_resend_button_text: otp_resend_button_text,
        otp_resend_countdown_text: otp_resend_countdown_text,
        otp_invalid_phone_message: otp_invalid_phone_message,
        otp_try_again_text: otp_try_again_text,
        otp_generic_error_message: otp_generic_error_message,
        otp_sent_message: otp_sent_message,
        otp_verified_message: otp_verified_message,
        otp_invalid_code_message: otp_invalid_code_message,
        security: order_detect.nonce,
      },
      beforeSend: function () {
        button.attr("disabled", true);
        button.text("Saving...");
      },
      success: function (response) {
        if (response.success) {
          showToast(response.data.message);
        }
      },
      error: function (e, textStatus, errorThrown) {
        console.log("Error loading order");
        console.log("Error Status: " + textStatus);
        console.log("Error Thrown: " + errorThrown);
        console.log("Response Text: " + e.responseText);
        console.log("Error Object:", e);
        showToast(e.responseText);
      },
      complete: function () {
        button.attr("disabled", false);
        button.text("Save");
      },
    });
  });

  jQuery(document).ready(function ($) {
    $(".order-detect-status-checkbox[type=checkbox]").each(function () {
      var messageRow = $(this).closest("tr").next("tr");
      if (this.checked) {
        messageRow.show();
      } else {
        messageRow.hide();
      }
    });

    $(".order-detect-status-checkbox[type=checkbox]").change(function () {
      const sms_provider = $("#sms_provider").val();
      const sms_api_key = $("#sms_api_key").val();
      const dianahost_sender_id = $("#dianahost_sender_id").val();
      const mimsms_sender_id = $("#mimsms_sender_id").val();
      const mimsms_username = $("#mimsms_username").val();
      const bulksmsbd_sender_id = $("#bulksmsbd_sender_id").val();

      if (!sms_provider || !sms_api_key) {
        alert("Please select an SMS provider and enter the API key first.");
        this.checked = false;
        return false;
      }

      if (sms_provider === "dianahost" && !dianahost_sender_id) {
        alert("Please enter Dianahost Sender ID first.");
        this.checked = false;
        return false;
      }

      if (
        sms_provider === "mimsms" &&
        (!mimsms_sender_id || !mimsms_username)
      ) {
        alert("Please enter Mimsms Sender ID and Username first.");
        this.checked = false;
        return false;
      }

      if (sms_provider === "bulksmsbd" && !bulksmsbd_sender_id) {
        alert("Please enter Bulksmsbd Sender ID first.");
        this.checked = false;
        return false;
      }

      var messageRow = $(this).closest("tr").next("tr");
      if (this.checked) {
        messageRow.show();
      } else {
        messageRow.hide();
      }
    });
  });

  $(document).on("click", "#order-alerts-save-btn", function (e) {
    let button = $(this);
    let settingsData = {};
    let hasError = false;

    $(".order-detect-status-alert").each(function () {
      let fieldName = $(this).attr("name");
      if ($(this).is("textarea")) {
        settingsData[fieldName] = $(this).val();
        let checkbox = $(this)
          .closest("tr")
          .prev()
          .find(".order-detect-status-checkbox[type=checkbox]");
        if (checkbox.is(":checked") && !settingsData[fieldName]) {
          hasError = true;
          $(this).focus();
          return false;
        }
      }
      if ($(this).is(":checkbox")) {
        settingsData[fieldName] = $(this).is(":checked") ? 1 : 0;
      }
    });

    if (hasError) {
      return;
    }

    $.ajax({
      url: order_detect.ajax_url,
      type: "POST",
      dataType: "json",
      data: {
        action: "save_order_alerts",
        settings: settingsData,
        security: order_detect.nonce,
      },
      beforeSend: function () {
        button.attr("disabled", true);
        button.text("Saving...");
      },
      success: function (response) {
        if (response.success) {
          showToast(response.data.message);
        }
      },
      error: function (e, textStatus, errorThrown) {
        console.log("Error loading order");
        console.log("Error Status: " + textStatus);
        console.log("Error Thrown: " + errorThrown);
        console.log("Response Text: " + e.responseText);
        console.log("Error Object:", e);
        showToast(e.responseText);
      },
      complete: function () {
        button.attr("disabled", false);
        button.text("Save");
      },
    });
  });

  jQuery(document).ready(function ($) {
    $("#sms_provider").on("change", function () {
      var selectedOption = $(this).find("option:selected");
      var apiKey = selectedOption.attr("api_key");
      var smsBalance = selectedOption.attr("balance");
      $("#sms_api_key").val(apiKey);
      $("#sms-balance-show").text(smsBalance);
      if ($(this).val() === "dianahost") {
        $("#order-detect-meta-dianahost_sender_id").show();
      } else {
        $("#order-detect-meta-dianahost_sender_id").hide();
      }
      if ($(this).val() === "mimsms") {
        $("#order-detect-meta-mimsms_sender_id").show();
        $("#order-detect-meta-mimsms_username").show();
      } else {
        $("#order-detect-meta-mimsms_sender_id").hide();
        $("#order-detect-meta-mimsms_username").hide();
      }
      if ($(this).val() === "bulksmsbd") {
        $("#order-detect-meta-bulksmsbd_sender_id").show();
      } else {
        $("#order-detect-meta-bulksmsbd_sender_id").hide();
      }
    });
    $("#sms_provider").trigger("change");
  });

  function showToast(text) {
    Toastify({
      text: '<span class="dashicons dashicons-cloud-saved"></span> ' + text,
      duration: 1000,
      close: true,
      escapeMarkup: false,
      gravity: "bottom",
      position: "right",
      stopOnFocus: true,
      style: {
        background: "#F3793D",
        color: "#ffff",
      },
      onClick: function () {},
    }).showToast();
    setTimeout(() => {
      document.querySelectorAll(".toast-close img").forEach((img) => {
        img.src = order_detect.assetsURL + "/img/toast-close-button.svg";
      });
      document.querySelectorAll(".toastify").forEach((toast) => {
        toast.classList.add("toastify-bounce");
      });
    }, 0);
  }

  $(document).on("change", ".od_phone_number_status", function (e) {
    let select = $(this);
    let id = select.data("id");
    let status = select.val();

    if (id !== "") {
      $.ajax({
        url: order_detect.ajax_url,
        type: "POST",
        dataType: "json",
        data: {
          action: "update_phone_number_status",
          id: id,
          is_verified: status,
          security: order_detect.nonce,
        },
        beforeSend: function () {
          select.attr("disabled", true);
        },
        success: function (response) {
          select.prop("disabled", false);
          if (response.success) {
            showToast(response.data.message);
          }
        },
        error: function (e, textStatus, errorThrown) {
          select.prop("disabled", false);
          console.log("Error loading order");
          console.log("Error Status: " + textStatus);
          console.log("Error Thrown: " + errorThrown);
          console.log("Response Text: " + e.responseText);
          console.log("Error Object:", e);
        },
        complete: function () {
          select.prop("disabled", false);
        },
      });
    }
  });

  if ($.fn.wpColorPicker) {
    $(".od-color-field").wpColorPicker();
  }
})(jQuery);
