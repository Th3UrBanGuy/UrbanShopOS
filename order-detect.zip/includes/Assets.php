<?php

namespace OrderDetect;

class Assets {

    private $settings;

    function __construct() {
        $this->settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => '',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => '',
                'mimsms' => '',
                'bulksmsbd' => ''
            ),
            'mimsms_sender_id' => '',
            'mimsms_username' => '',
            'bulksmsbd_sender_id' => '',
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'otp_expiry_minutes' => 15,
            'otp_resend_countdown_seconds' => 60,
            'otp_popup_title' => 'Order Verification',
            'otp_processing_message' => 'Checking your phone number...',
            'otp_placeholder' => 'Enter OTP Code',
            'otp_verify_button_text' => 'Verify',
            'otp_resend_button_text' => 'Resend OTP',
            'otp_resend_countdown_text' => 'Didn\'t receive code? Resend in %time%',
            'otp_invalid_phone_message' => 'Please enter a valid Bangladeshi phone number. Example: 017XXXXXXXX.',
            'otp_try_again_text' => 'Try again',
            'otp_generic_error_message' => 'Something went wrong!',
            'otp_sent_message' => 'OTP has been sent to: %phone_number%',
            'otp_verified_message' => 'OTP verification successful!',
            'otp_invalid_code_message' => 'OTP verification failed. Invalid OTP.',
            'dianahost_sender_id' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));
        add_action('wp_enqueue_scripts', array($this, 'register_assets'));
        add_action('admin_enqueue_scripts', array($this, 'register_admin_assets'));
    }

    private function is_plugin_admin_screen($screen_id) {
        return $screen_id === 'toplevel_page_order-detect' || strpos($screen_id, 'order-detect_page_') === 0;
    }

    private function is_order_admin_screen($screen_id) {
        return in_array($screen_id, array('edit-shop_order', 'woocommerce_page_wc-orders', 'shop_order'), true);
    }

    public function get_scripts() {
        return array(
            'order-detect-script' => array(
                'src'     => ORDERDETECT_ASSETS . '/js/frontend.js',
                'version' => filemtime(ORDERDETECT_PATH . '/assets/js/frontend.js'),
                'deps'    => array('jquery'),
            ),
        );
    }

    public function get_styles() {
        return array(
            'order-detect-style' => array(
                'src'     => ORDERDETECT_ASSETS . '/css/frontend.css',
                'version' => filemtime(ORDERDETECT_PATH . '/assets/css/frontend.css'),
            ),

        );
    }

    public function register_assets() {

        if( ! Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
            return '';
        }
        
        $scripts = $this->get_scripts();
        $styles  = $this->get_styles();

        foreach ($scripts as $handle => $script) {
            $deps = isset($script['deps']) ? $script['deps'] : false;
            $type = isset($script['type']) ? $script['type'] : '';

            wp_enqueue_script($handle, $script['src'], $deps, $script['version'], true);
        }

        foreach ($styles as $handle => $style) {
            $deps = isset($style['deps']) ? $style['deps'] : false;

            wp_enqueue_style($handle, $style['src'], $deps, $style['version']);
        }

        wp_localize_script('order-detect-script', 'order_detect', array(
            'ajax_url'  => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('order-detect-nonce'),
            'loader' => '<div class="order-detect-loader"></div>',
            'resend_otp' => ! empty( $this->settings['otp_resend_button_text'] ) ? $this->settings['otp_resend_button_text'] : __('Resend OTP', 'order-detect'),
            'place_order' => __('Place Order', 'order-detect'),
            'verify' => ! empty( $this->settings['otp_verify_button_text'] ) ? $this->settings['otp_verify_button_text'] : __('Verify', 'order-detect'),
            'try_again' => ! empty( $this->settings['otp_try_again_text'] ) ? $this->settings['otp_try_again_text'] : __('Try again', 'order-detect'),
            'something_wrong' => ! empty( $this->settings['otp_generic_error_message'] ) ? $this->settings['otp_generic_error_message'] : __('Something went wrong!', 'order-detect'),
            'invalid_phone_message' => ! empty( $this->settings['otp_invalid_phone_message'] ) ? $this->settings['otp_invalid_phone_message'] : __('Please enter a valid Bangladeshi phone number. Example: 017XXXXXXXX.', 'order-detect'),
            'resend_countdown_text' => ! empty( $this->settings['otp_resend_countdown_text'] ) ? $this->settings['otp_resend_countdown_text'] : __('Didn\'t receive code? Resend in %time%', 'order-detect'),
            'settings' => $this->settings
        ));
    }

    public function get_admin_scripts() {
        return array(
            'order-detect-admin-script' => array(
                'src'     => ORDERDETECT_ASSETS . '/js/admin.js',
                'version' => filemtime(ORDERDETECT_PATH . '/assets/js/admin.js'),
                'deps'    => array('jquery'),
            ),
            'toastify-script' => array(
                'src'     => ORDERDETECT_ASSETS . '/lib/toastify/toastify.js',
                'version' => filemtime(ORDERDETECT_PATH . '/assets/lib/toastify/toastify.js'),
                'deps'    => array('order-detect-admin-script'),
            ),
        );
    }

    public function get_admin_styles() {
        return array(
            'orderdetect-admin-style' => array(
                'src'     => ORDERDETECT_ASSETS . '/css/admin.css',
                'version' => filemtime(ORDERDETECT_PATH . '/assets/css/admin.css'),
            ),
            'toastify-style' => array(
                'src'     => ORDERDETECT_ASSETS . '/lib/toastify/toastify.css',
                'version' => filemtime(ORDERDETECT_PATH . '/assets/lib/toastify/toastify.css'),
            ),
        );
    }

    public function register_admin_assets($hook) {
        $screen = get_current_screen();
        $screen_id = $screen ? $screen->id : '';

        if ( ! $this->is_plugin_admin_screen($screen_id) && ! $this->is_order_admin_screen($screen_id) ) {
            return;
        }

        $styles  = $this->get_admin_styles();

        if ( $this->is_order_admin_screen($screen_id) ) {
            if ( ! Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
                return;
            }

            wp_enqueue_style(
                'orderdetect-admin-style',
                $styles['orderdetect-admin-style']['src'],
                false,
                $styles['orderdetect-admin-style']['version']
            );

            return;
        }

		wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_media();
        $scripts = $this->get_admin_scripts();

        foreach ($scripts as $handle => $script) {
            $deps = isset($script['deps']) ? $script['deps'] : false;
            wp_enqueue_script($handle, $script['src'], $deps, $script['version'], true);
        }

        foreach ($styles as $handle => $style) {
            if ($handle === 'orderdetect-admin-style' && in_array($screen_id, ['order-detect_page_obn-blocklist', 'order-detect_page_obn-auto-blocklist', 'order-detect_page_otp-reports'], true)) {
                continue;
            }
            $deps = isset($style['deps']) ? $style['deps'] : false;

            wp_enqueue_style($handle, $style['src'], $deps, $style['version']);
        }

        wp_localize_script('order-detect-admin-script', 'order_detect', array(
            'ajax_url'  => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('order-detect-admin-nonce'),
            'nonces' => array(
                'od_packlist' => wp_create_nonce('order-detect'),
            ),
            'activate' => __('Activate', 'order-detect'),
            'deactivate' => __('Deactivate', 'order-detect'),
            'loader' => '<div class="order-detect-loader"></div>',
            'assetsURL' => ORDERDETECT_ASSETS,
        ));
    }
}
