<?php

namespace OrderDetect\Admin;

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/template.php';
    require_once ABSPATH . 'wp-admin/includes/class-wp-screen.php';
    require_once ABSPATH . 'wp-admin/includes/screen.php';
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class BlocklistList extends \WP_List_Table {

    public $search_query;
    public $type_filter;

    public function __construct() {
        parent::__construct([
            'singular' => 'block_entry',
            'plural'   => 'block_entries',
            'ajax'     => false,
        ]);

        $this->search_query = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        $this->type_filter  = isset($_GET['type']) ? sanitize_key(wp_unslash($_GET['type'])) : '';

        if (!in_array($this->type_filter, ['phone', 'ip', 'device'], true)) {
            $this->type_filter = '';
        }
    }

    public function get_columns() {
        return [
            'cb'         => '<input type="checkbox" />',
            'id'         => __('ID', 'order-detect'),
            'type'       => __('Type', 'order-detect'),
            'value'      => __('Value', 'order-detect'),
            'created_at' => __('Created At', 'order-detect'),
            'actions'    => __('Action', 'order-detect'),
        ];
    }

    protected function get_sortable_columns() {
        return [
            'id'         => ['id', true],
            'type'       => ['type', false],
            'created_at' => ['created_at', false],
        ];
    }

    protected function column_cb($item) {
        return sprintf(
            '<input type="checkbox" name="block_entry[]" value="%d" />',
            (int) $item->id
        );
    }

    protected function column_default($item, $column_name) {
        switch ($column_name) {
            case 'id':
                return (int) $item->id;
            case 'type':
                return esc_html($item->type);
            case 'value':
                return esc_html($item->value);
            case 'created_at':
                $created_ts = \obn_utc_datetime_to_timestamp($item->created_at);
                return esc_html($this->format_datetime($created_ts));
            case 'actions':
                return $this->get_action_link((int) $item->id);
            default:
                return '';
        }
    }

    protected function get_bulk_actions() {
        return [
            'unblock' => __('Unblock', 'order-detect'),
            'delete'  => __('Delete', 'order-detect'),
        ];
    }

    public function prepare_items() {
        $this->process_bulk_action();

        $per_page     = $this->get_items_per_page('obn_blocklist_per_page', 20);
        $current_page = $this->get_pagenum();
        $total_items  = $this->get_total_items();

        $this->items = $this->get_items($per_page, $current_page);

        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => (int) ceil($total_items / $per_page),
        ]);

        $this->_column_headers = [$this->get_columns(), [], $this->get_sortable_columns()];
    }

    protected function process_bulk_action() {
        $action = $this->current_action();
        if (!in_array($action, ['unblock', 'delete'], true)) {
            return;
        }

        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('You do not have permission to manage the blocklist.', 'order-detect'));
        }

        $ids = isset($_REQUEST['block_entry']) ? (array) wp_unslash($_REQUEST['block_entry']) : [];
        $ids = array_values(array_filter(array_map('absint', $ids)));

        if (!$ids) {
            return;
        }

        check_admin_referer('bulk-' . $this->_args['plural']);

        global $wpdb;
        $table        = $wpdb->prefix . 'obn_blocklist';
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        $wpdb->query($wpdb->prepare("DELETE FROM $table WHERE id IN ($placeholders)", $ids));

        wp_safe_redirect($this->get_redirect_url());
        exit;
    }

    protected function get_total_items() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'obn_blocklist';
        $query      = "SELECT COUNT(*) FROM $table_name";
        $where      = [];
        $params     = [];

        if ($this->search_query !== '') {
            $like    = '%' . $wpdb->esc_like($this->search_query) . '%';
            $where[] = '(type LIKE %s OR value LIKE %s)';
            $params[] = $like;
            $params[] = $like;
        }

        if ($this->type_filter !== '') {
            $where[] = 'type = %s';
            $params[] = $this->type_filter;
        }

        if ($where) {
            $query .= ' WHERE ' . implode(' AND ', $where);
        }

        if ($params) {
            return (int) $wpdb->get_var($wpdb->prepare($query, $params));
        }

        return (int) $wpdb->get_var($query);
    }

    protected function get_items($per_page, $current_page) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'obn_blocklist';
        $offset     = ($current_page - 1) * $per_page;
        $query      = "SELECT id, type, value, created_at FROM $table_name";
        $where      = [];
        $params     = [];

        if ($this->search_query !== '') {
            $like    = '%' . $wpdb->esc_like($this->search_query) . '%';
            $where[] = '(type LIKE %s OR value LIKE %s)';
            $params[] = $like;
            $params[] = $like;
        }

        if ($this->type_filter !== '') {
            $where[] = 'type = %s';
            $params[] = $this->type_filter;
        }

        if ($where) {
            $query .= ' WHERE ' . implode(' AND ', $where);
        }

        $query .= $wpdb->prepare(' ORDER BY created_at DESC LIMIT %d OFFSET %d', $per_page, $offset);

        if ($params) {
            $query = $wpdb->prepare($query, $params);
        }

        return $wpdb->get_results($query);
    }

    protected function get_action_link($id) {
        $args = [
            'page'        => 'obn-blocklist',
            'action'      => 'delete',
            'block_entry' => [$id],
        ];

        if ($this->search_query !== '') {
            $args['s'] = $this->search_query;
        }

        if ($this->type_filter !== '') {
            $args['type'] = $this->type_filter;
        }

        $url = wp_nonce_url(
            add_query_arg($args, admin_url('admin.php')),
            'bulk-' . $this->_args['plural']
        );

        return sprintf(
            '<a href="%s" class="button button-link-delete" onclick="return confirm(\'%s\');">%s</a>',
            esc_url($url),
            esc_js(__('Are you sure you want to unblock this value?', 'order-detect')),
            esc_html__('Unblock', 'order-detect')
        );
    }

    protected function format_datetime($timestamp) {
        if (!$timestamp) {
            return __('N/A', 'order-detect');
        }

        if (function_exists('wp_date')) {
            return wp_date('h:i:s A | d-M-Y', $timestamp);
        }

        return date_i18n('h:i:s A | d-M-Y', $timestamp);
    }

    protected function get_items_per_page($option, $default_value = 20) {
        $user_value = (int) get_user_meta(get_current_user_id(), $option, true);

        if ($user_value < 1) {
            return $default_value;
        }

        return $user_value;
    }

    protected function get_redirect_url() {
        $args = ['page' => 'obn-blocklist'];

        if ($this->search_query !== '') {
            $args['s'] = $this->search_query;
        }

        if ($this->type_filter !== '') {
            $args['type'] = $this->type_filter;
        }

        return add_query_arg($args, admin_url('admin.php'));
    }
}
