<div id="order-detect-otp_settings" class="order-detect-settings-tab">
    <div id="order-detect-settings-otp_settings" class="order-detect-settings-section order-detect-otp_settings">
        <table>
            <tbody>
                <tr class="order-detect-settings-group-heading">
                    <th colspan="2">
                        <span>Core OTP Settings</span>
                        <p>These settings control whether checkout OTP is enabled and what message is sent by SMS.</p>
                    </th>
                </tr>
                <tr data-id="enable_otp" id="order-detect-meta-enable_otp" class="order-detect-field order-detect-meta-checkbox type-checkbox">
                    <th class="order-detect-label">
                        <label for="enable_otp">
                            Enable
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <label class="order-detect-switch">
                                <input class="order-detect-settings-field" 
                                    id="enable_otp" 
                                    type="checkbox" 
                                    name="orderdetect_settings[enable_otp]" 
                                    value="1" 
                                <?php checked( isset($enable_otp) ? $enable_otp : 0, 1 ); ?>>
                                <div class="slider"></div>
                            </label>
                        </div>
                    </td>
                </tr>
                <tr data-id="checkout_otp_message" id="order-detect-meta-checkout_otp_message" class="order-detect-field order-detect-meta-textarea type-textarea ">
                    <th class="order-detect-label">
                        <label for="checkout_otp_message">
                            Checkout OTP Message                                                            
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <textarea class="order-detect-settings-field" id="checkout_otp_message" name="orderdetect_settings[checkout_otp_message]" placeholder="Checkout OPT Message" rows="4" cols="20" wrap="hard"><?php echo esc_attr( $checkout_otp_message ); ?></textarea>
                            <p class="order-detect-field-help">Example Format:
                                (Company Name)
                                আপনার ওটিপি: %otp_code%
                                @domain, #%otp_code%
                                Note: SMS Text এর শুরুতে অবশ্যই ব্রাকেট দিয়ে কোম্পানীর নাম/সাইট এড্রেস/ব্রান্ড নেম দিবেন, অনথ্যায় ওটিপি এসএমএস যাবে না। যেমনে, (Company Name) অথবা (কোম্পানীসাইট.কম)
                            </p>
                        </div>
                    </td>
                </tr>
                <tr data-id="otp_expiry_minutes" id="order-detect-meta-otp_expiry_minutes" class="order-detect-field order-detect-meta-text type-text otp-dynamic-setting">
                    <th class="order-detect-label">
                        <label for="otp_expiry_minutes">OTP Expiry (Minutes)</label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="otp_expiry_minutes" type="number" min="1" max="60" value="<?php echo esc_attr( $otp_expiry_minutes ); ?>">
                            <p class="order-detect-field-help">Set how long an OTP stays valid. Allowed range: 1 to 60 minutes.</p>
                        </div>
                    </td>
                </tr>
                <tr data-id="otp_resend_countdown_seconds" id="order-detect-meta-otp_resend_countdown_seconds" class="order-detect-field order-detect-meta-text type-text otp-dynamic-setting">
                    <th class="order-detect-label">
                        <label for="otp_resend_countdown_seconds">Resend Countdown (Seconds)</label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="otp_resend_countdown_seconds" type="number" min="5" max="600" value="<?php echo esc_attr( $otp_resend_countdown_seconds ); ?>">
                            <p class="order-detect-field-help">Set how long the popup waits before showing the resend button. Allowed range: 5 to 600 seconds.</p>
                        </div>
                    </td>
                </tr>
                <tr class="order-detect-settings-group-heading otp-dynamic-setting">
                    <th colspan="2">
                        <span>Popup Layout</span>
                        <p>These texts appear directly inside the checkout OTP popup interface.</p>
                    </th>
                </tr>
                <tr data-id="otp_popup_title" id="order-detect-meta-otp_popup_title" class="order-detect-field order-detect-meta-text type-text otp-dynamic-setting">
                    <th class="order-detect-label">
                        <label for="otp_popup_title">Popup Title</label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="otp_popup_title" type="text" value="<?php echo esc_attr( $otp_popup_title ); ?>" placeholder="Order Verification">
                        </div>
                    </td>
                </tr>
                <tr data-id="otp_processing_message" id="order-detect-meta-otp_processing_message" class="order-detect-field order-detect-meta-text type-text otp-dynamic-setting">
                    <th class="order-detect-label">
                        <label for="otp_processing_message">Processing Message</label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="otp_processing_message" type="text" value="<?php echo esc_attr( $otp_processing_message ); ?>" placeholder="Checking your phone number...">
                        </div>
                    </td>
                </tr>
                <tr data-id="otp_placeholder" id="order-detect-meta-otp_placeholder" class="order-detect-field order-detect-meta-text type-text otp-dynamic-setting">
                    <th class="order-detect-label">
                        <label for="otp_placeholder">OTP Placeholder</label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="otp_placeholder" type="text" value="<?php echo esc_attr( $otp_placeholder ); ?>" placeholder="Enter OTP Code">
                        </div>
                    </td>
                </tr>
                <tr data-id="otp_verify_button_text" id="order-detect-meta-otp_verify_button_text" class="order-detect-field order-detect-meta-text type-text otp-dynamic-setting">
                    <th class="order-detect-label">
                        <label for="otp_verify_button_text">Verify Button Text</label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="otp_verify_button_text" type="text" value="<?php echo esc_attr( $otp_verify_button_text ); ?>" placeholder="Verify">
                        </div>
                    </td>
                </tr>
                <tr data-id="otp_resend_button_text" id="order-detect-meta-otp_resend_button_text" class="order-detect-field order-detect-meta-text type-text otp-dynamic-setting">
                    <th class="order-detect-label">
                        <label for="otp_resend_button_text">Resend Button Text</label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="otp_resend_button_text" type="text" value="<?php echo esc_attr( $otp_resend_button_text ); ?>" placeholder="Resend OTP">
                        </div>
                    </td>
                </tr>
                <tr data-id="otp_resend_countdown_text" id="order-detect-meta-otp_resend_countdown_text" class="order-detect-field order-detect-meta-text type-text otp-dynamic-setting">
                    <th class="order-detect-label">
                        <label for="otp_resend_countdown_text">Resend Countdown Text</label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="otp_resend_countdown_text" type="text" value="<?php echo esc_attr( $otp_resend_countdown_text ); ?>" placeholder="Didn't receive code? Resend in %time%">
                            <p class="order-detect-field-help">Use <code>%time%</code> where the countdown should appear.</p>
                        </div>
                    </td>
                </tr>
                <tr class="order-detect-settings-group-heading otp-dynamic-setting">
                    <th colspan="2">
                        <span>Popup Messages</span>
                        <p>Use placeholders where needed: <code>%time%</code> for countdown and <code>%phone_number%</code> for the customer phone.</p>
                    </th>
                </tr>
                <tr data-id="otp_invalid_phone_message" id="order-detect-meta-otp_invalid_phone_message" class="order-detect-field order-detect-meta-text type-text otp-dynamic-setting">
                    <th class="order-detect-label">
                        <label for="otp_invalid_phone_message">Invalid Phone Message</label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="otp_invalid_phone_message" type="text" value="<?php echo esc_attr( $otp_invalid_phone_message ); ?>" placeholder="Please enter a valid Bangladeshi phone number.">
                        </div>
                    </td>
                </tr>
                <tr data-id="otp_try_again_text" id="order-detect-meta-otp_try_again_text" class="order-detect-field order-detect-meta-text type-text otp-dynamic-setting">
                    <th class="order-detect-label">
                        <label for="otp_try_again_text">Try Again Button Text</label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="otp_try_again_text" type="text" value="<?php echo esc_attr( $otp_try_again_text ); ?>" placeholder="Try again">
                        </div>
                    </td>
                </tr>
                <tr data-id="otp_generic_error_message" id="order-detect-meta-otp_generic_error_message" class="order-detect-field order-detect-meta-text type-text otp-dynamic-setting">
                    <th class="order-detect-label">
                        <label for="otp_generic_error_message">Generic Error Message</label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="otp_generic_error_message" type="text" value="<?php echo esc_attr( $otp_generic_error_message ); ?>" placeholder="Something went wrong!">
                        </div>
                    </td>
                </tr>
                <tr data-id="otp_sent_message" id="order-detect-meta-otp_sent_message" class="order-detect-field order-detect-meta-text type-text otp-dynamic-setting">
                    <th class="order-detect-label">
                        <label for="otp_sent_message">OTP Sent Message</label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="otp_sent_message" type="text" value="<?php echo esc_attr( $otp_sent_message ); ?>" placeholder="OTP has been sent to: %phone_number%">
                            <p class="order-detect-field-help">Use <code>%phone_number%</code> to show the customer phone number.</p>
                        </div>
                    </td>
                </tr>
                <tr data-id="otp_verified_message" id="order-detect-meta-otp_verified_message" class="order-detect-field order-detect-meta-text type-text otp-dynamic-setting">
                    <th class="order-detect-label">
                        <label for="otp_verified_message">Verify Success Message</label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="otp_verified_message" type="text" value="<?php echo esc_attr( $otp_verified_message ); ?>" placeholder="OTP verification successful!">
                        </div>
                    </td>
                </tr>
                <tr data-id="otp_invalid_code_message" id="order-detect-meta-otp_invalid_code_message" class="order-detect-field order-detect-meta-text type-text otp-dynamic-setting">
                    <th class="order-detect-label">
                        <label for="otp_invalid_code_message">Invalid Code Message</label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="otp_invalid_code_message" type="text" value="<?php echo esc_attr( $otp_invalid_code_message ); ?>" placeholder="OTP verification failed. Invalid OTP.">
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
        <p class="submit">
            <button type="button" name="otp-settings-save-btn" id="otp-settings-save-btn" class="btn-settings order-detect-settings-button">
                <span class="dashicons dashicons-cloud-saved"></span> Save
            </button>
        </p>
    </div>
</div>
