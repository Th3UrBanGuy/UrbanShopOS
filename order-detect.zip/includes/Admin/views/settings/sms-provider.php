<div id="order-detect-provider_settings" class="order-detect-settings-tab">
    <div id="order-detect-settings-provider_settings" class="order-detect-settings-section order-detect-provider_settings">
        <table>
            <tbody>
                <tr data-id="sms_provider" id="order-detect-meta-sms_provider" class="order-detect-field order-detect-meta-checkbox type-checkbox">
                    <th class="order-detect-label">
                        <label for="sms_provider">
                            SMS Provider
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <select id="sms_provider" name="orderdetect_settings[sms_provider]">
                                <option value="" api_key="" balance="0.00">Select SMS Provider</option>
                                <option value="greenweb" api_key="<?php echo esc_attr($sms_api_key['greenweb']); ?>" balance="<?php echo esc_attr($balance['greenweb']); ?>" <?php selected($sms_provider, 'greenweb'); ?>>Greenweb</option>
                                <option value="alpha" api_key="<?php echo esc_attr($sms_api_key['alpha']); ?>" balance="<?php echo esc_attr($balance['alpha']); ?>" <?php selected($sms_provider, 'alpha'); ?>>Alpha SMS</option>
                                <option value="dianahost" api_key="<?php echo esc_attr($sms_api_key['dianahost']); ?>" balance="<?php echo esc_attr($balance['dianahost']); ?>" <?php selected($sms_provider, 'dianahost'); ?>>Dianahost</option>
                                <option value="mimsms" api_key="<?php echo esc_attr($sms_api_key['mimsms']); ?>" balance="<?php echo esc_attr($balance['mimsms']); ?>" <?php selected($sms_provider, 'mimsms'); ?>>Mimsms</option>
                                <option value="bulksmsbd" api_key="<?php echo esc_attr($sms_api_key['bulksmsbd']); ?>" balance="<?php echo esc_attr($balance['bulksmsbd']); ?>" <?php selected($sms_provider, 'bulksmsbd'); ?>>Bulksmsbd</option>
                            </select>
                        </div>
                    </td>
                </tr>
                <tr data-id="sms_api_key" id="order-detect-meta-sms_api_key" class="order-detect-field order-detect-meta-text type-text ">
                    <th class="order-detect-label">
                        <label for="sms_api_key">
                            API Key
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="sms_api_key" type="text" name="orderdetect_settings[sms_api_key]" value="<?php echo esc_attr($sms_api_key[$sms_provider]); ?>" placeholder="SMS Provider API Key">
                            <span class="toggle-visibility" onclick="toggleVisibility('sms_api_key')" style="cursor: pointer;">
                                <i class="dashicons dashicons-hidden"></i>
                            </span>
                            <p class="order-detect-field-help">Set SMS Provider API Key</p>
                        </div>
                    </td>
                </tr>

                <tr data-id="dianahost_sender_id" id="order-detect-meta-dianahost_sender_id" class="order-detect-field order-detect-meta-text type-text " style="<?php if ("dianahost" === $sms_provider) { echo "display:contents;"; } ?>">
                    <th class="order-detect-label">
                        <label for="dianahost_sender_id">
                            Sender Id
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="dianahost_sender_id" type="text" name="orderdetect_settings[dianahost_sender_id]" value="<?php echo esc_attr($setting_options['dianahost_sender_id']); ?>" placeholder="Sender Id">
                            <span class="toggle-visibility" onclick="toggleVisibility('dianahost_sender_id')" style="cursor: pointer;">
                                <i class="dashicons dashicons-hidden"></i>
                            </span>
                            <p class="order-detect-field-help">Set Sender Id</p>
                        </div>
                    </td>
                </tr>

                <tr data-id="mimsms_username" id="order-detect-meta-mimsms_username" class="order-detect-field order-detect-meta-text type-text " style="<?php if ("mimsms" === $sms_provider) { echo "display:;"; } ?>">
                    <th class="order-detect-label">
                        <label for="mimsms_username">
                            User Name
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="mimsms_username" type="text" autocomplete="email" name="orderdetect_settings[mimsms_username]" value="<?php echo esc_attr($setting_options['mimsms_username']); ?>" placeholder="User Name">
                            <span class="toggle-visibility" onclick="toggleVisibility('mimsms_username')" style="cursor: pointer;">
                                <i class="dashicons dashicons-hidden"></i>
                            </span>
                            <p class="order-detect-field-help">Set User Name</p>
                        </div>
                    </td>
                </tr>
                <tr data-id="mimsms_sender_id" id="order-detect-meta-mimsms_sender_id" class="order-detect-field order-detect-meta-text type-text " style="<?php if ("mimsms" === $sms_provider) { echo "display:contents;"; } ?>">
                    <th class="order-detect-label">
                        <label for="mimsms_sender_id">
                            Sender Id
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="mimsms_sender_id" type="text" name="orderdetect_settings[mimsms_sender_id]" value="<?php echo esc_attr($setting_options['mimsms_sender_id']); ?>" placeholder="Sender Id">
                            <span class="toggle-visibility" onclick="toggleVisibility('mimsms_sender_id')" style="cursor: pointer;">
                                <i class="dashicons dashicons-hidden"></i>
                            </span>
                            <p class="order-detect-field-help">Set Sender Id</p>
                        </div>
                    </td>
                </tr>

                <tr data-id="bulksmsbd_sender_id" id="order-detect-meta-bulksmsbd_sender_id" class="order-detect-field order-detect-meta-text type-text " style="<?php if ("bulksmsbd" === $sms_provider) { echo "display:contents;"; } ?>">
                    <th class="order-detect-label">
                        <label for="bulksmsbd_sender_id">
                            Sender Id
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input class="order-detect-settings-field" id="bulksmsbd_sender_id" type="text" name="orderdetect_settings[bulksmsbd_sender_id]" value="<?php echo esc_attr($setting_options['bulksmsbd_sender_id']); ?>" placeholder="Sender Id">
                            <span class="toggle-visibility" onclick="toggleVisibility('bulksmsbd_sender_id')" style="cursor: pointer;">
                                <i class="dashicons dashicons-hidden"></i>
                            </span>
                            <p class="order-detect-field-help">Set Sender Id</p>
                        </div>
                    </td>
                </tr>

                <tr data-id="sms_balance" id="order-detect-meta-sms_balance" class="order-detect-field order-detect-meta-html type-html ">
                    <th class="order-detect-label">
                        <label for="sms_balance">
                            SMS Balance
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <span style="font-size: 16px;font-weight:600" id="sms-balance-show">
                                <?php
                                    $sms_balance = isset($balance[$sms_provider]) ? $balance[$sms_provider] : '0.00';
                                    echo !empty($sms_balance) ? $sms_balance : '0.00';
                                ?>
                            </span>
                            <p class="order-detect-field-help">Your current sms balance</p>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
        <p class="submit">
            <button type="button" name="provider-settings-save-btn" id="provider-settings-save-btn" class="btn-settings order-detect-settings-button">
                <span class="dashicons dashicons-cloud-saved"></span> Save
            </button>
        </p>
    </div>
</div>
