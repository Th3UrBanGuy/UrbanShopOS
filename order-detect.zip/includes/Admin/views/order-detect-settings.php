<?php

    $license_options = wp_parse_args(get_option('orderdetect_license'));
    $license_key = array_key_exists('key', $license_options) ? $license_options['key'] : '';
    $license_expires = array_key_exists('expires', $license_options) ? $license_options['expires'] : '';
    $license_active = $helper::check_license( $license_options );

    $setting_options = wp_parse_args(get_option($this->_optionName), $this->_defaultOptions);
    $sms_provider = $setting_options['sms_provider'] ? $setting_options['sms_provider'] : '';
    $sms_api_key = $setting_options['sms_api_key'] ? $setting_options['sms_api_key'] : array(
        'greenweb' => '',
        'alpha' => '',
        'dianahost' => '',
        'mimsms' => '',
        'bulksmsbd' => ''
    );
    $enable_otp = $setting_options['enable_otp'] ? $setting_options['enable_otp'] : '0';
    $checkout_otp_message = $setting_options['checkout_otp_message'] ? $setting_options['checkout_otp_message'] : '';
    $otp_expiry_minutes = ! empty( $setting_options['otp_expiry_minutes'] ) ? (int) $setting_options['otp_expiry_minutes'] : 15;
    $otp_resend_countdown_seconds = ! empty( $setting_options['otp_resend_countdown_seconds'] ) ? (int) $setting_options['otp_resend_countdown_seconds'] : 60;
    $otp_popup_title = ! empty( $setting_options['otp_popup_title'] ) ? $setting_options['otp_popup_title'] : 'Order Verification';
    $otp_processing_message = ! empty( $setting_options['otp_processing_message'] ) ? $setting_options['otp_processing_message'] : 'Checking your phone number...';
    $otp_placeholder = ! empty( $setting_options['otp_placeholder'] ) ? $setting_options['otp_placeholder'] : 'Enter OTP Code';
    $otp_verify_button_text = ! empty( $setting_options['otp_verify_button_text'] ) ? $setting_options['otp_verify_button_text'] : 'Verify';
    $otp_resend_button_text = ! empty( $setting_options['otp_resend_button_text'] ) ? $setting_options['otp_resend_button_text'] : 'Resend OTP';
    $otp_resend_countdown_text = ! empty( $setting_options['otp_resend_countdown_text'] ) ? $setting_options['otp_resend_countdown_text'] : 'Didn\'t receive code? Resend in %time%';
    $otp_invalid_phone_message = ! empty( $setting_options['otp_invalid_phone_message'] ) ? $setting_options['otp_invalid_phone_message'] : 'Please enter a valid Bangladeshi phone number. Example: 017XXXXXXXX.';
    $otp_try_again_text = ! empty( $setting_options['otp_try_again_text'] ) ? $setting_options['otp_try_again_text'] : 'Try again';
    $otp_generic_error_message = ! empty( $setting_options['otp_generic_error_message'] ) ? $setting_options['otp_generic_error_message'] : 'Something went wrong!';
    $otp_sent_message = ! empty( $setting_options['otp_sent_message'] ) ? $setting_options['otp_sent_message'] : 'OTP has been sent to: %phone_number%';
    $otp_verified_message = ! empty( $setting_options['otp_verified_message'] ) ? $setting_options['otp_verified_message'] : 'OTP verification successful!';
    $otp_invalid_code_message = ! empty( $setting_options['otp_invalid_code_message'] ) ? $setting_options['otp_invalid_code_message'] : 'OTP verification failed. Invalid OTP.';
    
    $delivery_partner = $setting_options['delivery_partner'] ? $setting_options['delivery_partner'] : '';
    $business_name = $setting_options['business_name'] ? $setting_options['business_name'] : get_bloginfo('name');
    $enable_footer_text = $setting_options['enable_footer_text'] ? $setting_options['enable_footer_text'] : '0';
    $footer_text_heading = $setting_options['footer_text_heading'] ? $setting_options['footer_text_heading'] : '';
    $footer_text_details = $setting_options['footer_text_details'] ? $setting_options['footer_text_details'] : '';
    $primary_color = $setting_options['primary_color'] ? $setting_options['primary_color'] : '';

    $balance = wp_parse_args( get_option('orderdetect_sms_balance', ['greenweb' => 0.00, 'alpha' => 0.00, 'dianahost' => 0.00, 'mimsms' => 0.00, 'bulksmsbd' => 0.00]));
?>
<div class="order-detect-settings-wrap">
    <div class="order-detect-settings-header">
        <div class="order-detect-header-full">
            <img src="<?php echo ORDERDETECT_ASSETS ?>/img/order-detect-logo.png" alt="Order Detect">
            <h2 class="title"><?php _e('Order Detect', 'order-detect'); ?></h2>
        </div>
    </div>

    <div class="order-detect-left-right-settings">
        <div class="order-detect-settings">

            <?php include_once 'settings/navbar.php'; ?>

            <div class="order-detect-settings-content">
                <div class="order-detect-settings-form-wrapper">
                    <?php include_once 'settings/license.php'; ?>
                    <?php if ( $license_active ) { ?>
                        <?php include_once 'settings/sms-provider.php'; ?>
                        <?php include_once 'settings/checkout-otp.php'; ?>
                        <?php include_once 'settings/order-notifications.php'; ?>
                    <?php } ?>
                </div>
            </div>
            <?php if ( $license_active ) { ?>
                <?php include_once 'settings/footer.php'; ?>
            <?php } ?>
        </div>
    </div>
</div>
<script>
    function toggleVisibility(id) {
        const inputField = document.getElementById(id);
        const toggle = inputField ? inputField.parentElement.querySelector('.toggle-visibility .dashicons') : null;

        if (!inputField || !toggle) {
            return;
        }

        if (inputField.type === 'password') {
            inputField.type = 'text';
            toggle.classList.remove('dashicons-hidden');
            toggle.classList.add('dashicons-visibility');
        } else {
            inputField.type = 'password';
            toggle.classList.remove('dashicons-visibility');
            toggle.classList.add('dashicons-hidden');
        }
    }
    toggleVisibility('sms_api_key');
    toggleVisibility('dianahost_sender_id');
    toggleVisibility('mimsms_sender_id');
    toggleVisibility('mimsms_username');
    toggleVisibility('bulksmsbd_sender_id');
</script>
