<?php

namespace OrderDetect\Admin;

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/template.php';
    require_once ABSPATH . 'wp-admin/includes/class-wp-screen.php';
    require_once ABSPATH . 'wp-admin/includes/screen.php';
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class OTPReportsList extends \WP_List_Table {

    public $phone_number;

    public function __construct($phone_number) {
        parent::__construct([
            'singular' => 'otp_report',
            'plural' => 'otp_reports',
            'ajax' => false,
        ]);
        $this->phone_number = $phone_number;
    }

    public function get_columns() {
        $columns = [
            'cb' => '<input type="checkbox" />',
            'id' => __('ID', 'order-detect'),
            'phone_number' => __('Phone Number', 'order-detect'),
            'code' => __('Code', 'order-detect'),
            'expires_at' => __('Expires At', 'order-detect'),
            'is_verified' => __('Verified?', 'order-detect'),
            'created_at' => __('Created At', 'order-detect'),
        ];
        return $columns;
    }

    protected function column_default($item, $column_name) {
        switch ($column_name) {
            case 'id':
                return $item->id;
            case 'phone_number':
                return $item->phone_number;
            case 'code':
                return $item->code;
            case 'expires_at':
                return $this->format_report_datetime($item->expires_at);
            case 'is_verified':
                $html = '<select name="is_verified[' . esc_attr($item->id) . ']" id="is_verified_' . esc_attr($item->id) . '" class="od_phone_number_status" data-id="' . esc_attr($item->id) . '">';
                $html .= '<option value="1"' . selected(1, $item->is_verified, false) . '>' . __('Yes', 'order-detect') . '</option>';
                $html .= '<option value="0"' . selected(0, $item->is_verified, false) . '>' . __('No', 'order-detect') . '</option>';
                $html .= '</select>';
                return $html;
            case 'created_at':
                return $this->format_report_datetime($item->created_at);
            default:
                return print_r($item, true);
        }
    }

    protected function column_cb($item) {
        return sprintf('<input type="checkbox" name="otp_report[]" value="%s" />', $item->id);
    }

    public function get_sortable_columns() {
        $sortable_columns = [
            'id' => ['id', true],
            'phone_number' => ['phone_number', true],
            'code' => ['code', false],
            'expires_at' => ['expires_at', false],
            'is_verified' => ['is_verified', false],
            'created_at' => ['created_at', false]
        ];
        return $sortable_columns;
    }

    public function get_bulk_actions() {
        $actions = [
            'delete' => __('Delete', 'order-detect'),
            'mark_as_verified' => __('Mark as Verified', 'order-detect'),
            'mark_as_unverified' => __('Mark as Unverified', 'order-detect'),
        ];
        return $actions;
    }

    public function process_bulk_action() {
        $action = $this->current_action();
        if ( ! in_array( $action, array( 'delete', 'mark_as_verified', 'mark_as_unverified' ), true ) ) {
            return;
        }

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to manage OTP reports.', 'order-detect' ) );
        }

        check_admin_referer( 'bulk-' . $this->_args['plural'] );

        $ids = isset($_REQUEST['otp_report']) ? wp_unslash($_REQUEST['otp_report']) : [];
        if (is_array($ids)) {
            $ids = array_map('intval', $ids);
        }

        if (!empty($ids)) {
            if ('delete' === $action) {
                $this->delete_items($ids);
            } elseif ('mark_as_verified' === $action) {
                $this->update_verification_status($ids, 1); // Mark as verified
            } elseif ('mark_as_unverified' === $action) {
                $this->update_verification_status($ids, 0); // Mark as unverified
            }
        }
    }

    public function delete_items($ids) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'od_otp_log';
        $ids_format = implode(',', array_fill(0, count($ids), '%d'));

        $wpdb->query($wpdb->prepare("DELETE FROM $table_name WHERE id IN ($ids_format)", $ids));
    }

    public function update_verification_status($ids, $status) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'od_otp_log';
        $ids_format = implode(',', array_fill(0, count($ids), '%d'));

        $wpdb->query($wpdb->prepare(
            "UPDATE $table_name SET is_verified = %d WHERE id IN ($ids_format)",
            $status,
            ...$ids
        ));
    }

    public function get_items_per_page($option, $default = 20) {
        $user_per_page = (int) get_user_meta(get_current_user_id(), $option, true);
        if (empty($user_per_page) || $user_per_page < 1) {
            $user_per_page = $default;
        }
        return $user_per_page;
    }

    public function get_views() {
        $current_view = isset($_REQUEST['status']) ? sanitize_text_field(wp_unslash($_REQUEST['status'])) : 'all';
        $page_url = admin_url('admin.php?page=' . ( isset($_REQUEST['page']) ? sanitize_key(wp_unslash($_REQUEST['page'])) : 'otp-reports' ));

        $all_count = $this->get_total_items();
        $verified_count = $this->get_total_items('verified');
        $unverified_count = $this->get_total_items('unverified');

        $views = [
            'all' => sprintf(
                '<a href="%s" %s>%s</a>',
                esc_url(add_query_arg('status', 'all', $page_url)),
                ($current_view === 'all') ? 'class="current"' : '',
                __('All', 'order-detect') . ' (' . $all_count . ')'
            ),
            'verified' => sprintf(
                '<a href="%s" %s>%s</a>',
                esc_url(add_query_arg('status', 'verified', $page_url)),
                ($current_view === 'verified') ? 'class="current"' : '',
                __('Verified', 'order-detect') . ' (' . $verified_count . ')'
            ),
            'unverified' => sprintf(
                '<a href="%s" %s>%s</a>',
                esc_url(add_query_arg('status', 'unverified', $page_url)),
                ($current_view === 'unverified') ? 'class="current"' : '',
                __('Unverified', 'order-detect') . ' (' . $unverified_count . ')'
            ),
        ];

        return $views;
    }

    public function prepare_items() {
        $this->process_bulk_action();

        $status = isset($_REQUEST['status']) ? sanitize_text_field(wp_unslash($_REQUEST['status'])) : 'all';
        $search = isset($_REQUEST['s']) ? sanitize_text_field(wp_unslash($_REQUEST['s'])) : '';

        $per_page = $this->get_items_per_page('otp_reports_per_page', 20);
        $current_page = $this->get_pagenum();
        $total_items = $this->get_total_items($status, $search);

        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page' => $per_page,
            'total_pages' => ceil($total_items / $per_page),
        ]);

        $otp_reports = $this->get_otp_reports_by_phone_number($per_page, $current_page, $status, $search );
        $this->items = $otp_reports;

        $columns = $this->get_columns();
        $hidden = [];
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = [$columns, $hidden, $sortable];
    }

    public function get_total_items($status = 'all', $search = '') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'od_otp_log';

        $query = "SELECT COUNT(*) FROM $table_name WHERE 1=1";

        if (!empty($search)) {
            $query .= $wpdb->prepare(" AND phone_number LIKE %s", '%' . $wpdb->esc_like($search) . '%');
        }

        if ($status === 'verified') {
            $query .= " AND is_verified = 1";
        } elseif ($status === 'unverified') {
            $query .= " AND is_verified = 0";
        }

        return (int) $wpdb->get_var($query);
    }

    public function get_otp_reports_by_phone_number($per_page, $current_page, $status = 'all', $phone_number = '') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'od_otp_log';

        $offset = ($current_page - 1) * $per_page;

        $query = "SELECT id, phone_number, code, expires_at, is_verified, created_at FROM $table_name WHERE 1=1";

        if (!empty($phone_number)) {
            $query .= $wpdb->prepare(" AND phone_number LIKE %s", '%' . $wpdb->esc_like($phone_number) . '%');
        }

        if ($status === 'verified') {
            $query .= " AND is_verified = 1";
        } elseif ($status === 'unverified') {
            $query .= " AND is_verified = 0";
        }

        $query .= $wpdb->prepare(" ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, $offset);

        return $wpdb->get_results($query);
    }

    protected function format_report_datetime($datetime) {
        if (empty($datetime)) {
            return __('N/A', 'order-detect');
        }

        $timezone = $this->get_site_timezone();
        $date = \DateTime::createFromFormat('Y-m-d H:i:s', $datetime, $timezone);

        if (!$date) {
            return __('N/A', 'order-detect');
        }

        return $date->format('F j, Y, g:i A');
    }

    protected function get_site_timezone() {
        if (function_exists('wp_timezone')) {
            return wp_timezone();
        }

        $timezone_string = get_option('timezone_string');
        if (!empty($timezone_string)) {
            return new \DateTimeZone($timezone_string);
        }

        $offset = (float) get_option('gmt_offset', 0);
        $hours = (int) $offset;
        $minutes = (int) round(abs($offset - $hours) * 60);
        $sign = ($offset < 0) ? '-' : '+';

        return new \DateTimeZone(sprintf('%s%02d:%02d', $sign, abs($hours), $minutes));
    }
}
