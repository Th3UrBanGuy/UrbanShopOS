<?php

namespace OrderDetect\Admin;

use OrderDetect\Helper;

class OTPReports {

    public $main;

    public function __construct($main) {
        $this->main = $main;
        add_filter( 'orderdetect_admin_menu', array( $this, 'register_otp_reports_page' ), PHP_INT_MAX );
        add_filter( 'set-screen-option', array( $this, 'set_screen_option' ), 10, 3 );
        add_action( 'load-order-detect_page_otp-reports', array( $this, 'add_screen_options' ) );
    }

    public function register_otp_reports_page( $settings ) {
        if( ! Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
            return $settings;
        }
        
        $settings['otp-reports']['parent_slug'] = 'order-detect';
        $settings['otp-reports']['page_title'] = __( 'Otp Reports', 'order-detect' );
        $settings['otp-reports']['menu_title'] = __( 'Otp Reports', 'order-detect' );
        $settings['otp-reports']['capability'] = 'manage_woocommerce';
        $phone_number = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
        $otp_reports_list_table = new OTPReportsList( $phone_number );

        $settings['otp-reports']['callback'] = function () use ( $otp_reports_list_table ) {
            $search_value = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
            $status_value = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
            ?>
            <div class="wrap">
                <h1><?php echo esc_html__( 'Otp Reports', 'order-detect' ); ?></h1>
                <form method="get">
                    <input type="hidden" name="page" value="otp-reports" />
                    <?php if ( $status_value !== '' ) { ?>
                        <input type="hidden" name="status" value="<?php echo esc_attr( $status_value ); ?>" />
                    <?php } ?>
                    <div class="tablenav top">
                        <p class="search-box">
                            <label class="screen-reader-text" for="otp-reports-search-input"><?php esc_html_e( 'Search OTP Reports', 'order-detect' ); ?></label>
                            <input type="search" id="otp-reports-search-input" name="s" value="<?php echo esc_attr( $search_value ); ?>" />
                            <input type="submit" id="search-submit" class="button" value="<?php echo esc_attr__( 'Search', 'order-detect' ); ?>" />
                        </p>
                        <br class="clear">
                    </div>
                </form>
                <form method="post">
                    <input type="hidden" name="page" value="otp-reports" />
                    <?php if ( $search_value !== '' ) { ?>
                        <input type="hidden" name="s" value="<?php echo esc_attr( $search_value ); ?>" />
                    <?php } ?>
                    <?php if ( $status_value !== '' ) { ?>
                        <input type="hidden" name="status" value="<?php echo esc_attr( $status_value ); ?>" />
                    <?php } ?>
                    <?php wp_nonce_field( 'bulk-otp_reports' ); ?>
                    <?php
                        $otp_reports_list_table->prepare_items();
                        $otp_reports_list_table->views();
                        $otp_reports_list_table->display();
                    ?>
                </form>
            </div>
            <?php
        };

        return $settings;
    }

    public function set_screen_option($status, $option, $value) {
        if (in_array($option, array('otp_reports_per_page'), true)) {
            return $value;
        }

        return $status;
    }

    public function add_screen_options() {
        add_screen_option('per_page', array(
            'label'   => esc_html__('Number of items per page:', 'order-detect'),
            'default' => 20,
            'option'  => 'otp_reports_per_page',
        ));
    }
}
