<?php

namespace OrderDetect\Admin;

use OrderDetect\Helper;

class Menu {

    public $main;

    function __construct($main) {
        $this->main = $main;
        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
    }

    public function admin_menu() {
        $parent_slug = 'order-detect';
        $capability = 'manage_woocommerce';
        $icon_url = ORDERDETECT_ASSETS.'/img/order-detect-icon.png';

        add_menu_page(__('Order Detect', 'order-detect'), __('Order Detect', 'order-detect'), $capability, $parent_slug, [$this->main, 'plugin_page'], $icon_url, 50);

        if (! Helper::check_license(wp_parse_args(get_option('orderdetect_license')))) {
            return;
        }

        $settings = apply_filters('orderdetect_admin_menu', array());

        if ( ! empty($settings) ) {
            foreach ($settings as $slug => $setting) {
                $cap = isset($setting['capability']) ? $setting['capability'] : 'delete_users';
                add_submenu_page($setting['parent_slug'], $setting['page_title'], $setting['menu_title'], $cap, $slug, $setting['callback']);
            }
        }

    }

}
