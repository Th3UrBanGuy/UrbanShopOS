<?php

namespace OrderDetect;

class Helper
{

    private static $hpos_enabled = null;

    public static function normalize_bangladeshi_phone_number($phone_raw)
    {
        $phone = wp_unslash((string) $phone_raw);
        $phone = preg_replace('/\D+/', '', $phone);

        if ($phone === '') {
            return '';
        }

        if (strlen($phone) === 13 && strpos($phone, '880') === 0) {
            $phone = '0' . substr($phone, 3);
        }

        if (strlen($phone) === 11 && strpos($phone, '0') === 0) {
            return $phone;
        }

        return '';
    }

    public static function check_license($settings)
    {
        if (empty($settings)) {
            return false;
        }

        $key = array_key_exists('key', $settings) ? $settings['key'] : '';
        $expires = array_key_exists('expires', $settings) ? $settings['expires'] : '';
        if (empty($key) || empty($expires)) {
            return false;
        }

        $current_date = current_time('mysql');
        $decrypted_expires = Helper::decrypt_data($expires, ORDERDETECT_ENCRYPTION_KEY, ORDERDETECT_IV);

        if (empty($decrypted_expires)) {
            return false;
        }

        if ($decrypted_expires === "lifetime") {
            return true;
        }
        if (strtotime($current_date) > strtotime($decrypted_expires)) {
            return false;
        }

        return true;
    }

    public static function is_valid_Bangladeshi_phone_number($phoneNumber)
    {
        $phone_number = self::normalize_bangladeshi_phone_number($phoneNumber);
        return (bool) preg_match('/^01[1-9]\d{8}$/', $phone_number);
    }

    public static function generate_unique_otp_for_phone($phone_number, $length = 4)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'od_otp_log';
        $phone_number = self::normalize_bangladeshi_phone_number($phone_number);

        if ($phone_number === '') {
            return false;
        }

        do {
            $random_number = rand(0, 9999);
            $otp = str_pad($random_number, $length, '0', STR_PAD_LEFT);

            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE phone_number = %s AND code = %s",
                $phone_number,
                $otp
            ));
        } while ($exists);
        return $otp;
    }

    public static function generate_otp($phone_number)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'od_otp_log';
        $phone_number = self::normalize_bangladeshi_phone_number($phone_number);
        if ($phone_number === '') {
            return false;
        }

        $otp = Helper::generate_unique_otp_for_phone($phone_number);
        if ($otp === false) {
            return false;
        }

        $settings = wp_parse_args(get_option('orderdetect_settings', array(
            'otp_expiry_minutes' => 15,
        )));
        $expiry_minutes = isset($settings['otp_expiry_minutes']) ? absint($settings['otp_expiry_minutes']) : 15;
        $expiry_minutes = max(1, min(60, $expiry_minutes));

        $expires_timestamp = current_time('timestamp') + ($expiry_minutes * MINUTE_IN_SECONDS);
        $expires_at = function_exists('wp_date')
            ? wp_date('Y-m-d H:i:s', $expires_timestamp)
            : date_i18n('Y-m-d H:i:s', $expires_timestamp);

        $wpdb->replace(
            $table_name,
            array(
                'phone_number' => $phone_number,
                'code' => $otp,
                'expires_at' => $expires_at,
            ),
            array(
                '%s',
                '%s',
                '%s'
            )
        );

        return $otp;
    }

    public static function verify_otp($phone_number, $otp)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'od_otp_log';
        $phone_number = self::normalize_bangladeshi_phone_number($phone_number);

        if ($phone_number === '') {
            return false;
        }

        $current_time = current_time('mysql');
        $result = $wpdb->get_row($wpdb->prepare(
            "SELECT id, phone_number, code, expires_at, is_verified, created_at FROM $table_name WHERE phone_number = %s AND code = %s AND expires_at > %s",
            $phone_number,
            $otp,
            $current_time
        ));

        return (bool) $result;
    }

    public static function set_phone_number_verified($phone_number)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'od_otp_log';
        $phone_number = self::normalize_bangladeshi_phone_number($phone_number);

        if ($phone_number === '') {
            return;
        }

        $wpdb->update(
            $table_name,
            array('is_verified' => true),
            array('phone_number' => $phone_number)
        );
    }

    public static function is_phone_number_verified($phone_number)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'od_otp_log';
        $phone_number = self::normalize_bangladeshi_phone_number($phone_number);

        if ($phone_number === '') {
            return false;
        }

        $sql = $wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE phone_number = %s AND is_verified = %d",
            $phone_number,
            1
        );

        $count = $wpdb->get_var($sql);
        return $count > 0;
    }

    public static function update_balance()
    {
        global $odSmsProvider;
        $default_balance = [
            'greenweb' => 0.00,
            'alpha' => 0.00,
            'dianahost' => 0.00,
            'mimsms' => 0.00,
            'bulksmsbd' => 0.00,
        ];
        $sms_balance = get_option('orderdetect_sms_balance', $default_balance);

        $settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => '',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => '',
                'mimsms' => '',
                'bulksmsbd' => ''
            ),
            'mimsms_sender_id' => '',
            'mimsms_username' => '',
            'bulksmsbd_sender_id' => '',
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));
        $sms_provider = isset($settings['sms_provider']) ? (string) $settings['sms_provider'] : '';
        $endpoint = isset($odSmsProvider[$sms_provider]) ? $odSmsProvider[$sms_provider] : '';
        $api_key = isset($settings['sms_api_key'][$sms_provider]) ? $settings['sms_api_key'][$sms_provider] : '';
        $orderdetect_settings = get_option('orderdetect_settings');
        $mim_user_name = isset($orderdetect_settings['mimsms_username']) ? $orderdetect_settings['mimsms_username'] : '';

        if (empty($endpoint) || empty($api_key)) {
            return;
        }

        if ("greenweb" === $sms_provider) {
            $endpoint .= "/g_api.php?token=" . $api_key . "&balance";
        } else if ("alpha" === $sms_provider) {
            $endpoint .= "/user/balance?api_key=" . $api_key . "";
        } else if ("dianahost" === $sms_provider) {
            $endpoint .= "/balance";
        } else if ("mimsms" === $sms_provider) {
            $endpoint .= "/SmsSending/balanceCheck?userName=".$mim_user_name."&Apikey=" . $api_key . "";
        } else if ("bulksmsbd" === $sms_provider) {
            $endpoint .= "/getBalanceApi?api_key=" . $api_key . "";
        }

        $headers = [
            "Authorization: Bearer $api_key",
            "Content-Type: application/json",
        ];






        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $endpoint);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);

        if ("dianahost" === $sms_provider) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        }
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_ENCODING, '');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $balanceResponse = curl_exec($ch);
        $http_code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        if ($balanceResponse !== false && $http_code < 400) {

            if ("greenweb" === $sms_provider) {
                if (strpos($balanceResponse, 'Error:') !== false) {
                    error_log('Error: ' . $balanceResponse);
                } else {
                    $sms_balance['greenweb'] = strip_tags($balanceResponse);
                }
            } else if ("alpha" === $sms_provider) {
                $responseArray = json_decode($balanceResponse, true);
                if (is_array($responseArray) && isset($responseArray['error']) && (int) $responseArray['error'] === 0 && isset($responseArray['data']['balance'])) {
                    $balance = $responseArray['data']['balance'];
                    $sms_balance['alpha'] = number_format($balance, 2);
                } else {
                    error_log('API Error: ' . (is_array($responseArray) && isset($responseArray['msg']) ? $responseArray['msg'] : $balanceResponse));
                }
            } else if ("dianahost" === $sms_provider) {
                $responseArray = json_decode($balanceResponse, true);
                if (is_array($responseArray) && isset($responseArray['status']) && $responseArray['status'] == "success" && isset($responseArray['data']['remaining_unit'])) {
                    $balance = $responseArray['data']['remaining_unit'];
                    $sms_balance['dianahost'] = number_format($balance, 2);
                } else {
                    error_log('API Error: ' . (is_array($responseArray) && isset($responseArray['msg']) ? $responseArray['msg'] : $balanceResponse));
                }
            }  else if ("mimsms" === $sms_provider) {
                $responseArray = json_decode($balanceResponse, true);
                if (is_array($responseArray) && isset($responseArray['statusCode']) && (int) $responseArray['statusCode'] === 200 && isset($responseArray['responseResult'])) {
                    $balance = $responseArray['responseResult'];
                    $sms_balance['mimsms'] = number_format($balance, 2);
                } else {
                    error_log('API Error: ' . (is_array($responseArray) && isset($responseArray['msg']) ? $responseArray['msg'] : $balanceResponse));
                }
            }  else if ("bulksmsbd" === $sms_provider) {
                $responseArray = json_decode($balanceResponse, true);
                if (is_array($responseArray) && isset($responseArray['response_code']) && (int) $responseArray['response_code'] === 202 && isset($responseArray['balance'])) {
                    $balance = $responseArray['balance'];
                    $sms_balance['bulksmsbd'] = number_format($balance, 2);
                } else {
                    error_log('API Error: ' . (is_array($responseArray) && isset($responseArray['msg']) ? $responseArray['msg'] : $balanceResponse));
                }
            }

            update_option('orderdetect_sms_balance', $sms_balance);
        }
    }

    public static function send_sms_balance_notification($sms_balance = null)
    {

        $settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => '',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => '',
                'mimsms' => '',
                'bulksmsbd' => ''
            ),
            'mimsms_sender_id' => '',
            'mimsms_username' => '',
            'bulksmsbd_sender_id' => '',
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));
        $sms_balance = wp_parse_args(get_option('orderdetect_sms_balance', [
            'greenweb' => 0.00,
            'alpha' => 0.00,
            'dianahost' => 0.00,
            'mimsms' => 0.00,
            'bulksmsbd' => 0.00,
        ]));

        $balance = $sms_balance[$settings['sms_provider']];

        if ($balance <= 50 && ($balance == 50 || $balance == 40 || $balance == 30 || $balance == 20 || $balance == 10 || $balance == 2)) {
            $to = get_option('admin_email');
            $subject = 'Low SMS Balance Notification';
            $message = "Dear shop owner,\n\n";
            $message .= "This is to inform you that your SMS balance has reached " . $balance . " taka.\n";
            $message .= "Please refill your SMS balance to ensure uninterrupted service for your customers.\n\n";
            $message .= "Current SMS balance: " . $balance . " taka\n\n";
            $message .= "Best regards,\n";
            $message .= "OrderDetect";

            wp_mail($to, $subject, $message);
        }
    }

    public static function encrypt_data($target_data, $key = ORDERDETECT_ENCRYPTION_KEY, $iv = ORDERDETECT_IV)
    {
        $cipher_method = 'aes-256-cbc';
        $encrypted = openssl_encrypt($target_data, $cipher_method, base64_decode($key), 0, base64_decode($iv));
        return base64_encode($encrypted);
    }

    public static function decrypt_data($encrypted_data, $key = ORDERDETECT_ENCRYPTION_KEY, $iv = ORDERDETECT_IV)
    {
        $cipher_method = 'aes-256-cbc';
        $decrypted = openssl_decrypt(base64_decode($encrypted_data), $cipher_method, base64_decode($key), 0, base64_decode($iv));
        return $decrypted;
    }

    public static function mask_string($input)
    {
        $length = strlen($input);
        if ($length <= 8) {
            return $input;
        }

        $first_part = substr($input, 0, 4);
        $last_part = substr($input, -4);
        return $first_part . str_repeat('*', $length - 8) . $last_part;
    }

    public static function validate_and_format_phone_number($phone)
    {
        $phone = self::normalize_bangladeshi_phone_number($phone);
        if ($phone === '') {
            return '';
        }

        return '880' . substr($phone, 1);
    }

}
