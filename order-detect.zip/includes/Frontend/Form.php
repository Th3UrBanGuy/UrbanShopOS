<?php

namespace OrderDetect\Frontend;

class Form {

    public static function otp_form() {
        $settings = wp_parse_args(
            get_option(
                'orderdetect_settings',
                array(
                    'otp_popup_title' => 'Order Verification',
                    'otp_processing_message' => 'Checking your phone number...',
                    'otp_placeholder' => 'Enter OTP Code',
                    'otp_verify_button_text' => 'Verify',
                )
            )
        );

        $popup_title = ! empty( $settings['otp_popup_title'] ) ? $settings['otp_popup_title'] : __('Order Verification', 'order-detect');
        $processing_message = ! empty( $settings['otp_processing_message'] ) ? $settings['otp_processing_message'] : __('Checking your phone number...', 'order-detect');
        $otp_placeholder = ! empty( $settings['otp_placeholder'] ) ? $settings['otp_placeholder'] : __('Enter OTP Code', 'order-detect');
        $verify_button_text = ! empty( $settings['otp_verify_button_text'] ) ? $settings['otp_verify_button_text'] : __('Verify', 'order-detect');
?>
        <div class="otp-verification-container" id="od-order-verification-popup">
            <div class="otp-verification-inner" id="od-order-verification-second-step">
                <div class="otp-verification-header">
                    <h2><?php echo esc_html( $popup_title ); ?></h2>
                    <button type="button" class="modal__close" aria-label="<?php echo esc_attr__( 'Close', 'order-detect' ); ?>"></button>
                </div>
                <div class="otp-verification-body">
                    <div class="otp-processing-area">
                        <div class="order-detect-loader"></div>
                        <p class="otp-sedning-msg" id="otp-processing-msg"><?php echo esc_html( $processing_message ); ?></p>
                    </div>
                    <div class="otp-form-area">
                        <p class="otp-sedning-msg" id="otp-sedning-msg"></p>
                        <p class="otp-status-success" id="otp-status-notice"></p>
                        <p class="otp-status-error" id="otp-verify-failed"></p>
                        <form class="otp-verification-form">
                            <div class="otp-form-group otp-form-group-25">
                                <input type="number" name="otp-code" class="otp-code" id="otp-code" maxlength="4" placeholder="<?php echo esc_attr( $otp_placeholder ); ?>">
                            </div>
                            <div class="otp-form-group">
                                <button type="button" class="otp-verification-btn" id="otp-verify-btn">
                                    <?php echo esc_html( $verify_button_text ); ?>
                                </button>
                            </div>
                            <div class="otp-form-group" id="otp-resend-section"></div>
                        </form>
                        <div id="otp-process-loader" class="otp-process-loader"></div>
                    </div>
                </div>
            </div>
        </div>
    <?php
    }

}
