<?php
namespace OrderDetect\Frontend;

use OrderDetect\Helper;

class StoreFront {

    private $api;
    private $settings;
    private $form;

    public function __construct() {
        $this->settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => '',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => '',
                'mimsms' => '',
                'bulksmsbd' => ''
            ),
            'mimsms_sender_id' => '',
            'mimsms_username' => '',
            'bulksmsbd_sender_id' => '',
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));
        add_action('wp_footer', array($this, 'init_otp_modal_checkout'));
        add_filter('woocommerce_order_button_html', array($this, 'place_order_button_html'), 10);

    }

    public function place_order_button_html($html){
        $html = preg_replace('/onclick="verifyOTPbilling\\(10\\);return false;"/', '', $html);
        $html = preg_replace('/data-digits_verify="[^"]*"/', '', $html);

        if ( ! empty( $this->settings['enable_otp'] ) && 1 == $this->settings['enable_otp'] && ! empty( $this->settings['checkout_otp_message'] ) ) {
            $html = preg_replace('/type="submit"/', 'type="button"', $html, 1);
            if (strpos($html, 'show-otp-popup') === false) {
                $html = preg_replace('/class="([^"]*)"/', 'class="$1 show-otp-popup"', $html, 1);
            }
        }

        return $html;
    }

    public function init_otp_modal_checkout() {
        if ( is_checkout() && ! empty( $this->settings['enable_otp'] ) ) {
            echo Form::otp_form();
        }

    }
}
