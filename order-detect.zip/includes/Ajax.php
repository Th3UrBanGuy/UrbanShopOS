<?php
namespace OrderDetect;
use OrderDetect\Helper;

if (! defined('ABSPATH')) {
    exit;
}

class Ajax {

    private $settings;

    public function __construct() {
        $this->settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => '',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => '',
                'mimsms' => '',
                'bulksmsbd' => ''
            ),
            'mimsms_sender_id' => '',
            'mimsms_username' => '',
            'bulksmsbd_sender_id' => '',
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'otp_expiry_minutes' => 15,
            'otp_resend_countdown_seconds' => 60,
            'otp_popup_title' => 'Order Verification',
            'otp_processing_message' => 'Checking your phone number...',
            'otp_placeholder' => 'Enter OTP Code',
            'otp_verify_button_text' => 'Verify',
            'otp_resend_button_text' => 'Resend OTP',
            'otp_resend_countdown_text' => 'Didn\'t receive code? Resend in %time%',
            'otp_invalid_phone_message' => 'Please enter a valid Bangladeshi phone number. Example: 017XXXXXXXX.',
            'otp_try_again_text' => 'Try again',
            'otp_generic_error_message' => 'Something went wrong!',
            'otp_sent_message' => 'OTP has been sent to: %phone_number%',
            'otp_verified_message' => 'OTP verification successful!',
            'otp_invalid_code_message' => 'OTP verification failed. Invalid OTP.',
            'dianahost_sender_id' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));

        add_action('wp_ajax_license_activate', array($this, 'license_activate'));
        add_action('wp_ajax_license_deactivate', array($this, 'license_deactivate'));

        add_action('wp_ajax_send_otp', array($this, 'send_otp'));
        add_action('wp_ajax_nopriv_send_otp', array($this, 'send_otp'));

        add_action('wp_ajax_verify_otp', array($this, 'verify_otp'));
        add_action('wp_ajax_nopriv_verify_otp', array($this, 'verify_otp'));

        add_action('wp_ajax_check_phone_is_verified', array($this, 'check_phone_is_verified'));
        add_action('wp_ajax_nopriv_check_phone_is_verified', array($this, 'check_phone_is_verified'));

        add_action('wp_ajax_od_precheck_otp', array($this, 'precheck_otp'));
        add_action('wp_ajax_nopriv_od_precheck_otp', array($this, 'precheck_otp'));

        add_action('wp_ajax_od_prepare_otp', array($this, 'prepare_otp'));
        add_action('wp_ajax_nopriv_od_prepare_otp', array($this, 'prepare_otp'));

        add_action('wp_ajax_get_customer_orders', array($this, 'get_customer_orders'));

        add_action('wp_ajax_save_sms_provider_settings', array($this, 'save_sms_provider_settings') );

        add_action('wp_ajax_save_otp_setting', array($this, 'save_otp_setting') );

        add_action('wp_ajax_save_order_alerts', array($this, 'save_order_alerts') );

        add_action('wp_ajax_update_phone_number_status', array($this, 'update_phone_number_status') );

    }

    private function get_popup_setting_text( $key, $default ) {
        if ( ! empty( $this->settings[ $key ] ) ) {
            return (string) $this->settings[ $key ];
        }

        return $default;
    }

    private function has_active_license() {
        return Helper::check_license( wp_parse_args( get_option( 'orderdetect_license' ) ) );
    }

    private function require_active_license() {
        if ( $this->has_active_license() ) {
            return true;
        }

        wp_send_json_error(
            array(
                'message' => __( 'An active license is required to use this feature.', 'order-detect' ),
            ),
            403
        );

        return false;
    }

    private function get_otp_precheck_result( $phone_number ) {
        $phone = $phone_number;
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $device = $_COOKIE['hashed_user_agent'] ?? '';

        $blocked = false;
        $message = '';

        if ($phone && function_exists('\\obn_is_blocked_value') && \obn_is_blocked_value('phone', $phone)) {
            $blocked = true;
            $message = function_exists('\\obn_get_block_message') ? \obn_get_block_message('phone') : '';
        } elseif ($ip && function_exists('\\obn_is_blocked_value') && \obn_is_blocked_value('ip', $ip)) {
            $blocked = true;
            $message = function_exists('\\obn_get_block_message') ? \obn_get_block_message('ip') : '';
        } elseif ($device && function_exists('\\obn_is_blocked_value') && \obn_is_blocked_value('device', $device)) {
            $blocked = true;
            $message = function_exists('\\obn_get_block_message') ? \obn_get_block_message('device') : '';
        }

        if (!$blocked && function_exists('\\obn_is_auto_blocked')) {
            foreach (['phone' => $phone, 'ip' => $ip, 'device' => $device] as $type => $value) {
                if (!$value) {
                    continue;
                }
                $msg = \obn_is_auto_blocked($type, $value);
                if ($msg) {
                    $blocked = true;
                    $message = $msg;
                    break;
                }
            }
        }

        return array(
            'blocked' => $blocked,
            'message' => $message,
        );
    }

    public function license_activate() {
        check_ajax_referer('order-detect-admin-nonce', 'security');

        if ( ! current_user_can('manage_woocommerce') ) {
            wp_send_json(array('message' => __('You do not have permission to perform this action.', 'order-detect'), 'class' => 'order-detect-license-status-error'), 403);
        }

        $license_key = sanitize_text_field($_POST['license_key']);
        if (isset($license_key)) {
            $license_key = sanitize_text_field($_POST['license_key']);
            $api_params = array(
                'edd_action' => 'activate_license',
                'license'    => $license_key,
                'item_name'  => urlencode(ORDERDETECT_SL_ITEM_NAME),
                'url'        => home_url()
            );

            $response = wp_remote_post(esc_url(ORDERDETECT_STORE_URL), array( 'timeout' => 20, 'body' => $api_params, 'headers' => array(
                'User-Agent' => 'Order Detect/1.0.0; ' . home_url('/')
            ) ) );

            if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code( $response )) {
                $message = is_wp_error($response)
                    ? $response->get_error_message()
                    : __('License server returned an unexpected response.', 'order-detect');
                wp_send_json(array('message' => $message, 'class' => 'order-detect-license-status-error'), 500);
            }

            $license_data = json_decode(wp_remote_retrieve_body($response));

            if ($license_data->success) {
                $settings = [];
                $settings['key'] = Helper::encrypt_data($license_key, ORDERDETECT_ENCRYPTION_KEY, ORDERDETECT_IV);
                $settings['expires'] = Helper::encrypt_data($license_data->expires, ORDERDETECT_ENCRYPTION_KEY, ORDERDETECT_IV);
                update_option('orderdetect_license', $settings);
                wp_send_json(array('message' => 'License activated successfully.', 'class' => 'order-detect-license-status-success'), 200);
            } else {
                wp_send_json(array('message' => 'License activation failed: '.$license_data->error, 'class' => 'order-detect-license-status-error'), 400);
            }
        } else {
            wp_send_json(array('message' => 'License key invalid!', 'class' => 'order-detect-license-status-error'), 400);
        }

        wp_die();
    }

    public function license_deactivate() {
        check_ajax_referer('order-detect-admin-nonce', 'security');

        if ( ! current_user_can('manage_woocommerce') ) {
            wp_send_json(array('message' => __('You do not have permission to perform this action.', 'order-detect'), 'class' => 'order-detect-license-status-error'), 403);
        }
    
        $orderdetect_license = get_option('orderdetect_license');
        $license_key = isset($orderdetect_license['key']) ? $orderdetect_license['key'] : '';
        
        if ($license_key) {
            $api_params = array(
                'edd_action' => 'deactivate_license',
                'license'   => Helper::decrypt_data($license_key, ORDERDETECT_ENCRYPTION_KEY, ORDERDETECT_IV),
                'item_name' => urlencode(ORDERDETECT_SL_ITEM_NAME),
                'url'       => home_url()
            );
    
            $response = wp_remote_post(esc_url(ORDERDETECT_STORE_URL), array( 'timeout' => 20, 'body' => $api_params, 'headers' => array(
                'User-Agent' => 'Order Detect/1.0.0; ' . home_url('/')
            ) ) );
    
            if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code( $response )) {
                $message = is_wp_error($response)
                    ? $response->get_error_message()
                    : __('License server returned an unexpected response.', 'order-detect');
                wp_send_json(array('message' => $message, 'class' => 'order-detect-license-status-error'), 500);
            }
    
            $license_data = json_decode(wp_remote_retrieve_body($response));
            if ($license_data && $license_data->success) {
                delete_option('orderdetect_license');
                wp_send_json(array('message' => 'License deactivated successfully.', 'class' => 'order-detect-license-status-success'), 200);
            } elseif ($license_data && isset($license_data->license) && $license_data->license == 'failed') {
                delete_option('orderdetect_license');
                wp_send_json(array('message' => 'License was already inactive. Local data cleaned.', 'class' => 'order-detect-license-status-warning'), 200);
            } else {
                $error_message = isset($license_data->error) ? $license_data->error : 'Unknown error';
                wp_send_json(array('message' => 'License deactivation failed: ' . $error_message, 'class' => 'order-detect-license-status-error'), 400);
            }
        } else {
            wp_send_json(array('message' => 'License key not found.', 'class' => 'order-detect-license-status-error'), 400);
        }
    
        wp_die();
    }        

    public function send_otp() {
        check_ajax_referer('order-detect-nonce', 'security');

        if ( ! $this->require_active_license() ) {
            return;
        }

        $phone_number = isset($_POST['phone_number']) ? Helper::normalize_bangladeshi_phone_number(sanitize_text_field(wp_unslash($_POST['phone_number']))) : '';
        $response = array();

        if (!Helper::is_valid_Bangladeshi_phone_number($phone_number)) {
            $response['success'] = false;
            $response['message'] = $this->get_popup_setting_text(
                'otp_invalid_phone_message',
                __('Please enter a valid Bangladeshi phone number. Example: 017XXXXXXXX.', 'order-detect')
            );
            wp_send_json($response, 400);
        }

        $otp = Helper::generate_otp($phone_number);

        if (!$otp) {
            $response['success'] = false;
            $response['message'] = __('Failed to generate OTP. Please try again later.', 'order-detect');
            wp_send_json($response, 500);
        }

        global $odSmsProvider;
        $enable = array_key_exists('enable_otp', $this->settings) ? $this->settings['enable_otp'] : '0';
        $sms_provider = isset($this->settings['sms_provider']) ? (string) $this->settings['sms_provider'] : '';
        $endpoint = isset($odSmsProvider[$sms_provider]) ? $odSmsProvider[$sms_provider] : '';
        $api_key = isset($this->settings['sms_api_key'][$sms_provider]) ? $this->settings['sms_api_key'][$sms_provider] : '';
        $checkout_otp_message = array_key_exists('checkout_otp_message', $this->settings) ? $this->settings['checkout_otp_message'] : '';

        if ( empty($enable) || (int) $enable !== 1 || empty($endpoint) || empty($api_key) || empty($checkout_otp_message) ) {
            wp_send_json(array(
                'success' => false,
                'message' => __('OTP SMS is not configured properly. Please contact the store administrator.', 'order-detect')
            ), 500);
        }

        if ( ! empty($enable) && $enable == 1 &&  ! empty($endpoint) &&  ! empty($api_key) &&  ! empty($checkout_otp_message) ) {
            $domain = $_SERVER['HTTP_HOST'];
            $message = str_replace(array('(', ')'), '', $checkout_otp_message);
            $message = str_replace('%otp_code%', $otp, $message);
            $message = str_replace('@domain', $domain, $message);

            $to = Helper::validate_and_format_phone_number( $phone_number );

            if("greenweb" === $sms_provider ) {
                $endpoint .= '/api.php';
                $data = [
                    'to'=>"$to",
                    'message'=>"$message",
                    'token'=>"$api_key"
                ];
            } else if( "alpha" === $sms_provider ) {
                $endpoint .= '/sendsms';
                $data = [
                    'to'=>"$to",
                    'msg'=>"$message",
                    'api_key'=>"$api_key"
                ];
            } else if( "dianahost" === $sms_provider ) {
                $endpoint .= '/sms/send';
                $data = [
                    'recipient'=>"$to",
                    'type' => 'plain',
                    'sender_id' => $this->settings['dianahost_sender_id'],
                    'message'=>"$message",
                ];
            } else if( "mimsms" === $sms_provider ) {
                $endpoint .= '/SmsSending/Send';
                $data = [
                    'UserName' => $this->settings['mimsms_username'],
                    'Apikey' => "$api_key",
                    'MobileNumber' => "$to",
                    'SenderName' => $this->settings['mimsms_sender_id'],
                    'TransactionType' => 'T',
                    'Message' => "$message",
                ];
                
            } else if( "bulksmsbd" === $sms_provider ) {
                $endpoint .= '/smsapi';
                $data = [
                    'number'=>"$to",
                    'type' => 'text',
                    'api_key'=>"$api_key",
                    'senderid' => $this->settings['bulksmsbd_sender_id'],
                    'message'=>"$message",
                ];
            }
			
            if( "mimsms" === $sms_provider ){
                $url = $endpoint . '?' . http_build_query($data);
                $response = wp_remote_get($url, array(
                    'timeout' => 20,
                    'redirection' => 2,
                ));

                if ( is_wp_error($response) ) {
                    wp_send_json(array(
                        'success' => false,
                        'message' => __('Failed to send OTP. Please try again later.', 'order-detect')
                    ), 500);
                }

                $http_code = wp_remote_retrieve_response_code($response);
                $smsresult = wp_remote_retrieve_body($response);
                if ( ! od_mimsms_is_success($smsresult, $http_code) ) {
                    wp_send_json(array(
                        'success' => false,
                        'message' => __('Failed to send OTP. Please try again later.', 'order-detect')
                    ), 500);
                }
            }else{
                $ch = curl_init(); 
                curl_setopt($ch, CURLOPT_URL, $endpoint);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
                curl_setopt($ch, CURLOPT_TIMEOUT, 20);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
                curl_setopt($ch, CURLOPT_ENCODING, '');
                if( "dianahost" === $sms_provider ) {
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Accept: application/json',
                        "Authorization: Bearer $api_key",
                        "Content-Type: application/json"
                    ));
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                } else {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                }
        
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $smsresult = curl_exec($ch);
                $http_code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
                curl_close($ch);

                if ($smsresult === false || $http_code >= 400) {
                    wp_send_json(array(
                        'success' => false,
                        'message' => __('Failed to send OTP. Please try again later.', 'order-detect')
                    ), 500);
                }

                if ( "greenweb" === $sms_provider ) {
                    $parsed = od_greenweb_parse_response($smsresult, $http_code);
                    if ( ! $parsed['success'] ) {
                        wp_send_json(array(
                            'success' => false,
                            'message' => __('Failed to send OTP. Please try again later.', 'order-detect')
                        ), 500);
                    }
                } elseif ( "dianahost" === $sms_provider ) {
                    $parsed = od_dianahost_parse_response($smsresult, $http_code);
                    if ( ! $parsed['success'] ) {
                        wp_send_json(array(
                            'success' => false,
                            'message' => __('Failed to send OTP. Please try again later.', 'order-detect')
                        ), 500);
                    }
                } elseif ( "bulksmsbd" === $sms_provider ) {
                    $parsed = od_bulksmsbd_parse_response($smsresult);
                    if ( ! $parsed['success'] ) {
                        wp_send_json(array(
                            'success' => false,
                            'message' => __('Failed to send OTP. Please try again later.', 'order-detect')
                        ), 500);
                    }
                } elseif ( "alpha" === $sms_provider ) {
                    $parsed = od_alpha_parse_response($smsresult);
                    if ( ! $parsed['success'] ) {
                        wp_send_json(array(
                            'success' => false,
                            'message' => __('Failed to send OTP. Please try again later.', 'order-detect')
                        ), 500);
                    }
                }
			}
            
            Helper::update_balance();
            Helper::send_sms_balance_notification();
        }

        $response['success'] = true;
        $response['message'] = str_replace(
            '%phone_number%',
            $phone_number,
            $this->get_popup_setting_text('otp_sent_message', __('OTP has been sent to: %phone_number%', 'order-detect'))
        );
        wp_send_json($response, 200);
        wp_die();
    }

    public function verify_otp() {
        check_ajax_referer('order-detect-nonce', 'security');

        if ( ! $this->require_active_license() ) {
            return;
        }

        $phone_number = isset($_POST['phone_number']) ? Helper::normalize_bangladeshi_phone_number(wp_unslash($_POST['phone_number'])) : '';
        $otp = isset($_POST['otp']) ? sanitize_text_field($_POST['otp']) : '';

        $response = array();

        $otp_verified = Helper::verify_otp($phone_number, $otp);

        if ($otp_verified) {
            Helper::set_phone_number_verified($phone_number);
            $response['success'] = true;
            $response['message'] = $this->get_popup_setting_text('otp_verified_message', __('OTP verification successful!', 'order-detect'));
        } else {
            $response['success'] = false;
            $response['message'] = $this->get_popup_setting_text('otp_invalid_code_message', __('OTP verification failed. Invalid OTP.', 'order-detect'));
        }

        wp_send_json($response, 200);
        wp_die();
    }

    public function check_phone_is_verified() {

        check_ajax_referer('order-detect-nonce', 'security');

        if ( ! $this->require_active_license() ) {
            return;
        }

        $phone_number = isset($_POST['phone_number']) ? Helper::normalize_bangladeshi_phone_number(wp_unslash($_POST['phone_number'])) : '';
        $is_verified = Helper::is_phone_number_verified($phone_number);
        if ($is_verified) {
            $response['success'] = true;
            $response['message'] = 'This phone number has already been verified.';
        } else {
            $response['success'] = false;
            $response['message'] = 'This phone number is not verified.';
        }

        wp_send_json($response, 200);
    }

    public function prepare_otp() {
        check_ajax_referer('order-detect-nonce', 'security');

        if ( ! $this->require_active_license() ) {
            return;
        }

        $phone_number = isset($_POST['phone_number']) ? Helper::normalize_bangladeshi_phone_number(sanitize_text_field(wp_unslash($_POST['phone_number']))) : '';

        if (!Helper::is_valid_Bangladeshi_phone_number($phone_number)) {
            wp_send_json_error(array('message' => $this->get_popup_setting_text(
                'otp_invalid_phone_message',
                __('Please enter a valid Bangladeshi phone number. Example: 017XXXXXXXX.', 'order-detect')
            )), 400);
        }

        $precheck = $this->get_otp_precheck_result($phone_number);
        if ( ! empty($precheck['blocked']) ) {
            $message = ! empty($precheck['message']) ? $precheck['message'] : __('Checkout blocked.', 'order-detect');
            wp_send_json_error(array('message' => $message), 400);
        }

        $is_verified = Helper::is_phone_number_verified($phone_number);

        wp_send_json_success(array(
            'status' => $is_verified ? 'verified' : 'needs_otp',
            'message' => $is_verified
                ? __('This phone number has already been verified.', 'order-detect')
                : __('OTP verification is required.', 'order-detect'),
        ));
    }

    public function precheck_otp() {
        check_ajax_referer('order-detect-nonce', 'security');

        if ( ! $this->require_active_license() ) {
            return;
        }

        $phone_number = isset($_POST['phone_number']) ? Helper::normalize_bangladeshi_phone_number(sanitize_text_field(wp_unslash($_POST['phone_number']))) : '';
        $precheck = $this->get_otp_precheck_result($phone_number);

        if (!empty($precheck['blocked'])) {
            $message = ! empty($precheck['message']) ? $precheck['message'] : __('Checkout blocked.', 'order-detect');
            wp_send_json_error([ 'message' => $message ], 400);
        }

        wp_send_json_success([ 'message' => 'ok' ]);
    }

    public function get_customer_orders() {
        check_ajax_referer('order-detect-admin-nonce', 'security');

        if ( ! current_user_can('manage_woocommerce') ) {
            wp_send_json_error(array('message' => __('You do not have permission to perform this action.', 'order-detect')), 403);
            return;
        }

        $order_id = intval($_POST['order_id']);
        $order = wc_get_order($order_id);
        
        if (!$order) {
            wp_send_json_error(array('message' => 'Invalid order ID'));
            return;
        }

        $customer_phone = $order->get_billing_phone();
        
        if (empty($customer_phone)) {
            wp_send_json_error(array('message' => 'No phone number found for this order'));
            return;
        }

        $args = array(
            'post_type' => 'shop_order',
            'post_status' => array_keys(wc_get_order_statuses()), // Include all order statuses
            'meta_query' => array(
                array(
                    'key' => '_billing_phone',
                    'value' => $customer_phone,
                    'compare' => '='
                ),
            ),
            'posts_per_page' => -1,
            'post__not_in' => array($order_id),
        );

        $orders = get_posts($args);
        
        if (empty($orders)) {
            wp_send_json_error(array('message' => 'No orders found for this customer phone number'));
            return;
        }

        $orders_data = array();
        
        foreach ($orders as $customer_order) {
            $order_id = $customer_order->ID;
            $order_date = $customer_order->post_date;
            $order_status = wc_get_order_status_name($customer_order->post_status);
            $order_total = get_post_meta($order_id, '_order_total', true);

            $orders_data[] = array(
                'id' => $order_id,
                'date' => $order_date,
                'status' => $order_status,
                'total' => wc_price($order_total),
                'edit_link' => admin_url('post.php?post=' . $order_id . '&action=edit')
            );
        }

        wp_send_json_success(array('orders' => $orders_data));

    }

    public function save_sms_provider_settings() {
        check_ajax_referer('order-detect-admin-nonce', 'security');

        if ( ! current_user_can('manage_woocommerce') ) {
            wp_send_json_error(array('message' => __('You do not have permission to perform this action.', 'order-detect')), 403);
            return;
        }

        if ( ! $this->require_active_license() ) {
            return;
        }
    
        $sms_provider = sanitize_text_field($_POST['sms_provider']);
        $sms_api_key = sanitize_text_field($_POST['sms_api_key']);
    
        $settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => '',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => '',
                'mimsms' => '',
                'bulksmsbd' => ''
            ),
            'mimsms_sender_id' => '',
            'mimsms_username' => '',
            'bulksmsbd_sender_id' => '',
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));
    
        $settings['sms_provider'] = $sms_provider;
        $settings['sms_api_key'][ $sms_provider ] = $sms_api_key;
        if( empty($sms_provider) ){
            $settings['enable_otp'] = 0;
            
            // Disable all order status notifications when no SMS provider is selected
            foreach ($settings as $key => $value) {
                if (strpos($key, 'wc-') === 0 && strpos($key, '_enable') !== false) {
                    $settings[$key] = 0;
                }
            }
        }

        if( isset($_POST['dianahost_sender_id']) ){
            $settings['dianahost_sender_id'] = sanitize_text_field($_POST['dianahost_sender_id']);
        }
        if( isset($_POST['mimsms_sender_id']) ){
            $settings['mimsms_sender_id'] = sanitize_text_field($_POST['mimsms_sender_id']);
        }
        if( isset($_POST['mimsms_username']) ){
            $settings['mimsms_username'] = sanitize_text_field($_POST['mimsms_username']);
        }
        if( isset($_POST['bulksmsbd_sender_id']) ){
            $settings['bulksmsbd_sender_id'] = sanitize_text_field($_POST['bulksmsbd_sender_id']);
        }

        update_option('orderdetect_settings', $settings);

        if (
            !empty($_POST['sms_provider']) &&
            !empty($_POST['sms_api_key'])
        ) {
            Helper::update_balance();
            $balance = get_option( 'orderdetect_sms_balance' , [
                'greenweb' => 0.00,
                'alpha' => 0.00,
                'dianahost' => 0.00,
                'mimsms' => 0.00,
                'bulksmsbd' => 0.00,
            ]);
        } 
        wp_send_json_success(array('message' => 'SMS Provider Saved Successfully!', 'balance' => ! empty( $sms_provider ) ? $balance[ $sms_provider ]: 0 ) );

    }

    public function save_otp_setting() {
        check_ajax_referer('order-detect-admin-nonce', 'security');

        if ( ! current_user_can('manage_woocommerce') ) {
            wp_send_json_error(array('message' => __('You do not have permission to perform this action.', 'order-detect')), 403);
            return;
        }

        if ( ! $this->require_active_license() ) {
            return;
        }
    
        $enable_otp = isset($_POST['enable_otp']) ? intval(wp_unslash($_POST['enable_otp'])) : 0;
        $checkout_otp_message = isset($_POST['checkout_otp_message']) ? sanitize_textarea_field(wp_unslash($_POST['checkout_otp_message'])) : '';
        $otp_expiry_minutes = isset($_POST['otp_expiry_minutes']) ? absint(wp_unslash($_POST['otp_expiry_minutes'])) : 15;
        $otp_resend_countdown_seconds = isset($_POST['otp_resend_countdown_seconds']) ? absint(wp_unslash($_POST['otp_resend_countdown_seconds'])) : 60;
        $otp_popup_title = isset($_POST['otp_popup_title']) ? sanitize_text_field(wp_unslash($_POST['otp_popup_title'])) : '';
        $otp_processing_message = isset($_POST['otp_processing_message']) ? sanitize_text_field(wp_unslash($_POST['otp_processing_message'])) : '';
        $otp_placeholder = isset($_POST['otp_placeholder']) ? sanitize_text_field(wp_unslash($_POST['otp_placeholder'])) : '';
        $otp_verify_button_text = isset($_POST['otp_verify_button_text']) ? sanitize_text_field(wp_unslash($_POST['otp_verify_button_text'])) : '';
        $otp_resend_button_text = isset($_POST['otp_resend_button_text']) ? sanitize_text_field(wp_unslash($_POST['otp_resend_button_text'])) : '';
        $otp_resend_countdown_text = isset($_POST['otp_resend_countdown_text']) ? sanitize_text_field(wp_unslash($_POST['otp_resend_countdown_text'])) : '';
        $otp_invalid_phone_message = isset($_POST['otp_invalid_phone_message']) ? sanitize_text_field(wp_unslash($_POST['otp_invalid_phone_message'])) : '';
        $otp_try_again_text = isset($_POST['otp_try_again_text']) ? sanitize_text_field(wp_unslash($_POST['otp_try_again_text'])) : '';
        $otp_generic_error_message = isset($_POST['otp_generic_error_message']) ? sanitize_text_field(wp_unslash($_POST['otp_generic_error_message'])) : '';
        $otp_sent_message = isset($_POST['otp_sent_message']) ? sanitize_text_field(wp_unslash($_POST['otp_sent_message'])) : '';
        $otp_verified_message = isset($_POST['otp_verified_message']) ? sanitize_text_field(wp_unslash($_POST['otp_verified_message'])) : '';
        $otp_invalid_code_message = isset($_POST['otp_invalid_code_message']) ? sanitize_text_field(wp_unslash($_POST['otp_invalid_code_message'])) : '';
    
        $settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => '',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => '',
                'mimsms' => '',
                'bulksmsbd' => ''
            ),
            'mimsms_sender_id' => '',
            'mimsms_username' => '',
            'bulksmsbd_sender_id' => '',
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'otp_expiry_minutes' => 15,
            'otp_resend_countdown_seconds' => 60,
            'otp_popup_title' => 'Order Verification',
            'otp_processing_message' => 'Checking your phone number...',
            'otp_placeholder' => 'Enter OTP Code',
            'otp_verify_button_text' => 'Verify',
            'otp_resend_button_text' => 'Resend OTP',
            'otp_resend_countdown_text' => 'Didn\'t receive code? Resend in %time%',
            'otp_invalid_phone_message' => 'Please enter a valid Bangladeshi phone number. Example: 017XXXXXXXX.',
            'otp_try_again_text' => 'Try again',
            'otp_generic_error_message' => 'Something went wrong!',
            'otp_sent_message' => 'OTP has been sent to: %phone_number%',
            'otp_verified_message' => 'OTP verification successful!',
            'otp_invalid_code_message' => 'OTP verification failed. Invalid OTP.',
            'dianahost_sender_id' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));
    
        if ($enable_otp) {
            // Verify SMS provider configuration
            $sms_provider = $settings['sms_provider'];
            $api_key = $settings['sms_api_key'][$sms_provider] ?? '';
            
            if (empty($sms_provider) || empty($api_key)) {
                wp_send_json_error(__('Please configure SMS provider settings before enabling OTP.', 'order-detect'));
                return;
            }
            
            $settings['enable_otp'] = $enable_otp;
        } else {
            unset($settings['enable_otp']);
        }
    
        $otp_expiry_minutes = max(1, min(60, $otp_expiry_minutes));
        $otp_resend_countdown_seconds = max(5, min(600, $otp_resend_countdown_seconds));

        $settings['checkout_otp_message'] = $checkout_otp_message;
        $settings['otp_expiry_minutes'] = $otp_expiry_minutes;
        $settings['otp_resend_countdown_seconds'] = $otp_resend_countdown_seconds;
        $settings['otp_popup_title'] = $otp_popup_title;
        $settings['otp_processing_message'] = $otp_processing_message;
        $settings['otp_placeholder'] = $otp_placeholder;
        $settings['otp_verify_button_text'] = $otp_verify_button_text;
        $settings['otp_resend_button_text'] = $otp_resend_button_text;
        $settings['otp_resend_countdown_text'] = $otp_resend_countdown_text;
        $settings['otp_invalid_phone_message'] = $otp_invalid_phone_message;
        $settings['otp_try_again_text'] = $otp_try_again_text;
        $settings['otp_generic_error_message'] = $otp_generic_error_message;
        $settings['otp_sent_message'] = $otp_sent_message;
        $settings['otp_verified_message'] = $otp_verified_message;
        $settings['otp_invalid_code_message'] = $otp_invalid_code_message;
        $sms_balance = get_option('orderdetect_sms_balance');
        update_option('orderdetect_settings', $settings);
        wp_send_json_success(array('message' => 'OTP Settings Saved Successfully!') );

    }

    public function save_order_alerts() {
        check_ajax_referer('order-detect-admin-nonce', 'security');

        if ( ! current_user_can('manage_woocommerce') ) {
            wp_send_json_error(array('message' => __('You do not have permission to perform this action.', 'order-detect')), 403);
            return;
        }

        if ( ! $this->require_active_license() ) {
            return;
        }
    
        $settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => '',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => '',
                'mimsms' => '',
                'bulksmsbd' => ''
            ),
            'mimsms_sender_id' => '',
            'mimsms_username' => '',
            'bulksmsbd_sender_id' => '',
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));
        
        if (isset($_POST['settings']) && is_array($_POST['settings'])) {
            $new_settings = $_POST['settings'];
            
            foreach ($new_settings as $key => $value) {
                $settings[$key] = sanitize_text_field($value);
            }
        }
    
        update_option('orderdetect_settings', $settings);
    
        wp_send_json_success(array('message' => 'Settings Saved Successfully!'));
    }

    public function update_phone_number_status() {

        check_ajax_referer('order-detect-admin-nonce', 'security');

        if ( ! current_user_can('manage_woocommerce') ) {
            wp_send_json_error(array('message' => __('You do not have permission to perform this action.', 'order-detect')), 403);
            return;
        }

        if ( ! $this->require_active_license() ) {
            return;
        }

        $id = isset($_POST['id']) ? intval(wp_unslash($_POST['id'])) : 0;
        $is_verified = isset($_POST['is_verified']) ? intval(wp_unslash($_POST['is_verified'])) : 0;
        if( $id > 0 && is_numeric( $id ) && in_array($is_verified, [0, 1], true) ) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'od_otp_log';
            $updated = $wpdb->update(
                $table_name,
                [ 'is_verified' => $is_verified ],
                [ 'id' => $id ],
                [ '%d' ],
                [ '%d' ]
            );
    
            if (false !== $updated) {
                wp_send_json_success([ 'message' => __('Status updated successfully.', 'order-detect') ]);
            } else {
                wp_send_json_error([ 'message' => __('Failed to update the status.', 'order-detect') ]);
            }
        } else {
            wp_send_json_error([ 'message' => __('Invalid ID or status value.', 'order-detect') ]);
        }
    }

}

