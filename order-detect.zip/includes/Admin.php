<?php

namespace OrderDetect;

class Admin {

    function __construct() {
        $main = new Admin\Main();
        new Admin\Menu($main);
        new Admin\OTPReports($main);
    }
}

function csod_add_column($columns) {

    if ( ! Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
        return $columns;
    }

    $new_columns = [];

    foreach ($columns as $key => $label) {

        $new_columns[$key] = $label;

        // HPOS
        if ($key === 'order_number') {
            $new_columns['csod_courier_score'] = 'Score';
        }

        // Non-HPOS fallback
        if ($key === 'order_title') {
            $new_columns['csod_courier_score'] = 'Score';
        }
    }

    return $new_columns;

}

add_filter('manage_woocommerce_page_wc-orders_columns', __NAMESPACE__ . '\csod_add_column');
add_filter('manage_edit-shop_order_columns', __NAMESPACE__ . '\csod_add_column');

function render_csod_column_hpos($column, $order) {
    
    if ( ! Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
        return;
    }

    if ($column !== 'csod_courier_score') {
        return;
    }

    $order_id = is_object($order) ? $order->get_id() : (int) $order;
    $order    = wc_get_order($order_id);
    
    $courier_data = $order->get_meta('_csod_score_response') ?? '';

    if (empty($courier_data)) {

        csod_courier_check_button($order_id);
    } else {
        $total_data = $courier_data['total_data'];

        ?>
        <div class="csod-order-section csod-order-section--column">
        <div class="csod-total-section">

            <div class="csod-total">
                <h3 class="csod-total-value"><?php echo (int)$total_data['total']; ?></h3>
                <p class="csod-total-title">TOTAL</p>
            </div>

            <div class="csod-total">
                <h3 class="csod-total-value csod-delivered"><?php echo (int)$total_data['delivered']; ?></h3>
                <p class="csod-total-title">DELIVERD</p>
            </div>

            <div class="csod-total">
                <h3 class="csod-total-value csod-returned"><?php echo (int)$total_data['returned']; ?></h3>
                <p class="csod-total-title">RETURNED</p>
            </div>

            <div class="csod-total">
                <h3 class="csod-total-value"><?php echo round((float)$total_data['success_ratio'], 2); ?>%</h3>
                <p class="csod-total-title">SUCCESS</p>
            </div>

        </div>
        </div>

        <?php
    }

}

add_action('manage_shop_order_posts_custom_column',__NAMESPACE__ . '\render_csod_column_hpos',10,2);
add_action('manage_woocommerce_page_wc-orders_custom_column', __NAMESPACE__ . '\render_csod_column_hpos', 10, 2);

function csod_add_order_section($order) {

    if ( ! Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
        return;
    }

    if (!$order || !is_a($order, 'WC_Order')) {
        return;
    }

    $order_id = $order->get_id();

    $courier_data = $order->get_meta('_csod_score_response') ?? '';

    if (empty($courier_data)) {

        csod_courier_check_button($order_id);

        
    } else {

        $total_data = $courier_data['total_data'];
        $steadfast = $courier_data['couriers']['steadfast'];
        $pathao = $courier_data['couriers']['pathao'];
        $redx = $courier_data['couriers']['redx'];
        $carrybee = $courier_data['couriers']['carrybee'];
        $bahok = $courier_data['couriers']['bahok'];
        ?>

        

        <div class="csod-order-section">
            <div class="csod-total-section">

                <div class="csod-total">
                    <h3 class="csod-total-value"><?php echo (int)$total_data['total']; ?></h3>
                    <p class="csod-total-title">TOTAL</p>
                </div>

                <div class="csod-total">
                    <h3 class="csod-total-value csod-delivered"><?php echo (int)$total_data['delivered']; ?></h3>
                    <p class="csod-total-title">DELIVERD</p>
                </div>

                <div class="csod-total">
                    <h3 class="csod-total-value csod-returned"><?php echo (int)$total_data['returned']; ?></h3>
                    <p class="csod-total-title">RETURNED</p>
                </div>

                <div class="csod-total">
                    <h3 class="csod-total-value"><?php echo round((float)$total_data['success_ratio'], 2); ?>%</h3>
                    <p class="csod-total-title">SUCCESS</p>
                </div>

            </div>

            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>Courier</th>
                        <th>Total</th>
                        <th>Delivered</th>
                        <th>Returned</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Steadfast</td>
                        <td><?php echo (int)($steadfast['total'] ?? 0); ?></td>
                        <td><?php echo (int)($steadfast['successful'] ?? 0); ?></td>
                        <td><?php echo (int)($steadfast['returned'] ?? 0); ?></td>
                    </tr>

                    <tr>
                        <td>Pathao</td>
                        <td><?php echo (int)($pathao['total'] ?? 0); ?></td>
                        <td><?php echo (int)($pathao['successful'] ?? 0); ?></td>
                        <td><?php echo (int)($pathao['returned'] ?? 0); ?></td>
                    </tr>

                    <tr>
                        <td>Redx</td>
                        <td><?php echo (int)($redx['total'] ?? 0); ?></td>
                        <td><?php echo (int)($redx['successful'] ?? 0); ?></td>
                        <td><?php echo (int)($redx['returned'] ?? 0); ?></td>
                    </tr>

                    <tr>
                        <td>Bahok</td>
                        <td><?php echo (int)($bahok['total'] ?? 0); ?></td>
                        <td><?php echo (int)($bahok['successful'] ?? 0); ?></td>
                        <td><?php echo (int)($bahok['returned'] ?? 0); ?></td>
                    </tr>

                    <tr>
                        <td>Carrybee</td>
                        <td><?php echo (int)($carrybee['total'] ?? 0); ?></td>
                        <td><?php echo (int)($carrybee['successful'] ?? 0); ?></td>
                        <td><?php echo (int)($carrybee['returned'] ?? 0); ?></td>
                    </tr>
                </tbody>
        </table>
        </div>
        <?php
        csod_courier_check_button($order_id);
    }
}
add_action('woocommerce_admin_order_data_after_billing_address',__NAMESPACE__ . '\csod_add_order_section',9999,1);

function csod_admin_footer_script() {
    if ( ! Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
        return;
    }
    ?>
    <script>
    jQuery(document).on('click', '.csod-check-btn', function (e) {
        e.preventDefault();

        const btn = jQuery(this);
        const orderId = btn.data('order-id');

        btn.prop('disabled', true).text('Checking...');

        jQuery.post(ajaxurl, {
            action: 'csod_check_and_save',
            order_id: orderId,
            nonce: '<?php echo esc_js( wp_create_nonce('order-detect') ); ?>'
        }, function () {
            location.reload();
        });
    });
    </script>
    <?php
}
add_action('admin_footer', __NAMESPACE__ . '\csod_admin_footer_script');

function ddo_add_duplicate_column($columns) {
    if ( ! Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
        return $columns;
    }

    $new = [];
    $inserted = false;

    foreach ($columns as $key => $label) {
        if ($key === 'order_date' && ! $inserted) {
            $new['ddo_duplicate'] = __('Duplicate?', 'detect-duplicate-order');
            $inserted = true;
        }
        $new[$key] = $label;
    }

    if (! $inserted) {
        $new['ddo_duplicate'] = __('Duplicate?', 'detect-duplicate-order');
    }

    return $new;
}

\add_filter('manage_edit-shop_order_columns', __NAMESPACE__ . '\ddo_add_duplicate_column', 20);
\add_filter('manage_woocommerce_page_wc-orders_columns', __NAMESPACE__ . '\ddo_add_duplicate_column', 20);


function obn_render_column($columns){
    if ( ! Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
        return $columns;
    }
    
    $columns['obn_admin_column'] = 'Block Action';
    return $columns;
}
add_filter('manage_edit-shop_order_columns', __NAMESPACE__ . '\obn_render_column');
add_filter('manage_woocommerce_page_wc-orders_columns', __NAMESPACE__ . '\obn_render_column');

add_action('manage_woocommerce_page_wc-orders_custom_column', function($column, $order) {
    if ($column === 'obn_admin_column') {
        obn_render_button($order);
    }
}, 10, 2);

add_action('manage_shop_order_posts_custom_column', function($column, $post_id) {
    if ($column === 'obn_admin_column') {
        $order = wc_get_order($post_id);
        obn_render_button($order);
    }
}, 10, 2);


add_action('admin_footer', function () {
    $screen = get_current_screen();
    if (!$screen) { return; }
    if ($screen->id !== 'edit-shop_order' && $screen->id !== 'woocommerce_page_wc-orders') {
        return;
    }
    ?>
    <script type="text/javascript">
    jQuery(document).on('click', '.obn-block-btn', function () {
        var $btn  = jQuery(this);
        var type  = $btn.data('type');
        var value = $btn.data('value');

        if (!value) { 
            alert('âš ï¸ Empty value.'); 
            return; 
        }

        $btn.prop('disabled', true).text('Blocking...');

        jQuery.post(ajaxurl, {
            action: 'obn_save_block',
            type: type,
            value: value,
            _wpnonce: '<?php echo wp_create_nonce("obn_block_nonce"); ?>'
        }, function (response) {
            if (response && response.data) {
                if (response.data.includes('blocked') || response.data.includes('success')) {
                    $btn.text(type.charAt(0).toUpperCase() + type.slice(1) + ' Blocked')
                        .prop('disabled', true);
                } else {
                    $btn.text('Block ' + type.charAt(0).toUpperCase() + type.slice(1))
                        .prop('disabled', false);
                }
            } else {
                $btn.text('Block ' + type.charAt(0).toUpperCase() + type.slice(1))
                    .prop('disabled', false);
            }
        }).fail(function () {
            alert('âŒ Request failed.');
            $btn.prop('disabled', false)
                .text('Block ' + type.charAt(0).toUpperCase() + type.slice(1));
        });
    });
    </script>
    <?php
});


add_action('wp_ajax_obn_save_block', __NAMESPACE__ . '\obn_save_block');
function obn_save_block() {
    if ( ! current_user_can('manage_woocommerce') ) {
        wp_send_json_error('permission denied');
    }
    if ( ! Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
        wp_send_json_error('license inactive');
    }
    check_ajax_referer('obn_block_nonce');

    $type  = isset($_POST['type']) ? sanitize_text_field(wp_unslash($_POST['type'])) : '';
    $value = isset($_POST['value']) ? sanitize_text_field(wp_unslash($_POST['value'])) : '';

    if ($type === '' || $value === '') {
        wp_send_json_error('empty value');
    }

    $allowed = ['phone', 'ip', 'device'];
    if ( ! in_array($type, $allowed, true) ) {
        wp_send_json_error('invalid type');
    }

    global $wpdb;
    $table = $wpdb->prefix . 'obn_blocklist';

    $exists = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $table WHERE type=%s AND value=%s",
        $type,
        $value
    ));
    if ($exists) {
        wp_send_json_success('already blocked');
    }

    $inserted = $wpdb->insert($table, [
        'type'  => $type,
        'value' => $value,
    ], ['%s', '%s']);

    if ($inserted) {
        wp_send_json_success('blocked');
    }

    wp_send_json_error('failed');
}

add_filter('orderdetect_admin_menu', function ($settings) {
    $settings['obn-settings'] = [
        'parent_slug' => 'order-detect',
        'page_title'  => 'Block Settings',
        'menu_title'  => 'Block Settings',
        'capability'  => 'manage_woocommerce',
        'callback'    => __NAMESPACE__ . '\orderdetect_obn_settings_page',
    ];

    $settings['obn-blocklist'] = [
        'parent_slug' => 'order-detect',
        'page_title'  => 'Blocklist',
        'menu_title'  => 'Blocklist',
        'capability'  => 'manage_woocommerce',
        'callback'    => __NAMESPACE__ . '\orderdetect_obn_blocklist_page',
    ];

    $settings['obn-auto-blocklist'] = [
        'parent_slug' => 'order-detect',
        'page_title'  => 'Auto Blocklist',
        'menu_title'  => 'Auto Blocklist',
        'capability'  => 'manage_woocommerce',
        'callback'    => __NAMESPACE__ . '\orderdetect_obn_auto_blocklist_page',
    ];

    return $settings;
});

add_filter('set-screen-option', __NAMESPACE__ . '\obn_set_screen_option', 10, 3);
add_action('load-order-detect_page_obn-blocklist', __NAMESPACE__ . '\obn_add_blocklist_screen_options');
add_action('load-order-detect_page_obn-auto-blocklist', __NAMESPACE__ . '\obn_add_auto_blocklist_screen_options');

function obn_set_screen_option($status, $option, $value) {
    if (in_array($option, ['obn_blocklist_per_page', 'obn_auto_blocklist_per_page'], true)) {
        return $value;
    }
    return $status;
}

function obn_add_blocklist_screen_options() {
    add_screen_option('per_page', [
        'label'   => 'Number of items per page:',
        'default' => 20,
        'option'  => 'obn_blocklist_per_page',
    ]);
}

function obn_add_auto_blocklist_screen_options() {
    add_screen_option('per_page', [
        'label'   => 'Number of items per page:',
        'default' => 20,
        'option'  => 'obn_auto_blocklist_per_page',
    ]);
}

function orderdetect_obn_settings_page() {
    if (!current_user_can('manage_woocommerce')) {
        return;
    }
    if ( ! Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
        wp_die('License inactive.');
    }

    // Handle form submit
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && check_admin_referer('obn_save_messages')) {
        $settings_notice = [
            'class' => 'notice notice-success',
            'text'  => 'Settings updated successfully.',
        ];
        $active_tab = isset($_POST['tab']) ? sanitize_key($_POST['tab']) : 'manual';
        if ($active_tab === 'manual') {
            $manual_enabled_map = [];
            if (isset($_POST['obn_manual_enabled'])) {
                foreach ($_POST['obn_manual_enabled'] as $type => $val) {
                    $manual_enabled_map[$type] = ($val === '1') ? 1 : 0;
                }
            }

            if (isset($_POST['obn_block_messages'])) {
                $messages = array_map('sanitize_text_field', $_POST['obn_block_messages']);
                update_option('obn_block_messages', $messages);
            }

            foreach (['phone', 'ip', 'device'] as $type) {
                $enabled = isset($manual_enabled_map[$type]) ? $manual_enabled_map[$type] : 0;
                $msg = isset($_POST['obn_block_messages'][$type]) ? trim((string) wp_unslash($_POST['obn_block_messages'][$type])) : '';
                if ($enabled === 1 && $msg === '') {
                    $enabled = 0;
                    $settings_notice = [
                        'class' => 'notice notice-warning',
                        'text'  => 'Manual block was not enabled because the message field is empty.',
                    ];
                }
                update_option("obn_manual_enabled_{$type}", $enabled);
            }
        }

        if (in_array($active_tab, ['phone', 'ip', 'device'], true)) {
            $type = $active_tab;
            $enabled = (isset($_POST['obn_auto_enabled'][$type]) && $_POST['obn_auto_enabled'][$type] === '1') ? 1 : 0;
            $limit = isset($_POST['obn_auto_limit'][$type]) ? absint($_POST['obn_auto_limit'][$type]) : 0;
            $duration = isset($_POST['obn_auto_duration'][$type]) ? absint($_POST['obn_auto_duration'][$type]) : 0;
            $message = isset($_POST['obn_auto_message'][$type]) ? sanitize_text_field($_POST['obn_auto_message'][$type]) : '';

            $valid = ($limit > 0 && $duration > 0 && $message !== '');
            if ($enabled === 1 && ! $valid) {
                $enabled = 0;
                $settings_notice = [
                    'class' => 'notice notice-warning',
                    'text'  => 'Auto block was not enabled because required fields were missing.',
                ];
            }
            update_option("obn_auto_enabled_{$type}", $enabled);

            if ($limit > 0) {
                update_option("obn_auto_limit_{$type}", $limit);
            }
            if ($duration > 0) {
                update_option("obn_auto_duration_{$type}", $duration);
            }
            if ($message !== '') {
                update_option("obn_auto_message_{$type}", $message);
            }
        }

        echo '<div class="' . esc_attr($settings_notice['class']) . '"><p>' . esc_html($settings_notice['text']) . '</p></div>';
    }

    // Load current options
    $manual_enabled = [
        'phone'  => (int) get_option('obn_manual_enabled_phone', 0),
        'ip'     => (int) get_option('obn_manual_enabled_ip', 0),
        'device' => (int) get_option('obn_manual_enabled_device', 0),
    ];
    $messages = get_option('obn_block_messages', [
        'phone'  => '',
        'ip'     => '',
        'device' => '',
    ]);

    $auto_enabled = [
        'phone'  => (int) get_option('obn_auto_enabled_phone', 0),
        'ip'     => (int) get_option('obn_auto_enabled_ip', 0),
        'device' => (int) get_option('obn_auto_enabled_device', 0),
    ];
    $auto_limits = [
        'phone'  => get_option('obn_auto_limit_phone', ''),
        'ip'     => get_option('obn_auto_limit_ip', ''),
        'device' => get_option('obn_auto_limit_device', ''),
    ];
    $auto_durations = [
        'phone'  => get_option('obn_auto_duration_phone', ''),
        'ip'     => get_option('obn_auto_duration_ip', ''),
        'device' => get_option('obn_auto_duration_device', ''),
    ];
    $auto_messages = [
        'phone'  => get_option('obn_auto_message_phone', ''),
        'ip'     => get_option('obn_auto_message_ip', ''),
        'device' => get_option('obn_auto_message_device', ''),
    ];
    ?>
    <div class="wrap">
        <h1>Block Settings</h1>
        <?php $active_tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'manual'; ?>
        <h2 class="nav-tab-wrapper">
            <a href="<?php echo esc_url(add_query_arg('tab', 'manual')); ?>" class="nav-tab <?php echo ($active_tab === 'manual') ? 'nav-tab-active' : ''; ?>">Manual Block</a>
            <a href="<?php echo esc_url(add_query_arg('tab', 'phone')); ?>" class="nav-tab <?php echo ($active_tab === 'phone') ? 'nav-tab-active' : ''; ?>">Phone Auto Block</a>
            <a href="<?php echo esc_url(add_query_arg('tab', 'ip')); ?>" class="nav-tab <?php echo ($active_tab === 'ip') ? 'nav-tab-active' : ''; ?>">IP Auto Block</a>
            <a href="<?php echo esc_url(add_query_arg('tab', 'device')); ?>" class="nav-tab <?php echo ($active_tab === 'device') ? 'nav-tab-active' : ''; ?>">Device Auto Block</a>
        </h2>
        <form method="post">
            <?php wp_nonce_field('obn_save_messages'); ?>
            <input type="hidden" name="tab" value="<?php echo esc_attr($active_tab); ?>" />

            <?php if ($active_tab === 'manual') { ?>
            <h2>Manual Block</h2>
            <table class="form-table">
                <tr>
                    <th>Enable Manual Phone Block</th>
                    <td><label><input type="checkbox" name="obn_manual_enabled[phone]" value="1" <?php checked(1, $manual_enabled['phone']); ?> /> Enable</label></td>
                </tr>
                <tr>
                    <th><label for="obn-phone-msg">Phone Block Message</label></th>
                    <td><input type="text" name="obn_block_messages[phone]" id="obn-phone-msg" value="<?php echo esc_attr($messages['phone']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>Enable Manual IP Block</th>
                    <td><label><input type="checkbox" name="obn_manual_enabled[ip]" value="1" <?php checked(1, $manual_enabled['ip']); ?> /> Enable</label></td>
                </tr>
                <tr>
                    <th><label for="obn-ip-msg">IP Block Message</label></th>
                    <td><input type="text" name="obn_block_messages[ip]" id="obn-ip-msg" value="<?php echo esc_attr($messages['ip']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>Enable Manual Device Block</th>
                    <td><label><input type="checkbox" name="obn_manual_enabled[device]" value="1" <?php checked(1, $manual_enabled['device']); ?> /> Enable</label></td>
                </tr>
                <tr>
                    <th><label for="obn-device-msg">Device Block Message</label></th>
                    <td><input type="text" name="obn_block_messages[device]" id="obn-device-msg" value="<?php echo esc_attr($messages['device']); ?>" class="regular-text"></td>
                </tr>
            </table>
            <?php } elseif ($active_tab === 'phone') { ?>
            <h2>Phone Auto Block</h2>
            <table class="form-table">
                <tr>
                    <th>Enable Phone Auto Block</th>
                    <td><label><input type="checkbox" name="obn_auto_enabled[phone]" value="1" <?php checked(1, $auto_enabled['phone']); ?> /> Enable</label></td>
                </tr>
                <tr>
                    <th>Phone Limit</th>
                    <td><input type="number" name="obn_auto_limit[phone]" min="1" value="<?php echo esc_attr($auto_limits['phone']); ?>" /></td>
                </tr>
                <tr>
                    <th>Phone Duration (minutes)</th>
                    <td><input type="number" name="obn_auto_duration[phone]" min="1" value="<?php echo esc_attr($auto_durations['phone']); ?>" /></td>
                </tr>
                <tr>
                    <th>Phone Auto Message</th>
                    <td><input type="text" name="obn_auto_message[phone]" value="<?php echo esc_attr($auto_messages['phone']); ?>" class="regular-text"></td>
                </tr>
            </table>
            <?php } elseif ($active_tab === 'ip') { ?>
            <h2>IP Auto Block</h2>
            <table class="form-table">
                <tr>
                    <th>Enable IP Auto Block</th>
                    <td><label><input type="checkbox" name="obn_auto_enabled[ip]" value="1" <?php checked(1, $auto_enabled['ip']); ?> /> Enable</label></td>
                </tr>
                <tr>
                    <th>IP Limit</th>
                    <td><input type="number" name="obn_auto_limit[ip]" min="1" value="<?php echo esc_attr($auto_limits['ip']); ?>" /></td>
                </tr>
                <tr>
                    <th>IP Duration (minutes)</th>
                    <td><input type="number" name="obn_auto_duration[ip]" min="1" value="<?php echo esc_attr($auto_durations['ip']); ?>" /></td>
                </tr>
                <tr>
                    <th>IP Auto Message</th>
                    <td><input type="text" name="obn_auto_message[ip]" value="<?php echo esc_attr($auto_messages['ip']); ?>" class="regular-text"></td>
                </tr>
            </table>
            <?php } elseif ($active_tab === 'device') { ?>
            <h2>Device Auto Block</h2>
            <table class="form-table">
                <tr>
                    <th>Enable Device Auto Block</th>
                    <td><label><input type="checkbox" name="obn_auto_enabled[device]" value="1" <?php checked(1, $auto_enabled['device']); ?> /> Enable</label></td>
                </tr>
                <tr>
                    <th>Device Limit</th>
                    <td><input type="number" name="obn_auto_limit[device]" min="1" value="<?php echo esc_attr($auto_limits['device']); ?>" /></td>
                </tr>
                <tr>
                    <th>Device Duration (minutes)</th>
                    <td><input type="number" name="obn_auto_duration[device]" min="1" value="<?php echo esc_attr($auto_durations['device']); ?>" /></td>
                </tr>
                <tr>
                    <th>Device Auto Message</th>
                    <td><input type="text" name="obn_auto_message[device]" value="<?php echo esc_attr($auto_messages['device']); ?>" class="regular-text"></td>
                </tr>
            </table>
            <?php } ?>

            <?php submit_button('Save Settings'); ?>
        </form>
    </div>
    <?php
}

function obn_get_block_message($type) {
    $messages = get_option('obn_block_messages', []);
    return $messages[$type] ?? '';
}

function obn_render_admin_pagination($total, $total_pages, $paged, $which) {
    $total       = max(0, (int) $total);
    $total_pages = max(1, (int) $total_pages);
    $paged       = max(1, (int) $paged);
    $base_url    = remove_query_arg('paged');
    $suffix      = ($which === 'top') ? '' : '-2';
    $input_id    = 'current-page-selector' . $suffix;
    $paging_id   = 'table-paging' . $suffix;
    $size        = strlen((string) $total_pages);
    $class       = 'tablenav-pages';

    if ($total_pages <= 1) {
        $class .= ' one-page';
    }

    $first_url = esc_url(add_query_arg('paged', 1, $base_url));
    $prev_url  = esc_url(add_query_arg('paged', max(1, $paged - 1), $base_url));
    $next_url  = esc_url(add_query_arg('paged', min($total_pages, $paged + 1), $base_url));
    $last_url  = esc_url(add_query_arg('paged', $total_pages, $base_url));

    $links = [];

    if ($paged > 1) {
        $links[] = '<a class="first-page button" href="' . $first_url . '"><span class="screen-reader-text">First page</span><span aria-hidden="true">&laquo;</span></a>';
        $links[] = '<a class="prev-page button" href="' . $prev_url . '"><span class="screen-reader-text">Previous page</span><span aria-hidden="true">&lsaquo;</span></a>';
    } else {
        $links[] = '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&laquo;</span>';
        $links[] = '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&lsaquo;</span>';
    }

    $current = '<label for="' . esc_attr($input_id) . '" class="screen-reader-text">Current Page</label>' .
        '<input class="current-page" id="' . esc_attr($input_id) . '" type="text" name="paged" value="' . $paged . '" size="' . $size . '" aria-describedby="' . esc_attr($paging_id) . '" />';
    $links[] = '<span class="paging-input">' . $current . '<span class="tablenav-paging-text" id="' . esc_attr($paging_id) . '"> of <span class="total-pages">' . $total_pages . '</span></span></span>';

    if ($paged < $total_pages) {
        $links[] = '<a class="next-page button" href="' . $next_url . '"><span class="screen-reader-text">Next page</span><span aria-hidden="true">&rsaquo;</span></a>';
        $links[] = '<a class="last-page button" href="' . $last_url . '"><span class="screen-reader-text">Last page</span><span aria-hidden="true">&raquo;</span></a>';
    } else {
        $links[] = '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&rsaquo;</span>';
        $links[] = '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&raquo;</span>';
    }

    $display = number_format_i18n($total) . ' items';

    echo '<div class="' . esc_attr($class) . '"><span class="displaying-num">' . $display . '</span><span class="pagination-links">' . implode('', $links) . '</span></div>';
}

add_action('admin_enqueue_scripts', function () {
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$screen) {
        return;
    }
    if (!in_array($screen->id, ['order-detect_page_obn-blocklist', 'order-detect_page_obn-auto-blocklist'], true)) {
        return;
    }
    wp_enqueue_style('list-tables');
});

function orderdetect_obn_blocklist_page() {
    if ( ! Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
        wp_die('License inactive.');
    }
    global $wpdb;
    $table = $wpdb->prefix . 'obn_blocklist';
    $notice = null;

    // --- Manual add handler ---
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['obn_add_manual'])) {
        check_admin_referer('obn_manual_add');
        $type  = isset($_POST['block_type']) ? sanitize_key($_POST['block_type']) : '';
        $value = isset($_POST['block_value']) ? sanitize_text_field(wp_unslash($_POST['block_value'])) : '';

        if (!in_array($type, ['phone', 'ip', 'device'], true)) {
            $notice = ['class' => 'notice notice-error', 'text' => 'Invalid block type.'];
        } else {
            if ($type === 'phone') {
                $value = obn_normalize_phone($value);
                if ($value === '' || !Helper::is_valid_Bangladeshi_phone_number($value)) {
                    $notice = ['class' => 'notice notice-error', 'text' => 'Invalid phone number.'];
                }
            } elseif ($type === 'ip') {
                if (!filter_var($value, FILTER_VALIDATE_IP)) {
                    $notice = ['class' => 'notice notice-error', 'text' => 'Invalid IP address.'];
                }
            } elseif ($type === 'device') {
                if ($value === '') {
                    $notice = ['class' => 'notice notice-error', 'text' => 'Invalid device value.'];
                }
            }

            if (!$notice) {
                $exists = $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM $table WHERE type=%s AND value=%s",
                    $type,
                    $value
                ));
                if ($exists) {
                    $notice = ['class' => 'notice notice-warning', 'text' => 'This value is already blocked.'];
                } else {
                    $inserted = $wpdb->insert($table, [
                        'type'  => $type,
                        'value' => $value,
                    ], ['%s', '%s']);
                    if ($inserted) {
                        $notice = ['class' => 'notice notice-success', 'text' => 'Block added successfully.'];
                    } else {
                        $notice = ['class' => 'notice notice-error', 'text' => 'Failed to add block.'];
                    }
                }
            }
        }
    }
    $blocklist_table = new Admin\BlocklistList();
    $blocklist_table->prepare_items();
    $search_val = $blocklist_table->search_query;
    $filter_type = $blocklist_table->type_filter;
    ?>
    <div class="wrap">
        <h1>Blocklist</h1>
        <?php if ($notice) { ?>
            <div class="<?php echo esc_attr($notice['class']); ?>"><p><?php echo esc_html($notice['text']); ?></p></div>
        <?php } ?>

        <h2>Add to Manual Blocklist</h2>
        <form method="post">
            <?php wp_nonce_field('obn_manual_add'); ?>
            <input type="hidden" name="obn_add_manual" value="1" />
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="obn-block-type">Type</label></th>
                    <td>
                        <select name="block_type" id="obn-block-type">
                            <option value="phone">Phone</option>
                            <option value="ip">IP</option>
                            <option value="device">Device</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="obn-block-value">Value</label></th>
                    <td>
                        <input type="text" name="block_value" id="obn-block-value" class="regular-text" placeholder="e.g. 01XXXXXXXXX or 1.2.3.4" required />
                    </td>
                </tr>
            </table>
            <?php submit_button('Add Block'); ?>
        </form>

        <form method="get">
            <input type="hidden" name="page" value="obn-blocklist" />
            <div class="tablenav top">
                <div class="alignleft actions">
                    <label class="screen-reader-text" for="obn-type-filter">Filter Type:</label>
                    <select id="obn-type-filter" name="type">
                        <option value="">All</option>
                        <option value="phone" <?php selected($filter_type, 'phone'); ?>>Phone</option>
                        <option value="ip" <?php selected($filter_type, 'ip'); ?>>IP</option>
                        <option value="device" <?php selected($filter_type, 'device'); ?>>Device</option>
                    </select>
                    <input type="submit" id="filter-submit" class="button" value="Filter" />
                </div>
                <p class="search-box">
                    <label class="screen-reader-text" for="obn-search-input">Search Blocks:</label>
                    <input type="search" id="obn-search-input" name="s" value="<?php echo esc_attr($search_val); ?>" />
                    <input type="submit" id="search-submit" class="button" value="Search" />
                </p>
                <br class="clear">
            </div>
        </form>

        <form method="post">
            <input type="hidden" name="page" value="obn-blocklist" />
            <?php if ($search_val !== '') { ?>
                <input type="hidden" name="s" value="<?php echo esc_attr($search_val); ?>" />
            <?php } ?>
            <?php if ($filter_type !== '') { ?>
                <input type="hidden" name="type" value="<?php echo esc_attr($filter_type); ?>" />
            <?php } ?>
            <?php $blocklist_table->display(); ?>
        </form>
    </div>
    <?php
}

function orderdetect_obn_auto_blocklist_page() {
    if ( ! Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
        wp_die('License inactive.');
    }
    $auto_blocklist_table = new Admin\AutoBlocklistList();
    $auto_blocklist_table->prepare_items();
    $search_val = $auto_blocklist_table->search_query;
    $filter_type = $auto_blocklist_table->type_filter;
    ?>
    <div class="wrap">
        <h1>Auto Blocklist</h1>
        <form method="get">
            <input type="hidden" name="page" value="obn-auto-blocklist" />
            <div class="tablenav top">
                <div class="alignleft actions">
                    <label class="screen-reader-text" for="obn-auto-type-filter">Filter Type:</label>
                    <select id="obn-auto-type-filter" name="type">
                        <option value="">All</option>
                        <option value="phone" <?php selected($filter_type, 'phone'); ?>>Phone</option>
                        <option value="ip" <?php selected($filter_type, 'ip'); ?>>IP</option>
                        <option value="device" <?php selected($filter_type, 'device'); ?>>Device</option>
                    </select>
                    <input type="submit" id="filter-submit" class="button" value="Filter" />
                </div>
                <p class="search-box">
                    <label class="screen-reader-text" for="obn-auto-search-input">Search Auto Blocklist:</label>
                    <input type="search" id="obn-auto-search-input" name="s" value="<?php echo esc_attr($search_val); ?>" />
                    <input type="submit" id="search-submit" class="button" value="Search" />
                </p>
                <br class="clear">
            </div>
        </form>

        <form method="post">
            <input type="hidden" name="page" value="obn-auto-blocklist" />
            <?php if ($search_val !== '') { ?>
                <input type="hidden" name="s" value="<?php echo esc_attr($search_val); ?>" />
            <?php } ?>
            <?php if ($filter_type !== '') { ?>
                <input type="hidden" name="type" value="<?php echo esc_attr($filter_type); ?>" />
            <?php } ?>
            <?php $auto_blocklist_table->display(); ?>
        </form>
    </div>
    <?php
}
