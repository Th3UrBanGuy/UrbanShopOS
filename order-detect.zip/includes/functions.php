<?php
use OrderDetect\Helper;

if ( ! function_exists( 'obn_license_active' ) ) {
    function obn_license_active() {
        if ( ! class_exists( 'OrderDetect\\Helper' ) ) {
            return false;
        }
        return Helper::check_license( wp_parse_args( get_option( 'orderdetect_license' ) ) );
    }
}

if ( ! function_exists( 'obn_get_block_message' ) ) {
    function obn_get_block_message( $type ) {
        $messages = get_option( 'obn_block_messages', [] );
        return isset( $messages[ $type ] ) ? (string) $messages[ $type ] : '';
    }
}


if ( ! function_exists( 'obn_utc_datetime_to_timestamp' ) ) {
    function obn_utc_datetime_to_timestamp( $datetime ) {
        $dt = date_create( (string) $datetime, new DateTimeZone( 'UTC' ) );
        return $dt ? $dt->getTimestamp() : 0;
    }
}

function normalize_customer_phone_number( $phone_number ) {
    $normalized = preg_replace('/[^\d+]/', '', $phone_number);
    if (substr($normalized, 0, 3) === '+88') {
        $normalized = substr($normalized, 3);
    } elseif (substr($normalized, 0, 2) === '88') {
        $normalized = substr($normalized, 2);
    }
    return $normalized;
}

if ( ! function_exists( 'remove_admin_notices_on_plugin_pages' ) ) {
    function remove_admin_notices_on_plugin_pages() {
        return;
    }
    add_action( 'in_admin_header', 'remove_admin_notices_on_plugin_pages', PHP_INT_MAX );
}

if ( ! function_exists( 'orderdetect_license_expiry_admin_notice' ) ) {
    function orderdetect_license_expiry_admin_notice( $force_echo = false ) {
        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $current_screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
        $is_plugin_screen = $current_screen
            && (
                $current_screen->id === 'toplevel_page_order-detect'
                || strpos( $current_screen->id, 'order-detect_page_' ) === 0
            );

        if ( $is_plugin_screen && ! $force_echo ) {
            return;
        }

        $settings = wp_parse_args( get_option( 'orderdetect_license' ) );
        $encrypted_expires = isset( $settings['expires'] ) ? (string) $settings['expires'] : '';

        if ( empty( $encrypted_expires ) ) {
            return;
        }

        $expires = Helper::decrypt_data( $encrypted_expires, ORDERDETECT_ENCRYPTION_KEY, ORDERDETECT_IV );
        if ( empty( $expires ) || $expires === 'lifetime' ) {
            return;
        }

        $expiry_timestamp = strtotime( $expires );
        if ( ! $expiry_timestamp ) {
            return;
        }

        $current_timestamp = current_time( 'timestamp' );
        $seconds_remaining = $expiry_timestamp - $current_timestamp;
        $days_remaining = (int) ceil( $seconds_remaining / DAY_IN_SECONDS );

        if ( $days_remaining > 7 ) {
            return;
        }


        if ( $seconds_remaining <= 0 ) {
            $message = __( 'Your Order Detect license has expired. Renew it to keep block and fraud-prevention features active.', 'order-detect' );
        } else {
            $date_format = get_option( 'date_format' );
            $time_format = get_option( 'time_format' );
            $expiry_display = date_i18n( trim( $date_format . ' ' . $time_format ), $expiry_timestamp );
            $message = sprintf(
                __( 'Your Order Detect license will expire on %1$s. Only %2$d day(s) left.', 'order-detect' ),
                $expiry_display,
                $days_remaining
            );
        }
        $renew_url = 'https://neurodigitalbd.com/step/order-detect-checkout/';

        $html  = '<div class="notice notice-warning">';
        $html .= '<p>' . esc_html( $message ) . '</p>';
        $html .= '<p><a class="button button-primary" target="_blank" rel="noopener noreferrer" href="' . esc_url( $renew_url ) . '">Renew License</a></p>';
        $html .= '</div>';

        echo $html;
    }

    add_action( 'admin_notices', 'orderdetect_license_expiry_admin_notice' );
}

if ( ! function_exists( 'od_send_alerts_based_on_order_status' ) ) {
    function od_send_alerts_based_on_order_status($phone_number, $message) {

        global $odSmsProvider;
        $settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => '',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => '',
                'mimsms' => '',
                'bulksmsbd' => ''
            ),
            'mimsms_sender_id' => '',
            'mimsms_username' => '',
            'bulksmsbd_sender_id' => '',
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));
        $sms_provider = isset($settings['sms_provider']) ? (string) $settings['sms_provider'] : '';
        $endpoint = isset($odSmsProvider[$sms_provider]) ? $odSmsProvider[$sms_provider] : '';
        $api_key = isset($settings['sms_api_key'][$sms_provider]) ? $settings['sms_api_key'][$sms_provider] : '';
        $to = Helper::validate_and_format_phone_number( $phone_number );
        $smsresult = null;
        $sms_sent = false;
        $error_code = null;
        $error_message = null;

        if ( empty($endpoint) || empty($api_key) || empty($to) ) {
            return [
                'success' => false,
                'error' => [
                    'code' => 'config',
                    'message' => 'SMS not configured',
                ],
                'provider' => $settings['sms_provider'],
            ];
        }

        if( "greenweb" === $sms_provider ) {
            $endpoint .= '/api.php';
            $data = [
                'to'=>"$to",
                'message'=>"$message",
                'token'=>"$api_key"
            ];
        } else if( "alpha" === $sms_provider ) {
            $endpoint .= '/sendsms';
            $data = [
                'to'=>"$to",
                'msg'=>"$message",
                'api_key'=>"$api_key"
            ];
        } else if( "dianahost" === $sms_provider ) {
            $endpoint .= '/sms/send';
            $data = [
                'recipient'=>"$to",
                'type' => 'plain',
                'sender_id' => $settings['dianahost_sender_id'],
                'message'=>"$message",
            ];
        } else if( "mimsms" === $sms_provider ) {
            $endpoint .= '/SmsSending/Send';
            $data = [
                'UserName' => $settings['mimsms_username'],
                'Apikey' => "$api_key",
                'MobileNumber' => "$to",
                'SenderName' => $settings['mimsms_sender_id'],
                'TransactionType' => 'T',
                'Message' => "$message",
            ];
            
        } else if( "bulksmsbd" === $sms_provider ) {
            $endpoint .= '/smsapi';
            $data = [
                'number'=>"$to",
                'type' => 'text',
                'api_key'=>"$api_key",
                'senderid' => $settings['bulksmsbd_sender_id'],
                'message'=>"$message",
            ];
        }

        if( "mimsms" === $sms_provider ){
            $url = $endpoint . '?' . http_build_query($data);
            $response = wp_remote_get($url, array(
                'timeout' => 20,
                'redirection' => 2,
            ));

            if ( is_wp_error($response) ) {
                error_log('Order Detect Mimsms WP Error: ' . $response->get_error_message());
                $sms_sent = false;
                $error_message = $response->get_error_message();
            } else {
                $http_code = wp_remote_retrieve_response_code($response);
                $smsresult = wp_remote_retrieve_body($response);
                $parsed = od_mimsms_parse_response($smsresult, $http_code);
                $sms_sent = $parsed['success'];
                $error_code = $parsed['code'];
                $error_message = $parsed['message'];
            }
        } else {
            $ch = curl_init(); 
            curl_setopt($ch, CURLOPT_URL, $endpoint);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
            curl_setopt($ch, CURLOPT_TIMEOUT, 20);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($ch, CURLOPT_ENCODING, '');
    
            if( "dianahost" === $sms_provider ) {
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Accept: application/json',
                    "Authorization: Bearer $api_key",
                    "Content-Type: application/json"
                ));
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            } else {
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            }
    
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $smsresult = curl_exec($ch);
            $http_code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);

            if ($smsresult === false) {
                error_log('cURL Error: ' . curl_error($ch));
            } else {
                error_log('cURL Response: ' . $smsresult);
            }
            curl_close($ch);

            if ($smsresult === false || $http_code >= 400) {
                $sms_sent = false;
                $error_code = $http_code ?: null;
                $error_message = 'SMS sending failed';
            } elseif ( "greenweb" === $sms_provider ) {
                $parsed = od_greenweb_parse_response($smsresult, $http_code);
                $sms_sent = $parsed['success'];
                $error_code = $parsed['code'];
                $error_message = $parsed['message'];
            } elseif ( "dianahost" === $sms_provider ) {
                $parsed = od_dianahost_parse_response($smsresult, $http_code);
                $sms_sent = $parsed['success'];
                $error_code = $parsed['code'];
                $error_message = $parsed['message'];
            } elseif ( "bulksmsbd" === $sms_provider ) {
                $parsed = od_bulksmsbd_parse_response($smsresult);
                $sms_sent = $parsed['success'];
                $error_code = $parsed['code'];
                $error_message = $parsed['message'];
            } elseif ( "alpha" === $sms_provider ) {
                $parsed = od_alpha_parse_response($smsresult);
                $sms_sent = $parsed['success'];
                $error_code = $parsed['code'];
                $error_message = $parsed['message'];
            } else {
                $sms_sent = ( $smsresult !== false && $smsresult !== null && $smsresult !== '' );
                if ( ! $sms_sent ) {
                    $error_message = 'SMS sending failed';
                }
            }
        }

        od_schedule_sms_balance_refresh();

        if ( ! $sms_sent ) {
            return [
                'success' => false,
                'error' => [
                    'code' => $error_code,
                    'message' => $error_message ?: 'SMS sending failed',
                ],
                'provider' => $sms_provider,
            ];
        }

        return [
            'success' => true,
            'provider' => $sms_provider,
        ];
    }
}

if ( ! function_exists( 'od_schedule_async_action' ) ) {
    function od_schedule_async_action( $hook, $args = array(), $group = 'order-detect', $delay = 5 ) {
        od_queue_shutdown_async_action($hook, $args);
    }
}

if ( ! function_exists( 'od_get_allowed_async_hooks' ) ) {
    function od_get_allowed_async_hooks() {
        return array(
            'od_async_refresh_sms_balance',
            'od_async_order_status_notification',
            'csod_async_check_score',
        );
    }
}

if ( ! function_exists( 'od_queue_shutdown_async_action' ) ) {
    function od_queue_shutdown_async_action( $hook, $args = array() ) {
        if ( ! in_array($hook, od_get_allowed_async_hooks(), true) ) {
            return;
        }

        if ( ! isset($GLOBALS['od_shutdown_async_tasks']) || ! is_array($GLOBALS['od_shutdown_async_tasks']) ) {
            $GLOBALS['od_shutdown_async_tasks'] = array();
        }

        $args = array_values((array) $args);
        $task_key = md5($hook . '|' . wp_json_encode($args));
        $GLOBALS['od_shutdown_async_tasks'][$task_key] = array(
            'hook' => $hook,
            'args' => $args,
        );
    }
}

if ( ! function_exists( 'od_run_shutdown_async_tasks' ) ) {
    function od_run_shutdown_async_tasks() {
        if (empty($GLOBALS['od_shutdown_async_tasks']) || ! is_array($GLOBALS['od_shutdown_async_tasks'])) {
            return;
        }

        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        }

        while ( ! empty($GLOBALS['od_shutdown_async_tasks']) && is_array($GLOBALS['od_shutdown_async_tasks']) ) {
            $tasks = $GLOBALS['od_shutdown_async_tasks'];
            $GLOBALS['od_shutdown_async_tasks'] = array();

            foreach ($tasks as $task) {
                $hook = isset($task['hook']) ? $task['hook'] : '';
                $args = isset($task['args']) && is_array($task['args']) ? $task['args'] : array();

                if ( ! in_array($hook, od_get_allowed_async_hooks(), true) ) {
                    continue;
                }

                do_action_ref_array($hook, $args);
            }
        }
    }
}
\add_action('shutdown', __NAMESPACE__ . '\od_run_shutdown_async_tasks', PHP_INT_MAX);

if ( ! function_exists( 'od_schedule_sms_balance_refresh' ) ) {
    function od_schedule_sms_balance_refresh() {
        od_schedule_async_action('od_async_refresh_sms_balance');
    }
}

if ( ! function_exists( 'od_async_refresh_sms_balance_handler' ) ) {
    function od_async_refresh_sms_balance_handler() {
        if ( ! obn_license_active() ) {
            return;
        }

        Helper::update_balance();
        Helper::send_sms_balance_notification();
    }
}
\add_action('od_async_refresh_sms_balance', __NAMESPACE__ . '\od_async_refresh_sms_balance_handler');

if ( ! function_exists( 'od_mimsms_is_success' ) ) {
    function od_mimsms_is_success( $body, $http_code = 0 ) {
        $parsed = od_mimsms_parse_response($body, $http_code);
        return $parsed['success'];
    }
}

if ( ! function_exists( 'od_mimsms_code_message' ) ) {
    function od_mimsms_code_message( $code ) {
        $map = [
            200 => 'SMS Send Successfully',
            401 => 'Unauthorized',
            208 => 'Invalid Sender ID',
            205 => 'Invalid Message Content',
            206 => 'Invalid Mobile Number',
            209 => 'SMS Length cross the Max level',
            221 => 'SMS Sending Failed',
            500 => 'Internal Server Error',
            213 => 'Parameter Mismatch',
            216 => 'Insufficient Balance',
            210 => 'Invalid CampaignId',
            207 => 'Invalid Transaction Type',
        ];

        return isset($map[$code]) ? $map[$code] : null;
    }
}

if ( ! function_exists( 'od_mimsms_parse_response' ) ) {
    function od_mimsms_parse_response( $body, $http_code = 0 ) {
        $body = is_string($body) ? trim($body) : '';
        if ($body === '') {
            return [
                'success' => false,
                'code' => null,
                'message' => null,
            ];
        }

        $decoded = json_decode($body, true);
        if ( json_last_error() === JSON_ERROR_NONE && is_array($decoded) ) {
            $code = null;
            $status = null;

            foreach (array('code', 'Code', 'statusCode', 'StatusCode', 'responsecode', 'ResponseCode') as $key) {
                if (array_key_exists($key, $decoded)) {
                    $code = (int) $decoded[$key];
                    break;
                }
            }
            foreach (array('status', 'Status', 'statue', 'Statue', 'result', 'Result') as $key) {
                if (array_key_exists($key, $decoded)) {
                    $status = strtoupper((string) $decoded[$key]);
                    break;
                }
            }

            if ($code !== null) {
                return [
                    'success' => ($code === 200),
                    'code' => $code,
                    'message' => od_mimsms_code_message($code),
                ];
            }
            if ($status !== null) {
                return [
                    'success' => ($status === 'SUCCESS'),
                    'code' => null,
                    'message' => $status === 'SUCCESS' ? null : 'SMS Sending Failed',
                ];
            }
        }

        if (preg_match('/\b(200|401|208|205|206|209|221|500|213|216|210|207)\b/', $body, $m)) {
            $code = (int) $m[1];
            return [
                'success' => ($code === 200),
                'code' => $code,
                'message' => od_mimsms_code_message($code),
            ];
        }

        if ($http_code >= 200 && $http_code < 300 && stripos($body, 'success') !== false) {
            return [
                'success' => true,
                'code' => null,
                'message' => null,
            ];
        }

        return [
            'success' => false,
            'code' => null,
            'message' => 'SMS Sending Failed',
        ];
    }
}

if ( ! function_exists( 'od_alpha_code_message' ) ) {
    function od_alpha_code_message( $code ) {
        $map = [
            0 => 'Success',
            400 => 'Missing or invalid parameter',
            403 => 'Permission denied',
            404 => 'Resource not found',
            405 => 'Authorization required',
            409 => 'Unknown server error',
            410 => 'Account expired',
            411 => 'Reseller account expired or suspended',
            412 => 'Invalid schedule',
            413 => 'Invalid sender ID',
            414 => 'Message is empty',
            415 => 'Message is too long',
            416 => 'No valid number found',
            417 => 'Insufficient balance',
            420 => 'Content blocked',
            421 => 'Restricted to registered phone number',
        ];

        return isset($map[$code]) ? $map[$code] : null;
    }
}

if ( ! function_exists( 'od_alpha_parse_response' ) ) {
    function od_alpha_parse_response( $body ) {
        $body = is_string($body) ? trim($body) : '';
        if ($body === '') {
            return [
                'success' => false,
                'code' => null,
                'message' => null,
            ];
        }

        $decoded = json_decode($body, true);
        if ( json_last_error() === JSON_ERROR_NONE && is_array($decoded) ) {
            $code = null;
            $message = null;

            if (array_key_exists('error', $decoded)) {
                $code = (int) $decoded['error'];
            } elseif (array_key_exists('code', $decoded)) {
                $code = (int) $decoded['code'];
            }

            if (array_key_exists('msg', $decoded)) {
                $message = (string) $decoded['msg'];
            } elseif (array_key_exists('message', $decoded)) {
                $message = (string) $decoded['message'];
            }

            if ($code !== null) {
                return [
                    'success' => ($code === 0),
                    'code' => $code,
                    'message' => $message ?: (od_alpha_code_message($code) ?: $body),
                ];
            }
        }

        if (preg_match('/\b(0|400|403|404|405|409|410|411|412|413|414|415|416|417|420|421)\b/', $body, $m)) {
            $code = (int) $m[1];
            return [
                'success' => ($code === 0),
                'code' => $code,
                'message' => od_alpha_code_message($code) ?: $body,
            ];
        }

        return [
            'success' => false,
            'code' => null,
            'message' => $body,
        ];
    }
}

if ( ! function_exists( 'od_greenweb_parse_response' ) ) {
    function od_greenweb_parse_response( $body, $http_code = 0 ) {
        $body = is_string($body) ? trim($body) : '';

        if ($body === '') {
            return [
                'success' => false,
                'code' => $http_code ?: null,
                'message' => 'Empty response from SMS provider',
            ];
        }

        if ($http_code >= 400) {
            return [
                'success' => false,
                'code' => $http_code,
                'message' => $body,
            ];
        }

        if (stripos($body, 'error') !== false) {
            return [
                'success' => false,
                'code' => $http_code ?: null,
                'message' => $body,
            ];
        }

        return [
            'success' => true,
            'code' => $http_code ?: null,
            'message' => null,
        ];
    }
}

if ( ! function_exists( 'od_dianahost_parse_response' ) ) {
    function od_dianahost_parse_response( $body, $http_code = 0 ) {
        $body = is_string($body) ? trim($body) : '';

        if ($body === '') {
            return [
                'success' => false,
                'code' => $http_code ?: null,
                'message' => 'Empty response from SMS provider',
            ];
        }

        $decoded = json_decode($body, true);
        if ( json_last_error() === JSON_ERROR_NONE && is_array($decoded) ) {
            $status = isset($decoded['status']) ? strtolower((string) $decoded['status']) : '';
            $message = '';

            foreach (['msg', 'message', 'error'] as $key) {
                if (!empty($decoded[$key])) {
                    $message = (string) $decoded[$key];
                    break;
                }
            }

            return [
                'success' => ($status === 'success'),
                'code' => $http_code ?: null,
                'message' => $message ?: ($status === 'success' ? null : $body),
            ];
        }

        return [
            'success' => ($http_code >= 200 && $http_code < 300 && stripos($body, 'success') !== false),
            'code' => $http_code ?: null,
            'message' => ($http_code >= 200 && $http_code < 300 && stripos($body, 'success') !== false) ? null : $body,
        ];
    }
}

if ( ! function_exists( 'od_bulksmsbd_parse_response' ) ) {
    function od_bulksmsbd_parse_response( $body, $http_code = 0 ) {
        $body = is_string($body) ? trim($body) : '';
        if ($body === '') {
            return [
                'success' => false,
                'code' => null,
                'message' => null,
            ];
        }

        $decoded = json_decode($body, true);
        if ( json_last_error() === JSON_ERROR_NONE && is_array($decoded) ) {
            $code = null;
            $message = null;
            $status = null;

            foreach (array('code', 'Code', 'response_code', 'responseCode', 'statusCode', 'StatusCode') as $key) {
                if (array_key_exists($key, $decoded)) {
                    $code = (int) $decoded[$key];
                    break;
                }
            }
            foreach (array('message', 'Message', 'msg') as $key) {
                if (array_key_exists($key, $decoded)) {
                    $message = (string) $decoded[$key];
                    break;
                }
            }
            foreach (array('status', 'Status', 'result', 'Result') as $key) {
                if (array_key_exists($key, $decoded)) {
                    $status = strtolower((string) $decoded[$key]);
                    break;
                }
            }

            if ($code !== null) {
                return [
                    'success' => ($code === 202),
                    'code' => $code,
                    'message' => $message ?: (od_bulksmsbd_code_message($code) ?: $body),
                ];
            }
            if ($status !== null) {
                $ok = (strpos($status, 'success') !== false || $status === 'ok');
                return [
                    'success' => $ok,
                    'code' => null,
                    'message' => $ok ? null : ($message ?: $body),
                ];
            }
        }

        if (preg_match('/\b(\d{3,4})\b/', $body, $m)) {
            $code = (int) $m[1];
            return [
                'success' => ($code === 202),
                'code' => $code,
                'message' => od_bulksmsbd_code_message($code) ?: $body,
            ];
        }

        if ($http_code >= 200 && $http_code < 300 && stripos($body, 'success') !== false) {
            return [
                'success' => true,
                'code' => null,
                'message' => null,
            ];
        }

        return [
            'success' => false,
            'code' => null,
            'message' => $body,
        ];
    }
}

if ( ! function_exists( 'od_bulksmsbd_code_message' ) ) {
    function od_bulksmsbd_code_message( $code ) {
        $map = [
            202 => 'SMS Submitted Successfully',
            1001 => 'Invalid Number',
            1002 => 'Sender ID not correct or sender ID is disabled',
            1003 => 'Required fields missing',
            1005 => 'Internal Error',
            1006 => 'Balance Validity Not Available',
            1007 => 'Balance Insufficient',
            1011 => 'User ID not found',
            1012 => 'Masking SMS must be sent in Bengali',
            1013 => 'Sender ID has not found Gateway by API key',
            1014 => 'Sender Type Name not found using this sender by API key',
            1015 => 'Sender ID has not found any valid Gateway by API key',
            1016 => 'Sender Type Name active price info not found by this sender ID',
            1017 => 'Sender Type Name price info not found by this sender ID',
            1018 => 'Account is disabled',
            1019 => 'Sender type price for this account is disabled',
            1020 => 'Parent account not found',
            1021 => 'Parent active sender type price not found',
            1031 => 'Account not verified',
            1032 => 'IP not whitelisted',
        ];

        return isset($map[$code]) ? $map[$code] : null;
    }
}

if ( ! function_exists( 'get_clean_price_with_currency' ) ) {
    function get_clean_price_with_currency($price) {
        return html_entity_decode(strip_tags(wc_price($price)));
    }
}

if ( ! function_exists( 'add_otp_enable_forcefully' ) ) {
    function add_otp_enable_forcefully(){
        if ( ! obn_license_active() ) {
            return;
        }

        $settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => '',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => '',
                'mimsms' => '',
                'bulksmsbd' => ''
            ),
            'mimsms_sender_id' => '',
            'mimsms_username' => '',
            'bulksmsbd_sender_id' => '',
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));
        if( isset($settings['enable_otp']) && 1 == $settings['enable_otp'] ) {
        ?>
        <script>
            jQuery(document).ready(function($) {
                function updateButtonClass() {
                    var $button = $('button[name="woocommerce_checkout_place_order"]');
                    if ($button.length) {
                        if (!$button.hasClass('button') || !$button.hasClass('alt') || !$button.hasClass('show-otp-popup')) {
                            $button.addClass('button alt show-otp-popup');
                        }
                    }
                }

                updateButtonClass();
                $(document.body).on('updated_checkout payment_method_selected update_checkout', updateButtonClass);
            });
        </script>
        <?php
        }
    }
    add_action('wp_footer', 'add_otp_enable_forcefully');
}

function csod_check_score_by_phone($phone) {

    if (empty($phone)) {
        return false;
    }

    $api_url = 'https://api.neurodigitalbd.com/score/v1/?phone=' . urlencode($phone);
    $curl_handle = curl_init($api_url);

    curl_setopt_array($curl_handle, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 15,
    ]);

    $response_body = curl_exec($curl_handle);

    if ($response_body === false) {
        curl_close($curl_handle);
        return false;
    }

    curl_close($curl_handle);
    $decoded_response = json_decode($response_body, true);
    return $decoded_response;
}

function csod_courier_check_button($order_id){
    echo '<button class="button button-primary csod-check-btn" data-order-id="'.esc_attr($order_id).'">
        Refresh Courier Data
    </button>';
}

function csod_save_score_to_order_meta($order_id, array $response) {

    if (empty($order_id) || empty($response)) {
        return false;
    }

    $order = wc_get_order($order_id);
    if (!$order) {
        return false;
    }

    $order->update_meta_data(
        '_csod_score_response',
        $response
    );

    $order->save();

    return true;
}

function csod_check_and_save() {
    check_ajax_referer('order-detect', 'nonce');

    if ( ! current_user_can( 'manage_woocommerce' ) ) {
        wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'order-detect' ) ), 403 );
    }

    if ( ! obn_license_active() ) {
        wp_send_json_error( array( 'message' => __( 'An active license is required to use this feature.', 'order-detect' ) ), 403 );
    }

    if (empty($_POST['order_id'])) {
        wp_send_json_error();
    }

    $order_id = (int) $_POST['order_id'];
    $order    = wc_get_order($order_id);

    if (!$order) {
        wp_send_json_error();
    }

    $phone = $order->get_billing_phone();

    $csod_response = csod_check_score_by_phone($phone);

    if (isset($csod_response['success']) && (int)$csod_response['success'] === 1) {
        csod_save_score_to_order_meta($order_id, $csod_response);
        wp_send_json_success();
    }

    wp_send_json_error();
}
\add_action('wp_ajax_csod_check_and_save', __NAMESPACE__ . '\csod_check_and_save');

function csod_schedule_score_check($order_id) {
    if ( ! obn_license_active() ) {
        return;
    }

    $order_id = (int) $order_id;
    if ($order_id < 1) {
        return;
    }

    $order = wc_get_order($order_id);
    if (!$order) {
        return;
    }

    if ($order->get_meta('_csod_score_response')) {
        return;
    }

    od_schedule_async_action('csod_async_check_score', array($order_id));
}
\add_action('woocommerce_checkout_order_processed', __NAMESPACE__ . '\csod_schedule_score_check');


function csod_process_scheduled_score_check($order_id) {
    if ( ! obn_license_active() ) {
        return;
    }

    $order_id = (int) $order_id;
    if ($order_id < 1) {
        return;
    }

    $order    = wc_get_order($order_id);
    if (!$order) {
        return;
    }

    $phone = $order->get_billing_phone();
    if (empty($phone)) {
        return;
    }

    $phone = preg_replace('/[^0-9]/', '', $phone);

    $response = csod_check_score_by_phone($phone);

    if (is_array($response) && isset($response['success']) && (int) $response['success'] === 1) {
        csod_save_score_to_order_meta($order_id, $response);
    }
}
\add_action('csod_async_check_score', __NAMESPACE__ . '\csod_process_scheduled_score_check');


function ddo_make_phone_variants($any_phone) {
    $digits = preg_replace('/\D+/', '', (string) $any_phone);
    if ($digits === '') {
        return [ '', '', '', '' ];
    }

    $last10 = substr($digits, -10);
    $local  = '0' . $last10;
    $with88 = '88'  . $last10;
    $plus88 = '+88' . $last10;

    return [ $local, $plus88, $with88, $last10 ];
}

add_action('current_screen', function () {
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ( ! $screen ) return;
    if ( ! in_array($screen->id, ['edit-shop_order','woocommerce_page_wc-orders'], true) ) return;
    if ( ! obn_license_active() ) return;

    if (isset($GLOBALS['ddo_phone_counts']) && is_array($GLOBALS['ddo_phone_counts'])) return;

    global $wpdb;

    $is_hpos = class_exists('\Automattic\WooCommerce\Utilities\OrderUtil')
        && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();

    if ($is_hpos) {
        $addr_tbl = $wpdb->prefix . 'wc_order_addresses';
        $phones = $wpdb->get_col("
            SELECT a.phone
            FROM {$addr_tbl} a
            WHERE a.address_type = 'billing'
              AND a.phone IS NOT NULL
              AND a.phone <> ''
        ");
    } else {
        $pm = $wpdb->postmeta;
        $phones = $wpdb->get_col( $wpdb->prepare("
            SELECT pm.meta_value
            FROM {$pm} pm
            WHERE pm.meta_key = %s
              AND pm.meta_value IS NOT NULL
              AND pm.meta_value <> ''
        ", '_billing_phone') );
    }

    $map = [];
    if ($phones) {
        foreach ($phones as $ph) {
            $digits = preg_replace('/\D+/', '', (string) $ph);
            if ($digits === '') continue;
            $last10 = substr($digits, -10);
            if ($last10 === '') continue;
            $map[$last10] = isset($map[$last10]) ? ($map[$last10] + 1) : 1;
        }
    }
    $GLOBALS['ddo_phone_counts'] = $map;
});

function ddo_render_duplicate_column_shop($column, $post_id) {
    if ( ! Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
        return;
    }
    if ($column !== 'ddo_duplicate') return;

    $raw_phone = (string) get_post_meta((int)$post_id, '_billing_phone', true);
    if ($raw_phone === '') { echo ''; return; }

    $digits = preg_replace('/\D+/', '', $raw_phone);
    $last10 = substr($digits, -10);
    if ($last10 !== '' && !empty($GLOBALS['ddo_phone_counts'][$last10])) {
        $count = (int) $GLOBALS['ddo_phone_counts'][$last10];
        echo ($count >= 2)
            ? '<button class="ddo-count-btn" data-phone="'. esc_attr('0'.$last10) .'">Total orders ' . $count . '</button>'
            : '';
        return;
    }

    list($local, $plus88, $with88, $last10x) = ddo_make_phone_variants($raw_phone);
    if ($last10x === '') { echo ''; return; }

    global $wpdb;
    $like = '%' . $wpdb->esc_like($last10x) . '%';

    $sql = "
        SELECT COUNT(DISTINCT p.ID)
        FROM {$wpdb->posts} p
        INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
        WHERE p.post_type = 'shop_order'
          AND pm.meta_key = '_billing_phone'
          AND (
                pm.meta_value = %s OR
                pm.meta_value = %s OR
                pm.meta_value = %s OR
                pm.meta_value LIKE %s
              )
    ";
    $count = (int) $wpdb->get_var( $wpdb->prepare($sql, $local, $plus88, $with88, $like) );

    echo ddo_render_count_or_blank($count, $local);
}
add_action('manage_shop_order_posts_custom_column', __NAMESPACE__ . '\ddo_render_duplicate_column_shop', 10, 2);

function ddo_render_duplicate_column_wc_orders($column, $order) {
    if ( ! Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
        return;
    }
    if ($column !== 'ddo_duplicate') return;

    $order_id = (is_object($order) && method_exists($order, 'get_id')) ? $order->get_id() : (int)$order;
    $wc_order = wc_get_order($order_id);
    if (! $wc_order) { echo ''; return; }
    $raw_phone = (string) $wc_order->get_billing_phone();
    if ($raw_phone === '') { echo ''; return; }
    $digits = preg_replace('/\D+/', '', $raw_phone);
    $last10 = substr($digits, -10);
    if ($last10 !== '' && !empty($GLOBALS['ddo_phone_counts'][$last10])) {
        $count = (int) $GLOBALS['ddo_phone_counts'][$last10];
        echo ($count >= 2)
            ? '<button class="ddo-count-btn" data-phone="'. esc_attr('0'.$last10) .'">Total Orders ' . $count . '</button>'
            : '';
        return;
    }

    list($local, $plus88, $with88, $last10x) = ddo_make_phone_variants($raw_phone);
    if ($last10x === '') { echo ''; return; }

    global $wpdb;

    $orders_tbl = $wpdb->prefix . 'wc_orders';
    $addr_tbl   = $wpdb->prefix . 'wc_order_addresses';

    $like = '%' . $wpdb->esc_like($last10x) . '%';

    $sql = "
        SELECT COUNT(DISTINCT o.id)
        FROM {$orders_tbl} o
        INNER JOIN {$addr_tbl} a
            ON a.order_id = o.id AND a.address_type = 'billing'
        WHERE o.type = 'shop_order'
          AND (
                a.phone = %s OR
                a.phone = %s OR
                a.phone = %s OR
                a.phone LIKE %s
              )
    ";
    $count = (int) $wpdb->get_var( $wpdb->prepare($sql, $local, $plus88, $with88, $like) );

    echo ddo_render_count_or_blank($count, $local);
}
add_action('manage_woocommerce_page_wc-orders_custom_column', __NAMESPACE__ . '\ddo_render_duplicate_column_wc_orders', 10, 2);

function ddo_render_count_or_blank($count, $search_key_local) {
    if ($count >= 2) {
        return '<span class="ddo-count-btn" data-phone="'. esc_attr($search_key_local) .'">Total Orders ' . (int)$count . '</span>';
    }
    return '';
}

add_action('wp_ajax_ddo_get_orders_by_phone', __NAMESPACE__ . '\ddo_get_orders_by_phone');
function ddo_get_orders_by_phone() {
    check_ajax_referer('ddo_nonce', 'nonce');

    if ( ! current_user_can( 'manage_woocommerce' ) ) {
        wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'order-detect' ) ), 403 );
    }

    if ( ! obn_license_active() ) {
        wp_send_json_error( array( 'message' => __( 'An active license is required to use this feature.', 'order-detect' ) ), 403 );
    }

    $search_key = isset($_POST['phone']) ? (string) wp_unslash($_POST['phone']) : '';
    list($local, $plus88, $with88, $last10) = ddo_make_phone_variants($search_key);
    if ($last10 === '') wp_send_json_success(['orders' => []]);

    global $wpdb;

    $is_hpos = class_exists('\Automattic\WooCommerce\Utilities\OrderUtil')
        && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();

    $like = '%' . $wpdb->esc_like($last10) . '%';

    if ($is_hpos) {
        $orders_tbl = $wpdb->prefix . 'wc_orders';
        $addr_tbl   = $wpdb->prefix . 'wc_order_addresses';
        $sql = "
            SELECT DISTINCT 
                o.id AS order_id,
                o.status,
                o.date_created_gmt,
                a.first_name,
                a.last_name,
                a.phone
            FROM {$orders_tbl} o
            INNER JOIN {$addr_tbl} a
                ON a.order_id = o.id AND a.address_type = 'billing'
            WHERE o.type = 'shop_order'
              AND (
                    a.phone = %s OR
                    a.phone = %s OR
                    a.phone = %s OR
                    a.phone LIKE %s
                  )
            ORDER BY o.date_created_gmt DESC
            LIMIT 200
        ";
        $rows = $wpdb->get_results( $wpdb->prepare($sql, $local, $plus88, $with88, $like) );
    } else {
        $pm = $wpdb->postmeta;
        $p  = $wpdb->posts;
        $sql = "
            SELECT DISTINCT 
                p.ID AS order_id,
                p.post_status AS status,
                p.post_date_gmt AS date_created_gmt,
                MAX(CASE WHEN pm1.meta_key = '_billing_first_name' THEN pm1.meta_value END) AS first_name,
                MAX(CASE WHEN pm2.meta_key = '_billing_last_name'  THEN pm2.meta_value END) AS last_name,
                MAX(CASE WHEN pm3.meta_key = '_billing_phone'      THEN pm3.meta_value END) AS phone
            FROM {$p} p
            LEFT JOIN {$pm} pm1 ON pm1.post_id = p.ID
            LEFT JOIN {$pm} pm2 ON pm2.post_id = p.ID
            LEFT JOIN {$pm} pm3 ON pm3.post_id = p.ID
            WHERE p.post_type = 'shop_order'
              AND (
                    (pm3.meta_key = '_billing_phone' AND pm3.meta_value = %s) OR
                    (pm3.meta_key = '_billing_phone' AND pm3.meta_value = %s) OR
                    (pm3.meta_key = '_billing_phone' AND pm3.meta_value = %s) OR
                    (pm3.meta_key = '_billing_phone' AND pm3.meta_value LIKE %s)
                  )
            GROUP BY p.ID, p.post_status, p.post_date_gmt
            ORDER BY p.post_date_gmt DESC
            LIMIT 200
        ";
        $rows = $wpdb->get_results( $wpdb->prepare($sql, $local, $plus88, $with88, $like) );
    }

    $orders = [];
    foreach ($rows as $r) {
        $id     = (int) $r->order_id;
        $status = (string) $r->status;

        $status_label = function_exists('wc_get_order_status_name')
            ? wc_get_order_status_name($status)
            : $status;

        $edit_url = class_exists('\Automattic\WooCommerce\Utilities\OrderUtil')
            && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled()
            ? admin_url('admin.php?page=wc-orders&action=edit&id=' . $id)
            : admin_url('post.php?post=' . $id . '&action=edit');
        $first = isset($r->first_name) ? (string) $r->first_name : '';
        $last  = isset($r->last_name)  ? (string) $r->last_name  : '';
        $name  = trim($first . ' ' . $last);
        $phone_raw = isset($r->phone) ? (string) $r->phone : '';
        $order_obj = wc_get_order($id);
        $customer_ip = $order_obj ? $order_obj->get_customer_ip_address() : 'N/A';
        $product_image = '';
        if ($order_obj) {
            $items = $order_obj->get_items();
            foreach ($items as $item) {
                $product = $item->get_product();
                if ($product && $product->get_image_id()) {
                    $product_image = wp_get_attachment_image_url($product->get_image_id(), 'thumbnail');
                    break;
                }
            }
        }
        if (!$product_image) {
            $product_image = wc_placeholder_img_src('thumbnail');
        }

        $orders[] = [
            'id'           => $id,
            'status'       => $status,
            'status_label' => $status_label,
            'date' => get_date_from_gmt($r->date_created_gmt,'d M Y, h:i A'),
            'url'          => $edit_url,
            'name'         => $name,
            'phone'        => $phone_raw,
            'ip'           => $customer_ip,
            'image'        => $product_image,
        ];
    }

    wp_send_json_success(['orders' => $orders]);
}

add_action('admin_footer', function(){
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ( ! $screen ) return;
    if ( ! in_array($screen->id, ['edit-shop_order','woocommerce_page_wc-orders'], true) ) return;
    if ( ! obn_license_active() ) return; ?>
    <div id="ddo-modal" class="ddo-modal" style="display:none;">
        <div class="ddo-modal__backdrop"></div>
        <div class="ddo-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="ddo-modal-title">
            <div class="ddo-modal__header">
                <h3 id="ddo-modal-title">Orders for this phone</h3>
                <button type="button" class="ddo-modal__close" aria-label="Close">×</button>
            </div>
            <div class="ddo-modal__body">
                <div class="ddo-modal__loading">Loading…</div>
                <table class="ddo-table" style="display:none;">
                    <thead>
                        <tr>
                            
                            <th>ID</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Image</th>
                            <th>IP</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
                <div class="ddo-modal__empty" style="display:none;">No orders found.</div>
            </div>
        </div>
    </div>
<?php });


add_action('admin_footer', function () {
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$screen) return;
    if (!in_array($screen->id, ['edit-shop_order','woocommerce_page_wc-orders'], true)) return;
    if ( ! obn_license_active() ) return;
    ?>
    <script>

    var DDO_VARS = {
        ajax_url: "<?php echo esc_js(admin_url('admin-ajax.php')); ?>",
        nonce: "<?php echo wp_create_nonce('ddo_nonce'); ?>"
    };

    (function ($) {

        function openModal() {
            $("#ddo-modal").show();
        }
        function closeModal() {
            $("#ddo-modal").hide();
        }

        $(document).on("click", ".ddo-count-btn", function (e) {
            e.preventDefault();
            console.log('BUTTON CLICKED');

            var phone = $(this).data("phone");
            if (!phone) return;

            var $modal = $("#ddo-modal");
            var $title = $modal.find("#ddo-modal-title");
            var $loading = $modal.find(".ddo-modal__loading");
            var $table = $modal.find(".ddo-table");
            var $tbody = $table.find("tbody");
            var $empty = $modal.find(".ddo-modal__empty");

            $title.text("Orders for: " + phone);

            $tbody.empty();
            $table.hide();
            $empty.hide();
            $loading.show();
            openModal();

            $.post(DDO_VARS.ajax_url, {
                action: "ddo_get_orders_by_phone",
                nonce: DDO_VARS.nonce,
                phone: phone
            })
            .done(function (resp) {
                $loading.hide();

                if (!resp || !resp.success || !resp.data || !resp.data.orders.length) {
                    $empty.show();
                    return;
                }

                resp.data.orders.forEach(function (r) {
                    var tr =
                        "<tr>" +
                        "<td><a href='" + r.url + "' target='_blank'>#" + r.id + "</a></td>" +
                        "<td>" + (r.name || "") + "</td>" +
                        "<td>" + (r.phone || "") + "</td>" +
                        "<td><img src='" + r.image + "' style='width:40px;height:40px'></td>" +
                        "<td>" + (r.ip || "") + "</td>" +
                        "<td>" + r.status_label + "</td>" +
                        "<td>" + r.date + "</td>" +
                        "<td><a href='" + r.url + "' target='_blank' class='button button-primary ddo-open-link'>Open</a></td>" +
                        "</tr>";
                    $tbody.append(tr);
                });

                $table.show();
            })
            .fail(function () {
                $loading.hide();
                $empty.text("Failed to load").show();
            });
        });

        $(document).on("click", ".ddo-modal__close, .ddo-modal__backdrop", function () {
            closeModal();
        });

    })(jQuery);
    </script>
    <?php
});

add_action('init', function () {

    if (is_admin() || wp_doing_ajax()) {
        return;
    }

    if (!isset($_COOKIE['hashed_user_agent'])) { 
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $hashed_user_agent = md5($user_agent . bin2hex(random_bytes(16)));

        setcookie(
            'hashed_user_agent',
            $hashed_user_agent,
            time() + (10 * YEAR_IN_SECONDS),
            COOKIEPATH,
            COOKIE_DOMAIN,
            is_ssl(),
            false
        );

        $_COOKIE['hashed_user_agent'] = $hashed_user_agent;
    }
}, 1);

add_action('woocommerce_checkout_create_order', function($order) {
    if (!empty($_COOKIE['hashed_user_agent'])) {
        $order->update_meta_data('_hashed_user_agent', $_COOKIE['hashed_user_agent']);
    }

    $phone = obn_normalize_phone($order->get_billing_phone());
    if ($phone !== '') {
        $order->set_billing_phone($phone);
    }
});


function obn_normalize_phone($phone_raw) {
    return \OrderDetect\Helper::normalize_bangladeshi_phone_number($phone_raw);
}

function obn_is_valid_phone($phone_raw) {
    return \OrderDetect\Helper::is_valid_Bangladeshi_phone_number($phone_raw);
}

function obn_invalid_phone_message() {
    return __('Please enter a valid Bangladeshi phone number.', 'order-detect');
}

function obn_render_button($order){
    if ( ! obn_license_active() ) {
        return;
    }
    global $wpdb;
    $table = $wpdb->prefix . 'obn_blocklist';

    $phone  = esc_attr($order->get_billing_phone());
    $ip     = esc_attr($order->get_customer_ip_address());
    $device = $order->get_meta('_hashed_user_agent');
    $phone_enabled  = (int) get_option('obn_manual_enabled_phone', 0) === 1;
    $ip_enabled     = (int) get_option('obn_manual_enabled_ip', 0) === 1;
    $device_enabled = (int) get_option('obn_manual_enabled_device', 0) === 1;

    $phone_blocked  = $phone  ? (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE type='phone' AND value=%s", $phone))   : false;
    $ip_blocked     = $ip     ? (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE type='ip' AND value=%s", $ip))         : false;
    $device_blocked = $device ? (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE type='device' AND value=%s", $device)) : false;
    ?>

    <?php if ($phone && $phone_enabled) { ?>
        <button type="button"
            class="obn-block-btn obn-block-phone"
            data-type="phone"
            data-value="<?php echo $phone; ?>"
            <?php echo $phone_blocked ? 'disabled' : ''; ?>>
            <?php echo $phone_blocked ? 'Phone Blocked' : 'Block Phone'; ?>
        </button>
    <?php } ?>

    <?php if ($ip && $ip_enabled) { ?>
        <button type="button"
            class="obn-block-btn obn-block-ip"
            data-type="ip"
            data-value="<?php echo $ip; ?>"
            <?php echo $ip_blocked ? 'disabled' : ''; ?>>
            <?php echo $ip_blocked ? 'IP Blocked' : 'Block IP'; ?>
        </button>
    <?php } ?>

    <?php if ($device && $device_enabled) { ?>
        <button type="button"
            class="obn-block-btn obn-block-device"
            data-type="device"
            data-value="<?php echo $device; ?>"
            <?php echo $device_blocked ? 'disabled' : ''; ?>>
            <?php echo $device_blocked ? 'Device Blocked' : 'Block Device'; ?>
        </button>
    <?php } ?>
    <?php
}

function obn_is_blocked_value($type, $value) {
    global $wpdb;
    $table = $wpdb->prefix . 'obn_blocklist';

    if ( ! obn_license_active() ) {
        return false;
    }
    $enabled = (int) get_option("obn_manual_enabled_{$type}", 0);
    if ($enabled !== 1) {
        return false;
    }
    if (empty($type) || empty($value)) {
        return false;
    }

    return (bool) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $table WHERE type=%s AND value=%s",
        $type,
        $value
    ));
}

function obn_is_auto_blocked($type, $value) {
    global $wpdb;
    if (empty($type) || empty($value)) {
        return false;
    }
    if ( ! obn_license_active() ) {
        return false;
    }

    $enabled = (int) get_option("obn_auto_enabled_{$type}", 0);
    if ($enabled !== 1) {
        return false;
    }

    $table = $wpdb->prefix . 'obn_auto_block';

    // কতগুলো entry আছে যেগুলো এখনও expire হয়নি
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT COUNT(*) as cnt, MAX(expires_at) as last_exp 
         FROM $table 
         WHERE type=%s AND value=%s AND expires_at > UTC_TIMESTAMP()",
        $type, $value
    ));

    if (!$row) return false;

    $limit    = absint(get_option("obn_auto_limit_{$type}", ''));
    $duration = absint(get_option("obn_auto_duration_{$type}", ''));
    $message  = get_option("obn_auto_message_{$type}", '');

    if ($limit < 1 || $duration < 1 || $message === '') {
        return false;
    }
    $limit = absint($limit);
    $duration = absint($duration);
    if ($limit < 1 || $duration < 1) {
        return false;
    }

    if ($row->cnt >= $limit) {
        return $message;
    }
    return false;
}

add_action('woocommerce_checkout_process', function () {
    $phone_raw  = isset($_POST['billing_phone']) ? trim($_POST['billing_phone']) : '';
    if (empty($phone_raw) && WC()->customer) {
        $phone_raw = WC()->customer->get_billing_phone();
    }
    $phone = obn_normalize_phone($phone_raw);

    if ( ! obn_is_valid_phone($phone_raw) || $phone === '' ) {
        wc_add_notice(obn_invalid_phone_message(), 'error');
        return;
    }

    if ( ! obn_license_active() ) {
        return;
    }

    $ip     = $_SERVER['REMOTE_ADDR'] ?? '';
    $device = $_COOKIE['hashed_user_agent'] ?? '';

    // manual block check
    if ($phone && obn_is_blocked_value('phone', $phone)) {
        wc_add_notice(obn_get_block_message('phone'), 'error');
    }
    if ($ip && obn_is_blocked_value('ip', $ip)) {
        wc_add_notice(obn_get_block_message('ip'), 'error');
    }
    if ($device && obn_is_blocked_value('device', $device)) {
        wc_add_notice(obn_get_block_message('device'), 'error');
    }

    // auto block check
    foreach (['phone'=>$phone,'ip'=>$ip,'device'=>$device] as $type=>$value) {
        $msg = obn_is_auto_blocked($type, $value);
        if ($msg) {
            wc_add_notice($msg, 'error');
        }
    }
});

add_action('woocommerce_store_api_checkout_validation', function ($data_or_request, $errors) {
    $phone_raw = '';
    if (is_array($data_or_request)) {
        if (!empty($data_or_request['billing_address']['phone'])) {
            $phone_raw = (string) $data_or_request['billing_address']['phone'];
        }
    } elseif (is_object($data_or_request) && method_exists($data_or_request, 'get_param')) {
        $billing = $data_or_request->get_param('billing_address');
        if (is_array($billing) && !empty($billing['phone'])) {
            $phone_raw = (string) $billing['phone'];
        }
    }
    $phone = obn_normalize_phone($phone_raw);

    if ( ! obn_is_valid_phone($phone_raw) || $phone === '' ) {
        $errors->add('obn_invalid_phone', obn_invalid_phone_message());
        return;
    }

    if ( ! obn_license_active() ) {
        return;
    }

    $ip     = $_SERVER['REMOTE_ADDR'] ?? '';
    $device = $_COOKIE['hashed_user_agent'] ?? '';

    // manual block check
    if ($phone && obn_is_blocked_value('phone', $phone)) {
        $errors->add('obn_block_phone', obn_get_block_message('phone'));
    }
    if ($ip && obn_is_blocked_value('ip', $ip)) {
        $errors->add('obn_block_ip', obn_get_block_message('ip'));
    }
    if ($device && obn_is_blocked_value('device', $device)) {
        $errors->add('obn_block_device', obn_get_block_message('device'));
    }

    // auto block check
    foreach (['phone'=>$phone,'ip'=>$ip,'device'=>$device] as $type=>$value) {
        $msg = obn_is_auto_blocked($type, $value);
        if ($msg) {
            $errors->add("obn_auto_block_{$type}", $msg);
        }
    }
}, 10, 2);

add_action('woocommerce_checkout_create_order', function ($order, $data) {
    $phone  = obn_normalize_phone($order->get_billing_phone());

    if ($phone === '') {
        throw new Exception(obn_invalid_phone_message());
    }

    $order->set_billing_phone($phone);

    if ( ! obn_license_active() ) {
        return;
    }

    $ip     = $order->get_customer_ip_address();
    $device = $order->get_meta('_hashed_user_agent');

    // manual block guard
    if ($phone && obn_is_blocked_value('phone', $phone)) {
        throw new Exception(obn_get_block_message('phone'));
    }
    if ($ip && obn_is_blocked_value('ip', $ip)) {
        throw new Exception(obn_get_block_message('ip'));
    }
    if ($device && obn_is_blocked_value('device', $device)) {
        throw new Exception(obn_get_block_message('device'));
    }

    // auto block guard
    foreach (['phone'=>$phone,'ip'=>$ip,'device'=>$device] as $type=>$value) {
        $msg = obn_is_auto_blocked($type, $value);
        if ($msg) {
            throw new Exception($msg);
        }
    }
}, 20, 2);

add_action('woocommerce_checkout_order_processed', function ($order_id, $posted_data, $order) {
    if ( ! obn_license_active() ) {
        return;
    }
    global $wpdb;
    $table = $wpdb->prefix . 'obn_auto_block';

    $phone  = obn_normalize_phone($order->get_billing_phone());
    $ip     = $order->get_customer_ip_address();
    $device = $order->get_meta('_hashed_user_agent');

    $types = ['phone'=>$phone,'ip'=>$ip,'device'=>$device];
    foreach ($types as $type=>$value) {
        if (!$value) continue;
        $enabled = (int) get_option("obn_auto_enabled_{$type}", 0);
        if ($enabled !== 1) {
            continue;
        }
        $minutes = absint(get_option("obn_auto_duration_{$type}", ''));
        if ($minutes < 1) {
            continue;
        }
        $wpdb->query($wpdb->prepare(
            "INSERT INTO $table (order_id, type, value, created_at, expires_at)
             VALUES (%d, %s, %s, UTC_TIMESTAMP(), DATE_ADD(UTC_TIMESTAMP(), INTERVAL %d MINUTE))",
            $order_id, $type, $value, $minutes
        ));
    }
}, 20, 3);

add_action('woocommerce_rest_insert_shop_order_object', function ($order, $request, $creating) {
    if ( ! obn_license_active() ) {
        return;
    }
    if (!$creating) {
        return;
    }

    global $wpdb;
    $table = $wpdb->prefix . 'obn_auto_block';

    $phone  = '';
    $billing = $request->get_param('billing');
    if (is_array($billing) && !empty($billing['phone'])) {
        $phone = trim($billing['phone']);
    } elseif (method_exists($order, 'get_billing_phone')) {
        $phone = $order->get_billing_phone();
    }

    $phone  = function_exists('obn_normalize_phone') ? obn_normalize_phone($phone) : $phone;

    if ($phone === '') {
        $message = obn_invalid_phone_message();
        if (class_exists('WC_REST_Exception')) {
            throw new WC_REST_Exception('obn_invalid_phone', $message, 400);
        }
        wp_die($message, '', ['response' => 400]);
    }

    if (method_exists($order, 'set_billing_phone')) {
        $order->set_billing_phone($phone);
    }

    $ip = $request->get_param('customer_ip_address');
    if (empty($ip)) {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    }

    $ua = $request->get_param('customer_user_agent');
    if (empty($ua)) {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    }

    $device = '';
    $meta = $request->get_param('meta_data');
    if (is_array($meta)) {
        foreach ($meta as $m) {
            if ($m['key'] === '_hashed_user_agent') {
                $device = $m['value'];
                break;
            }
        }
    }
    if (empty($device) && isset($_COOKIE['hashed_user_agent'])) {
        $device = $_COOKIE['hashed_user_agent'];
    }

    if ($ip) {
        $order->set_customer_ip_address($ip);
    }
    if ($ua) {
        $order->set_customer_user_agent($ua);
    }
    if ($device) {
        $order->update_meta_data('_hashed_user_agent', $device);
    }

    foreach (['phone'=>$phone, 'ip'=>$ip, 'device'=>$device] as $type => $value) {
        if (!$value) continue;
        if (obn_is_blocked_value($type, $value)) {
            $msg = obn_get_block_message($type);
            $order->update_status('cancelled', '🚫 Blocked by OBN (' . $type . ')');
            if (class_exists('WC_REST_Exception')) {
                throw new WC_REST_Exception('obn_blocked', $msg, 403);
            }
            wp_die($msg, '', ['response' => 403]);
        }
    }

    foreach (['phone'=>$phone,'ip'=>$ip,'device'=>$device] as $type=>$value) {
        if (!$value) continue;
        $enabled = (int) get_option("obn_auto_enabled_{$type}", 0);
        if ($enabled !== 1) {
            continue;
        }
        $msg = obn_is_auto_blocked($type, $value);
        if ($msg) {
            $order->update_status('cancelled', '🚫 Auto-blocked by OBN (' . $type . ')');
            if (class_exists('WC_REST_Exception')) {
                throw new WC_REST_Exception('obn_auto_blocked', $msg, 403);
            }
            wp_die($msg, '', ['response' => 403]);
        }
    }

    $types = ['phone'=>$phone,'ip'=>$ip,'device'=>$device];
    foreach ($types as $type=>$value) {
        if (!$value) continue;
        $enabled = (int) get_option("obn_auto_enabled_{$type}", 0);
        if ($enabled !== 1) {
            continue;
        }

        $minutes = absint(get_option("obn_auto_duration_{$type}", ''));
        if ($minutes < 1) {
            continue;
        }
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table WHERE type=%s AND value=%s AND expires_at > UTC_TIMESTAMP()",
            $type, $value
        ));

        if (!$exists) {
            $wpdb->query($wpdb->prepare(
                "INSERT INTO $table (order_id, type, value, created_at, expires_at)
                 VALUES (%d, %s, %s, UTC_TIMESTAMP(), DATE_ADD(UTC_TIMESTAMP(), INTERVAL %d MINUTE))",
                $order->get_id(), $type, $value, $minutes
            ));
        }
    }
    $order->save();

}, 10, 3);
