<?php
/**
 * Plugin Name: Order Detect
 * Plugin URI: https://orderdetect.com/
 * Description: Secure your store with phone verification and parcel trust scores for smarter order management and reduced fraud.
 * Version: 1.0.21
 * Author: NEURO Digital
 * Author URI: https://neurodigitalbd.com/
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain:       order-detect
 * Domain Path:       /languages
 * @package Order Detect
 */

if ( ! defined('ABSPATH') ) {
    exit;
}

require_once __DIR__ . '/vendor/autoload.php';

final class OrderDetect {

    const version = '1.0.21';

    private function __construct() {
        $this->define_constants();

        register_activation_hook(__FILE__, [$this, 'activate']);
        add_action('plugins_loaded', [$this, 'init_plugin']);
    }

    public static function init() {
        static $instance = false;

        if (!$instance) {
            $instance = new self();
        }

        return $instance;
    }

    public function define_constants() {
        define('ORDERDETECT_VERSION', self::version);
        define('ORDERDETECT_FILE', __FILE__);
        define('ORDERDETECT_PATH', __DIR__);
        define('ORDERDETECT_URL', plugins_url('', ORDERDETECT_FILE));
        define('ORDERDETECT_ASSETS', ORDERDETECT_URL . '/assets');
        define('ORDERDETECT_VIEWS', __DIR__ . '/includes/views');
        define('ORDERDETECT_BASENAME', plugin_basename(__FILE__));
        define('ORDERDETECT_PLUGIN_NAME', 'Order Detect');
        define('ORDERDETECT_MINIMUM_PHP_VERSION', '7.4');
        define('ORDERDETECT_MINIMUM_WP_VERSION', '6.0');
        define('ORDERDETECT_MINIMUM_WC_VERSION', '3.1');

        define('ORDERDETECT_STORE_URL', 'https://dash.orderdetect.com/');
        define('ORDERDETECT_SL_ITEM_NAME', 'Order Detect');

        define('ORDERDETECT_ENCRYPTION_KEY', 'yE7VLwfyweOTwWyxQgjNcxgArStNUARmkHVvsF3j4eU=');
        define('ORDERDETECT_IV', 'sq/gQejtmYczi99rYa61hA==');

        global $odSmsProvider;
        $odSmsProvider = array(
            'greenweb' => 'https://api.bdbulksms.net',
            'alpha' => 'https://api.sms.net.bd',
            'dianahost' => 'https://login.esms.com.bd/api/v3',
            'mimsms' => 'https://api.mimsms.com/api',
            'bulksmsbd' => 'https://bulksmsbd.net/api'
        );
    }

    public function init_plugin() {

        new OrderDetect\Assets();

        if (defined('DOING_AJAX') && DOING_AJAX) {
            new OrderDetect\Ajax();
        }

        if (is_admin()) {
            new OrderDetect\Admin();
        } else {
            new OrderDetect\Frontend();
        }

        new OrderDetect\API();
        OrderDetect\Services\OrderNotifications::instance();
    }

    public function activate() {
        $installer = new OrderDetect\Installer();
        $installer->run();
    }
}

function order_detect() {
    return OrderDetect::init();
}

order_detect();
